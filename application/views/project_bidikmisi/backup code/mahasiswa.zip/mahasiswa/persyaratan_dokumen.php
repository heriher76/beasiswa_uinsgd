<?php
	$this->load->view('project_bidikmisi/header/mahasiswa/header3_mhs');
	$this->load->view('project_bidikmisi/mahasiswa/navbar_mhs');
?>

<!DOCTYPE html>
<html>
	<body>
		<div class="container-fluid">
			<div class="">
				<div class="row">
					<div class="notif notifikasi col-md-offset-8">
						<?php echo $this->session->flashdata('direct9_success'); ?>
					</div>

					<!--Sidebar-->
					<div class="col-md-3" style="padding-bottom: 40px;">
						<div class="sidebar-buat col-md-12 col-md-offset-1">
							<h3>Tahapan Bidikmisi</h3>
						</div>

						<div class="list-group col-md-12 col-md-offset-1">
							<a href="<?=base_url('C_mhs'); ?>" class="list-group-item input">Tahap 1 Upload Foto</a>
							<a href="<?=base_url('C_mhs/step2'); ?>" class="list-group-item input">Tahap 2 Identitas Diri</a>
							<a href="<?=base_url('C_mhs/step3'); ?>" class="list-group-item input">Tahap 3 Data Ortu</a>
							<a href="<?=base_url('C_mhs/step4'); ?>" class="list-group-item input">Tahap 4 Data Kondisi Rumah</a>
							<a href="<?=base_url('C_mhs/step5'); ?>" class="list-group-item input">Tahap 5 Data Sekolah</a>
							<a href="<?=base_url('C_mhs/step6'); ?>" class="list-group-item input">Tahap 6 Data Pesantren</a>
							<a href="<?=base_url('C_mhs/step7'); ?>" class="list-group-item input">Tahap 7 Keterampilan</a>
							<a href="<?=base_url('C_mhs/step8'); ?>" class="list-group-item input">Tahap 8 Upload Dokumen Pendukung</a>
							<a href="<?=base_url('C_mhs/step9'); ?>" class="list-group-item input active">Tahap 9 Persyaratan Dokumen</a>
							<a href="<?=base_url('C_mhs/step10'); ?>" class="list-group-item input">Tahap 10 Verifikasi Data</a>	    
						</div>
					</div>
					<!--End Sidebar-->

					<div class="col-md-4" style="text-align: center;">
    					<div class="col-md-offset-2">
    						<h3>RULE Tahap 9 (Persyaratan Dokumen)</h3>
    						<div class="penting">
    							<p>Tanda Asterik (*) Wajib diisi</p>
    						</div>
    						
    						<p>Silahkan klik Tombol EDIT dibawah, jika ada kesalahan/data anda belum diisi</p>
    						<p>Jika sudah diisi Silahkan klik Tombol Lanjut</p>
    					</div>
					</div>		

					<?php foreach($data_diri as $value) { ?>
					<div class="col-md-4">
						<div class="tahap">
							<h3>Tahap 9</h3>
						</div>
						
						<!--Persyaratan Dokumen-->
						<div id="persyaratan-dokumen">
							<h2><b><u>Persyaratan Dokumen</u></b></h2>
						</div>

						<table class="table">
							<tr>
								<td>Kartu Peserta Jalur <?php echo $value->jalur_pendaftaran.' '.date('Y'); ?></td>
								<td>:</td>
								<td><?php echo $value->kartu_tes; ?></td>
								<td><i class="asterik">*</i></td>
							</tr>

							<tr>
								<td>Formulir Pedaftaran Bidik Misi yang telah diisi</td>
								<td>:</td>
								<td><?php echo $value->formulir_pendaftaran; ?></td>
								<td><i class="asterik">*</i></td>
							</tr>

							<tr>
								<td>Surat Keterangan Lulus dari Kepela Sekolah</td>
								<td>:</td>
								<td><?php echo $value->surat_ket_lulus; ?></td>
								<td><i class="asterik">*</i></td>
							</tr>

							<tr>
								<td>Fotocopy Raport Semester 1-6 yang dilegalisir Kepala Sekolah</td>
								<td>:</td>
								<td><?php echo $value->fotocopy_raport_semester; ?></td>
								<td><i class="asterik">*</i></td>
							</tr>

							<tr>
								<td>Fotocopy Ijazah yang dilegalisir Kepala Sekolah</td>
								<td>:</td>
								<td><?php echo $value->fotocopy_ijazah; ?></td>
								<td><i class="asterik">*</i></td>
							</tr>

							<tr>
								<td>Fotocopy Nilai Ujian Akhir Nasional yang dilegalisir Kepala Sekolah</td>
								<td>:</td>
								<td><?php echo $value->fotocopy_nilai_uan; ?></td>
								<td><i class="asterik">*</i></td>
							</tr>

							<tr>
								<td>Surat Keterangan Prestasi dan Bukti Pendukung Prestasi yang dilegalisir Kepala Sekolah</td>
								<td>:</td>
								<td><?php echo $value->surat_ket_prestasi; ?></td>
								<td><i class="asterik">*</i></td>
							</tr>

							<tr>
								<td>Surat Keterangan Penghasilan Ortu/Wali atau Surat Keterangan Tidak Mampu yang dikeluarkan Kepala Desa/Dusun/Instansi/Tokoh Masyarakat</td>
								<td>:</td>
								<td><?php echo $value->surat_ket_peng_ortu; ?></td>
								<td><i class="asterik">*</i></td>
							</tr>

							<tr>
								<td>Fotocopy Kartu Keluarga atau Surat Keterangan Susunan Keluarga</td>
								<td>:</td>
								<td><?php echo $value->fotocopy_kk; ?></td>
								<td><i class="asterik">*</i></td>
							</tr>

							<tr>
								<td>Fotocopy Rekening Listrik Bulan Terakhir (bila tersedia listrik)</td>
								<td>:</td>
								<td><?php echo $value->fotocopy_rek_listrik; ?></td>
								<td><i class="asterik">*</i></td>
							</tr>

							<tr>
								<td>Fotocopy Bukti Pembayaran PBB Tahun Terakhir</td>
								<td>:</td>
								<td><?php echo $value->fotocopy_pbb; ?></td>
								<td><i class="asterik">*</i></td>
							</tr>

							<tr>
								<td>Melengkapi data foto rumah dari 3(tiga) sudut</td>
								<td>:</td>
								<td><?php echo $value->foto_rumah_tiga_sudut; ?></td>
								<td><i class="asterik">*</i></td>
							</tr>
						</table>
						<!--End Persyaratan Dokumen-->

						<!--button-->
						<div class="button-all">
							<div class="col-md-12 col-md-offset-2">
								<a href="<?=base_url('C_mhs/step8'); ?>" class="btn btn-info">
									<i class="fa fa-check-circle-o"></i>
									&laquo; Kembali
								</a>

								<button data-target="#edit-data-dokumen" data-toggle="modal" class="btn btn-primary" value="Edit" type="submit">
									<i class="glyphicon glyphicon-edit"></i>
									Edit
								</button>

								<a href="<?=base_url('C_mhs/step10'); ?>" class="btn btn-info">
									<i class="fa fa-check-circle-o"></i>
									Lanjut &raquo;
								</a>
							</div>
						</div>
						<!--End button-->
					</div>

					<!--Modal Update Persyaratan Dokumen-->
					<form action="<?=base_url('C_mhs/direct9'); ?>" method="POST">
						<div id="edit-data-dokumen" class="modal fade">
							<div class="modal-dialog">
								<div class="modal-content">
									<div class="modal-header">
										<button type="button" class="close" data-dismiss="modal">&times;</button>
										<h4 class="modal-title">Edit Data Persyaratan Dokumen</h4>
									</div>

									<div class="modal-body">
										<?php foreach($data_diri as $value) { ?>
											<div class="form-group">
												<label class="input">Kartu Tes Pendaftaran Jalur <?php echo $value->jalur_pendaftaran; ?> <i class="asterik">*</i></label>
												<select class="form-control input" required="required" name="kartu_tes">
													<?php if($value->kartu_tes == null) {?>	
														<option value="">-Pilih SalahSatu-</option>
														<option value="ADA">ADA</option>
														<option value="TIDAK ADA">TIDAK ADA</option>
													<?php }else{ ?>
														<option value="<?php echo $value->kartu_tes; ?>"><?php echo $value->kartu_tes; ?></option>
														<option value="">--</option>
														<option value="ADA">ADA</option>
														<option value="TIDAK ADA">TIDAK ADA</option>
													<?php } ?>
												</select>
											</div>

											<div class="form-group">
												<label class="input">Formulir Pendaftaran Bidik Misi yang telah diisi <i class="asterik">*</i></label>
												<select class="form-control input" required="required" name="formulir_pendaftaran">
													<?php if($value->formulir_pendaftaran == null) { ?>	
														<option value="">-Pilih SalahSatu-</option>
														<option value="ADA">ADA</option>
														<option value="TIDAK ADA">TIDAK ADA</option>
													<?php }else{ ?>
														<option value="<?php echo $value->formulir_pendaftaran; ?>"><?php echo $value->formulir_pendaftaran; ?></option>
														<option value="">--</option>
														<option value="ADA">ADA</option>
														<option value="TIDAK ADA">TIDAK ADA</option>
													<?php } ?>
												</select>
											</div>

											<div class="form-group">
												<label class="input">Surat Keterangan Lulus dari Kepala Sekolah <i class="asterik">*</i></label>
												<select class="form-control input" required="required" name="skl_dari_kepsek">
													<?php if($value->surat_ket_lulus == null) { ?>
														<option value="">-Pilih SalahSatu-</option>
														<option value="ADA">ADA</option>
														<option value="TIDAK ADA">TIDAK ADA</option>
													<?php }else{ ?>
														<option value="<?php echo $value->surat_ket_lulus; ?>"><?php echo $value->surat_ket_lulus; ?></option>
														<option value="">--</option>
														<option value="ADA">ADA</option>
														<option value="TIDAK ADA">TIDAK ADA</option>
													<?php } ?>
												</select>
											</div>

											<div class="form-group">
												<label class="input">Fotocopy Raport Semester 1-6 yang dilegalisir Kepala Sekolah <i class="asterik">*</i></label>
												<select class="form-control input" required="required" name="raport_semester">
													<?php if($value->fotocopy_raport_semester == null) { ?>
														<option value="">-Pilih SalahSatu-</option>
														<option value="ADA">ADA</option>
														<option value="TIDAK ADA">TIDAK ADA</option>
													<?php }else{ ?>
														<option value="<?php echo $value->fotocopy_raport_semester; ?>"><?php echo $value->fotocopy_raport_semester; ?></option>
														<option value="">--</option>
														<option value="ADA">ADA</option>
														<option value="TIDAK ADA">TIDAK ADA</option>
													<?php } ?>
												</select>
											</div>

											<div class="form-group">
												<label class="input">Fotocopy Ijazah yang diligalisir Kepala Sekolah <i class="asterik">*</i></label>
												<select class="form-control input" required="required" name="ijazah_legalisir">
													<?php if($value->fotocopy_ijazah == null) { ?>
														<option value="">-Pilih SalahSatu-</option>
														<option value="ADA">ADA</option>
														<option value="TIDAK ADA">TIDAK ADA</option>
													<?php }else{ ?>
														<option value="<?php echo $value->fotocopy_ijazah; ?>"><?php echo $value->fotocopy_ijazah; ?></option>
														<option value="">--</option>
														<option value="ADA">ADA</option>
														<option value="TIDAK ADA">TIDAK ADA</option>
													<?php } ?>
												</select>
											</div>

											<div class="form-group">
												<label class="input">Fotocopy Nilai Ujian Akhir Nasional yang dilegalisir Kepala Sekolah <i class="asterik">*</i></label>
												<select class="form-control input" required="required" name="fotocopy_nilai_ujian_un">
													<?php if($value->fotocopy_nilai_uan == null) { ?>
														<option value="">-Pilih SalahSatu-</option>
														<option value="ADA">ADA</option>
														<option value="TIDAK ADA">TIDAK ADA</option>
													<?php }else{ ?>
														<option value="<?php echo $value->fotocopy_nilai_uan; ?>"><?php echo $value->fotocopy_nilai_uan; ?></option>
														<option value="">--</option>
														<option value="ADA">ADA</option>
														<option value="TIDAK ADA">TIDAK ADA</option>
													<?php } ?>
												</select>
											</div>

											<div class="form-group">
												<label class="input">Surat Keterangan Prestasi dan Bukti Pendukung Prestasi yang dilegalisir Kepala Sekolah <i class="asterik">*</i></label>
												<select class="form-control input" required="required" name="keterangan_prestasi">
													<?php if($value->surat_ket_prestasi == null) { ?>
														<option value="">-Pilih SalahSatu-</option>
														<option value="ADA">ADA</option>
														<option value="TIDAK ADA">TIDAK ADA</option>
													<?php }else{ ?>
														<option value="<?php echo $value->surat_ket_prestasi; ?>"><?php echo $value->surat_ket_prestasi; ?></option>
														<option value="">--</option>
														<option value="ADA">ADA</option>
														<option value="TIDAK ADA">TIDAK ADA</option>
													<?php } ?>
												</select>
											</div>

											<div class="form-group">
												<label class="input">Surat Keterangan Penghasilan Ortu/Wali atau Surat Keterangan Tidak Mampu yang dikeluarkan Kepala Desa/Dusun/Instansi/Tokoh Masyarakat <i class="asterik">*</i></label>
												<select class="form-control input" required="required" name="keterangan_penghasilan_ortu_wali">
													<?php if($value->surat_ket_peng_ortu == null) { ?>
														<option value="">-Pilih SalahSatu-</option>
														<option value="ADA">ADA</option>
														<option value="TIDAK ADA">TIDAK ADA</option>
													<?php }else{ ?>
														<option value="<?php echo $value->surat_ket_peng_ortu; ?>"><?php echo $value->surat_ket_peng_ortu; ?></option>
														<option value="">--</option>
														<option value="ADA">ADA</option>
														<option value="TIDAK ADA">TIDAK ADA</option>
													<?php } ?>
												</select>
											</div>

											<div class="form-group">
												<label class="input">Fotocopy Kartu Keluarga atau Surat Keterangan Susunan Keluarga <i class="asterik">*</i></label>
												<select class="form-control input" required="required" name="fotocopy_kk">
													<?php if($value->fotocopy_kk == null) { ?>
														<option value="">-Pilih SalahSatu-</option>
														<option value="ADA">ADA</option>
														<option value="TIDAK ADA">TIDAK ADA</option>
													<?php }else{ ?>
														<option value="<?php echo $value->fotocopy_kk; ?>"><?php echo $value->fotocopy_kk; ?></option>
														<option value="">--</option>
														<option value="ADA">ADA</option>
														<option value="TIDAK ADA">TIDAK ADA</option>
													<?php } ?>
												</select>
											</div>

											<div class="form-group">
												<label class="input">Fotocopy Rekening Listrik Bulan Terakhir (bila tersedia listrik) <i class="asterik">*</i></label>
												<select class="form-control input" required="required" name="fotocopy_rek">
													<?php if($value->fotocopy_rek_listrik == null) { ?>
														<option value="">-Pilih SalahSatu-</option>
														<option value="ADA">ADA</option>
														<option value="TIDAK ADA">TIDAK ADA</option>
													<?php }else{ ?>
														<option value="<?php echo $value->fotocopy_rek_listrik; ?>"><?php echo $value->fotocopy_rek_listrik; ?></option>
														<option value="">--</option>
														<option value="ADA">ADA</option>
														<option value="TIDAK ADA">TIDAK ADA</option>
													<?php } ?>
												</select>
											</div>

											<div class="form-group">
												<label class="input">Fotocopy Bukti Pembayaran PBB Tahun Terakhir <i class="asterik">*</i></label>
												<select class="form-control input" required="required" name="fotocopy_bukti_pembayaran_pbb">
													<?php if($value->fotocopy_pbb == null) { ?>
														<option value="">-Pilih SalahSatu-</option>
														<option value="ADA">ADA</option>
														<option value="TIDAK ADA">TIDAK ADA</option>
													<?php }else{ ?>
														<option value="<?php echo $value->fotocopy_pbb; ?>"><?php echo $value->fotocopy_pbb; ?></option>
														<option value="">--</option>
														<option value="ADA">ADA</option>
														<option value="TIDAK ADA">TIDAK ADA</option>
													<?php } ?>
												</select>
											</div>

											<div class="form-group">
												<label class="input">Melengkapi data foto rumah dari 3(tiga) sudut <i class="asterik">*</i></label>
												<select class="form-control input" required="required" name="data_foto_rumah">
													<?php if($value->foto_rumah_tiga_sudut == null) { ?>
														<option value="">-Pilih SalahSatu-</option>
														<option value="ADA">ADA</option>
														<option value="TIDAK ADA">TIDAK ADA</option>
													<?php }else{ ?>
														<option value="<?php echo $value->foto_rumah_tiga_sudut; ?>"><?php echo $value->foto_rumah_tiga_sudut; ?></option>
														<option value="">--</option>
														<option value="ADA">ADA</option>
														<option value="TIDAK ADA">TIDAK ADA</option>
													<?php } ?>
												</select>
											</div>
										<!--div class="table-responsive">
											<table class="table">
												<tr class="form-group">
													<td style="width:200px;" class="input">Kartu Tes Pendaftaran Jalur <?php echo $value->jalur_pendaftaran; ?></td>
													<td>:</td>
													<td>
														<select class="form-control input" required="required" name="kartu_tes">
															<?php if($value->kartu_tes == null) {?>	
																<option value="">-Pilih SalahSatu-</option>
																<option value="ADA">ADA</option>
																<option value="TIDAK ADA">TIDAK ADA</option>
															<?php }else{ ?>
																<option value="<?php echo $value->kartu_tes; ?>"><?php echo $value->kartu_tes; ?></option>
																<option value="">--</option>
																<option value="ADA">ADA</option>
																<option value="TIDAK ADA">TIDAK ADA</option>
															<?php } ?>
														</select>
													</td>
													<td><i class="asterik">*</i></td>
												</tr>
												<?php } ?>

												<tr class="form-group">
													<td style="width:200px;" class="input">Formulir Pendaftaran Bidik Misi yang telah diisi</td>
													<td>:</td>
													<td>
														<select class="form-control input" required="required" name="formulir_pendaftaran">
															<?php if($value->formulir_pendaftaran == null) { ?>	
																<option value="">-Pilih SalahSatu-</option>
																<option value="ADA">ADA</option>
																<option value="TIDAK ADA">TIDAK ADA</option>
															<?php }else{ ?>
																<option value="<?php echo $value->formulir_pendaftaran; ?>"><?php echo $value->formulir_pendaftaran; ?></option>
																<option value="">--</option>
																<option value="ADA">ADA</option>
																<option value="TIDAK ADA">TIDAK ADA</option>
															<?php } ?>
														</select>
														<td><i class="asterik">*</i></td>
													</td>
												</tr>

												<tr class="form-group">
													<td style="width:200px;" class="input">Surat Keterangan Lulus dari Kepala Sekolah</td>
													<td>:</td>
													<td>
														<select class="form-control input" required="required" name="skl_dari_kepsek">
															<?php if($value->surat_ket_lulus == null) { ?>
																<option value="">-Pilih SalahSatu-</option>
																<option value="ADA">ADA</option>
																<option value="TIDAK ADA">TIDAK ADA</option>
															<?php }else{ ?>
																<option value="<?php echo $value->surat_ket_lulus; ?>"><?php echo $value->surat_ket_lulus; ?></option>
																<option value="">--</option>
																<option value="ADA">ADA</option>
																<option value="TIDAK ADA">TIDAK ADA</option>
															<?php } ?>
														</select>
													</td>
													<td><i class="asterik">*</i></td>
												</tr>

												<tr class="form-group">
													<td style="width:200px;" class="input">Fotocopy Raport Semester 1-6 yang dilegalisir Kepala Sekolah</td>
													<td>:</td>
													<td>
														<select class="form-control input" required="required" name="raport_semester">
															<?php if($value->fotocopy_raport_semester == null) { ?>
																<option value="">-Pilih SalahSatu-</option>
																<option value="ADA">ADA</option>
																<option value="TIDAK ADA">TIDAK ADA</option>
															<?php }else{ ?>
																<option value="<?php echo $value->fotocopy_raport_semester; ?>"><?php echo $value->fotocopy_raport_semester; ?></option>
																<option value="">--</option>
																<option value="ADA">ADA</option>
																<option value="TIDAK ADA">TIDAK ADA</option>
															<?php } ?>
														</select>
													</td>
													<td><i class="asterik">*</i></td>
												</tr>

												<tr class="form-group">
													<td style="width:200px;" class="input">Fotocopy Ijazah yang diligalisir Kepala Sekolah</td>
													<td>:</td>
													<td>
														<select class="form-control input" required="required" name="ijazah_legalisir">
															<?php if($value->fotocopy_ijazah == null) { ?>
																<option value="">-Pilih SalahSatu-</option>
																<option value="ADA">ADA</option>
																<option value="TIDAK ADA">TIDAK ADA</option>
															<?php }else{ ?>
																<option value="<?php echo $value->fotocopy_ijazah; ?>"><?php echo $value->fotocopy_ijazah; ?></option>
																<option value="">--</option>
																<option value="ADA">ADA</option>
																<option value="TIDAK ADA">TIDAK ADA</option>
															<?php } ?>
														</select>
													</td>
													<td><i class="asterik">*</i></td>
												</tr>

												<tr class="form-group">
													<td style="width:200px;" class="input">Fotocopy Nilai Ujian Akhir Nasional yang dilegalisir Kepala Sekolah</td>
													<td>:</td>
													<td>
														<select class="form-control input" required="required" name="fotocopy_nilai_ujian_un">
															<?php if($value->fotocopy_nilai_uan == null) { ?>
																<option value="">-Pilih SalahSatu-</option>
																<option value="ADA">ADA</option>
																<option value="TIDAK ADA">TIDAK ADA</option>
															<?php }else{ ?>
																<option value="<?php echo $value->fotocopy_nilai_uan; ?>"><?php echo $value->fotocopy_nilai_uan; ?></option>
																<option value="">--</option>
																<option value="ADA">ADA</option>
																<option value="TIDAK ADA">TIDAK ADA</option>
															<?php } ?>
														</select>
													</td>
													<td><i class="asterik">*</i></td>
												</tr>

												<tr class="form-group">
													<td style="width:200px;" class="input">Surat Keterangan Prestasi dan Bukti Pendukung Prestasi yang dilegalisir Kepala Sekolah</td>
													<td>:</td>
													<td>
														<select class="form-control input" required="required" name="keterangan_prestasi">
															<?php if($value->surat_ket_prestasi == null) { ?>
																<option value="">-Pilih SalahSatu-</option>
																<option value="ADA">ADA</option>
																<option value="TIDAK ADA">TIDAK ADA</option>
															<?php }else{ ?>
																<option value="<?php echo $value->surat_ket_prestasi; ?>"><?php echo $value->surat_ket_prestasi; ?></option>
																<option value="">--</option>
																<option value="ADA">ADA</option>
																<option value="TIDAK ADA">TIDAK ADA</option>
															<?php } ?>
														</select>
													</td>
													<td><i class="asterik">*</i></td>
												</tr>

												<tr class="form-group">
													<td style="width:200px;" class="input">Surat Keterangan Penghasilan Ortu/Wali atau Surat Keterangan Tidak Mampu yang dikeluarkan Kepala Desa/Dusun/Instansi/Tokoh Masyarakat</td>
													<td>:</td>
													<td>
														<select class="form-control input" required="required" name="keterangan_penghasilan_ortu_wali">
															<?php if($value->surat_ket_peng_ortu == null) { ?>
																<option value="">-Pilih SalahSatu-</option>
																<option value="ADA">ADA</option>
																<option value="TIDAK ADA">TIDAK ADA</option>
															<?php }else{ ?>
																<option value="<?php echo $value->surat_ket_peng_ortu; ?>"><?php echo $value->surat_ket_peng_ortu; ?></option>
																<option value="">--</option>
																<option value="ADA">ADA</option>
																<option value="TIDAK ADA">TIDAK ADA</option>
															<?php } ?>
														</select>
													</td>
													<td><i class="asterik">*</i></td>
												</tr>

												<tr class="form-group">
													<td style="width:200px;" class="input">Fotocopy Kartu Keluarga atau Surat Keterangan Susunan Keluarga</td>
													<td>:</td>
													<td>
														<select class="form-control input" required="required" name="fotocopy_kk">
															<?php if($value->fotocopy_kk == null) { ?>
																<option value="">-Pilih SalahSatu-</option>
																<option value="ADA">ADA</option>
																<option value="TIDAK ADA">TIDAK ADA</option>
															<?php }else{ ?>
																<option value="<?php echo $value->fotocopy_kk; ?>"><?php echo $value->fotocopy_kk; ?></option>
																<option value="">--</option>
																<option value="ADA">ADA</option>
																<option value="TIDAK ADA">TIDAK ADA</option>
															<?php } ?>
														</select>
													</td>
													<td><i class="asterik">*</i></td>
												</tr>

												<tr class="form-group">
													<td style="width:200px;" class="input">Fotocopy Rekening Listrik Bulan Terakhir (bila tersedia listrik)</td>
													<td>:</td>
													<td>
														<select class="form-control input" required="required" name="fotocopy_rek">
															<?php if($value->fotocopy_rek_listrik == null) { ?>
																<option value="">-Pilih SalahSatu-</option>
																<option value="ADA">ADA</option>
																<option value="TIDAK ADA">TIDAK ADA</option>
															<?php }else{ ?>
																<option value="<?php echo $value->fotocopy_rek_listrik; ?>"><?php echo $value->fotocopy_rek_listrik; ?></option>
																<option value="">--</option>
																<option value="ADA">ADA</option>
																<option value="TIDAK ADA">TIDAK ADA</option>
															<?php } ?>
														</select>
													</td>
													<td><i class="asterik">*</i></td>
												</tr>

												<tr class="form-group">
													<td style="width:200px;" class="input">Fotocopy Bukti Pembayaran PBB Tahun Terakhir</td>
													<td>:</td>
													<td>
														<select class="form-control input" required="required" name="fotocopy_bukti_pembayaran_pbb">
															<?php if($value->fotocopy_pbb == null) { ?>
																<option value="">-Pilih SalahSatu-</option>
																<option value="ADA">ADA</option>
																<option value="TIDAK ADA">TIDAK ADA</option>
															<?php }else{ ?>
																<option value="<?php echo $value->fotocopy_pbb; ?>"><?php echo $value->fotocopy_pbb; ?></option>
																<option value="">--</option>
																<option value="ADA">ADA</option>
																<option value="TIDAK ADA">TIDAK ADA</option>
															<?php } ?>
														</select>
													</td>
													<td><i class="asterik">*</i></td>
												</tr>

												<tr class="form-group">
													<td style="width:200px;" class="input">Melengkapi data foto rumah dari 3(tiga) sudut</td>
													<td>:</td>
													<td>
														<select class="form-control input" required="required" name="data_foto_rumah">
															<?php if($value->foto_rumah_tiga_sudut == null) { ?>
																<option value="">-Pilih SalahSatu-</option>
																<option value="ADA">ADA</option>
																<option value="TIDAK ADA">TIDAK ADA</option>
															<?php }else{ ?>
																<option value="<?php echo $value->foto_rumah_tiga_sudut; ?>"><?php echo $value->foto_rumah_tiga_sudut; ?></option>
																<option value="">--</option>
																<option value="ADA">ADA</option>
																<option value="TIDAK ADA">TIDAK ADA</option>
															<?php } ?>
														</select>
													</td>
													<td><i class="asterik">*</i></td>
												</tr>
											</table>
										</div-->
									</div>
									<div class="modal-footer">
										<button type="button" class="btn btn-default" data-dismiss="modal">Tutup</button>
										<button type="submit" class="btn btn-primary">Simpan</button>
									</div>
								</div>
							</div>
						</div>
					<div class="clear"></div>
					</form>
					<?php } ?>
					<!--End Modal Update Persyaratan Dokumen-->
				</div>
			</div>
		</div>
	</body>
	<div style="text-align: center;">	
		<?php
			$this->load->view('project_bidikmisi/footer/footer');
		?>
	</div>
</html>
