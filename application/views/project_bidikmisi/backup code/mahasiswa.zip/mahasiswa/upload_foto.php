<?php
	$this->load->view('project_bidikmisi/header/mahasiswa/header3_mhs');
	$this->load->view('project_bidikmisi/mahasiswa/navbar_mhs');
?>
<!DOCTYPE html>
<html>
	<body>
		<div class="container-fluid">
			<div class="">	
				<div class="row">
					<div class="notif notifikasi col-md-offset-8">
						<?php echo $this->session->flashdata('direct_error'); ?>
					</div>

					<div class="notif notifikasi col-md-offset-10">
						<?php echo $this->session->flashdata('direct_success'); ?>
					</div>
					
					<!--Sidebar-->
					<div class="col-md-3" style="padding-bottom: 40px;">
						<div class="sidebar-buat col-md-12 col-md-offset-1">
							<h3>Tahapan Bidikmisi</h3>
						</div>

						<div class="list-group col-md-12 col-md-offset-1">
							<a href="<?=base_url('C_mhs'); ?>" class="list-group-item input active">Tahap 1 Upload Foto</a>
							<a href="<?=base_url('C_mhs/step2'); ?>" class="list-group-item input">Tahap 2 Identitas Diri</a>
							<a href="<?=base_url('C_mhs/step3'); ?>" class="list-group-item input">Tahap 3 Data Ortu</a>
							<a href="<?=base_url('C_mhs/step4'); ?>" class="list-group-item input">Tahap 4 Data Kondisi Rumah</a>
							<a href="<?=base_url('C_mhs/step5'); ?>" class="list-group-item input">Tahap 5 Data Sekolah</a>
							<a href="<?=base_url('C_mhs/step6'); ?>" class="list-group-item input">Tahap 6 Data Pesantren</a>
							<a href="<?=base_url('C_mhs/step7'); ?>" class="list-group-item input">Tahap 7 Keterampilan</a>
							<a href="<?=base_url('C_mhs/step8'); ?>" class="list-group-item input">Tahap 8 Upload Dokumen Pendukung</a>
							<a href="<?=base_url('C_mhs/step9'); ?>" class="list-group-item input">Tahap 9 Persyaratan Dokumen</a>
							<a href="<?=base_url('C_mhs/step10'); ?>" class="list-group-item input">Tahap 10 Verifikasi Data</a>	    
						</div>
					</div>
					<!--End Sidebar-->

					<div class="col-md-4" style="text-align: center;">
						<div class="col-md-offset-2">
    						<h3>RULE Tahap 1 (Upload Foto)</h3>
    						<div class="penting">
    							<p>Maksimal Foto 1 MB</p>
    							<p>Format Foto : JPG, JPEG, dan PNG</p>
    							<p>Foto Harus Resmi</p>
    						</div>
    
    						<p>Jika ingin ganti fotonya, silahkan klik tombol telusuri/browse</p>
    						<p>Jika sudah Upload Silahkan klik Tombol Lanjut</p>
    					</div>
					</div>

					<div class="col-md-4">
						<div class="tahap">
							<h3>Tahap 1</h3>
						</div>

						<form action="<?=base_url('C_mhs/direct1'); ?>" method="POST" enctype="multipart/form-data">
							<!--Upload Foto-->
							<div id="judul-upload-foto">
								<h2><b><u>Upload Foto</u></b></h2>
							</div>


							<div class="form-group">
								<center>
								<?php foreach($data_diri as $value) { ?>
								<tr>
									<td><img style="width: 130px; height: 130px;" src="<?php echo base_url(). 'assets/foto_mhs/'.$value->upload_foto; ?>"></td>
								</tr>
								<?php } ?>
									<div id="input-foto" style="margin-top: 20px;">
										<input type="file" name="foto" required="required">
									</div>		
								</center>
							</div>

							<div class="clear"></div>

							<!--button-->
							<div class="button-all" style="text-align: center;">
								<div class="col-md-12 col-md-offset-2">
									<button class="btn btn-primary" value="Simpan" type="submit">
										<i class="fa fa-check-circle-o"></i>
										Simpan
									</button>
									<a href="<?=base_url('C_mhs/step2'); ?>" class="btn btn-info">Lanjut &raquo;</a>
								</div>
							</div>
							<!--End button-->
						</form>
					</div>
					<!--End Upload Foto-->

					<div class="clear"></div>
				</div>
			</div>
		</div>
	</body>
	
	<div style="text-align: center;">
	<?php
		$this->load->view('project_bidikmisi/footer/footer');
	?>
	</div>
</html>
