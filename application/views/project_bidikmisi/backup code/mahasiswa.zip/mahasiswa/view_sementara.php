<?php
    $this->load->view('project_bidikmisi/header/mahasiswa/header3_mhs');
    $this->load->view('project_bidikmisi/mahasiswa/navbar_mhs');
    $this->load->view('project_bidikmisi/mahasiswa/rule_view_sementara');
?>
<!DOCTYPE html>
<html>
<body>
	<script type="text/javascript">
			//check keterangan
			function proses(){
				var keterangan=document.getElementById("pekerjaan_ayah").value;

				if(keterangan=="1"){
					document.getElementById("keterangan_tukang").style.display = "none";
					document.getElementById("keterangan_wiraswasta").style.display = "none";
					document.getElementById("keterangan_pns").style.display = "block";
				}else if(keterangan=="2"){
					document.getElementById("keterangan_pns").style.display = "none";
					document.getElementById("keterangan_tukang").style.display = "none";
					document.getElementById("keterangan_wiraswasta").style.display = "block";
				}else if(keterangan=="3"){
					document.getElementById("keterangan_pns").style.display = "none";
					document.getElementById("keterangan_wiraswasta").style.display = "none";
					document.getElementById("keterangan_tukang").style.display = "block";
				}else{
					document.getElementById("keterangan_pns").style.display = "none";
					document.getElementById("keterangan_wiraswasta").style.display = "none";
					document.getElementById("keterangan_tukang").style.display = "none";
				}
			}

			function proses2(){
				var keterangan=document.getElementById("pekerjaan_ibu").value;

				if(keterangan=="PNS/TNI/POLRI"){
					document.getElementById("keterangan_wiraswasta2").style.display = "none";
					document.getElementById("keterangan_pns2").style.display = "block";
				}else if(keterangan=="Wiraswasta"){
					document.getElementById("keterangan_pns2").style.display = "none";
					document.getElementById("keterangan_wiraswasta2").style.display = "block";
				}else{
					document.getElementById("keterangan_pns2").style.display = "none";
					document.getElementById("keterangan_wiraswasta2").style.display = "none";
				}
			}
			//End check keterangan
			
			//cek pondok
			function cek_pondok(){
				var kode = document.getElementById('mondok').checked;
				var elems = document.getElementsByClassName('list_pondok');
				if ( kode == false ) {
					for(var i = 0; i < elems.length; i++) {
				          /*elems[i].style.backgroundColor = "#DCDCDC";
				          elems[i].disabled = true; 
				          elems[i].required = false;*/
				          elems[i].style.display = "none";
				          elems[i].disabled = true; 
				          elems[i].required = false;
				      }
				  } else {
				  	for(var i = 0; i < elems.length; i++) {
				          /*elems[i].style.backgroundColor = '#FFFFFF';
				          elems[i].disabled = false;
				          elems[i].required = true;*/
				          elems[i].style.display = "block"; 
				          elems[i].disabled = false;
				          elems[i].required = true;
				      }
				  }
				}
			//End cek pondok
		</script>

		<div class="container">
			<div class="row">
				<div class="col-md-6">
					<div class="sidebar-buat col-md-12 col-md-offset-1">
						<h3>Tahapan Bidikmisi</h3>
					</div>

					<div class="list-group col-md-12 col-md-offset-1">
						<a href="<?=base_url('C_mhs'); ?>" class="list-group-item input">Tahap 1 Upload Foto</a>
						<a href="<?=base_url('C_mhs/step2'); ?>" class="list-group-item input">Tahap 2 Identitas Diri</a>
						<a href="<?=base_url('C_mhs/step3'); ?>" class="list-group-item input">Tahap 3 Data Ortu</a>
						<a href="<?=base_url('C_mhs/step4'); ?>" class="list-group-item input">Tahap 4 Data Kondisi Rumah</a>
						<a href="<?=base_url('C_mhs/step5'); ?>" class="list-group-item input">Tahap 5 Data Sekolah</a>
						<a href="<?=base_url('C_mhs/step6'); ?>" class="list-group-item input">Tahap 6 Data Pesantren</a>
						<a href="<?=base_url('C_mhs/step7'); ?>" class="list-group-item input">Tahap 7 Keterampilan</a>
						<a href="<?=base_url('C_mhs/step8'); ?>" class="list-group-item input">Tahap 8 Upload Dokumen Pendukung</a>
						<a href="<?=base_url('C_mhs/step9'); ?>" class="list-group-item input">Tahap 9 Persyaratan Dokumen</a>
						<a href="<?=base_url('C_mhs/step10'); ?>" class="list-group-item input active">Tahap 10 Verifikasi Data</a>    
					</div>
					<!--div class="col-md-12">
						<div class="list-group" style="margin-top:40px;">
							<button class="btn btn-primary list-group-item input" data-toggle="modal" data-target="#edit-identitas-diri" type="submit">
								<i class="glyphicon glyphicon-edit"></i>
								Edit Identitas Diri
							</button>
							<button class="btn btn-primary list-group-item input" data-toggle="modal" data-target="#edit-data-ortu" type="submit">
								<i class="glyphicon glyphicon-edit"></i>
								Edit Data Ortu
							</button>
							<button class="btn btn-primary list-group-item input" data-toggle="modal" data-target="#edit-data-rumah" type="submit">
								<i class="glyphicon glyphicon-edit"></i>
								Edit Data Kondisi Rumah
							</button>
							<button class="btn btn-primary list-group-item input" data-toggle="modal" data-target="#edit-data-sekolah" type="submit">
								<i class="glyphicon glyphicon-edit"></i>
								Edit Data Sekolah
							</button>
							<button class="btn btn-primary list-group-item input" data-toggle="modal" data-target="#edit-data-pesantren" type="submit">
								<i class="glyphicon glyphicon-edit"></i>
								Edit Data Pesantren
							</button>
							<button class="btn btn-primary list-group-item input" data-toggle="modal" data-target="#edit-data-keterampilan" type="submit">
								<i class="glyphicon glyphicon-edit"></i>
								Edit Data Keterampilan
							</button>
							<button class="btn btn-primary list-group-item input" data-toggle="modal" data-target="#edit-data-dokumen" type="submit">
								<i class="glyphicon glyphicon-edit"></i>
								Edit Data Dokumen Pendukung
							</button>
							<button class="btn btn-primary list-group-item input" data-toggle="modal" data-target="#edit-data-persyaratan-dokumen" type="submit">
								<i class="glyphicon glyphicon-edit"></i>
								Edit Data Persyaratan Dokumen
							</button>
						</div>
					</div-->
				</div>
				
				<div class="col-md-6">
					<?php foreach($data as $value) { ?>
						
						<!--Identitas Diri-->
						<div id="identitas-diri" style="margin-top:40px; margin-right: 30px;">
							<h2><b><u>Identitas Diri</u></b></h2>
						</div>

						<div class="col-md-offset-4 col-md-8" style="margin-bottom: 30px;">
							<tr>
								<td><img style="width: 130px; height: 130px;" src="<?php echo base_url(). 'assets/foto_mhs/'.$value->upload_foto; ?>"></td>
							</tr>
						</div>

						<div class="table-responsive col-md-offset-2 col-md-9 input">	
							<table class="table">
								<tr>
									<td>Nama Lengkap</td>
									<td>:</td>
									<td><?php echo $value->nama_mahasiswa; ?></td>
								</tr>

								<tr>
									<td>Jenis Kelamin</td>
									<td>:</td>
									<td><?php echo $value->jenis_kelamin; ?></td>
								</tr>

								<tr>
									<td>Tempat Lahir</td>
									<td>:</td>
									<td><?php echo $value->tempat_lahir; ?></td>
								</tr>

								<tr>
									<td>Tanggal Lahir</td>
									<td>:</td>
									<td><?php echo $value->tanggal_lahir; ?></td>
								</tr>

								<tr>
									<td>Jalur Pendaftaran</td>
									<td>:</td>
									<td><?php echo $value->jalur_pendaftaran; ?></td>
								</tr>

								<tr>
									<td>Kategori UKT</td>
									<td>:</td>
									<td><?php echo $value->kategori; ?></td>
								</tr>

								<tr>
									<td>Fakultas</td>
									<td>:</td>
									<td><?php
									if($value->fakultas == '0' || $value->fakultas == null){
										echo "-";
									}

									foreach($fakultas as $x_fak){
										if($value->fakultas == $x_fak->id_fakultas){
											echo $x_fak->nama_fakultas;
										}
									}
									?></td>
								</tr>

								<tr>
									<td>Jurusan</td>
									<td>:</td>
									<td><?php
									if($value->jurusan == '0' || $value->jurusan == null){
										echo "-";
									}

									foreach($jurusan as $x_jur){
										if($value->jurusan == $x_jur->id_jurusan){
											echo $x_jur->nama_jurusan;
										}
									}
									?></td>
								</tr>

								<tr>
									<td>Status Pernikahan</td>
									<td>:</td>
									<td><?php echo $value->status_pernikahan; ?></td>
								</tr>

								<tr>
									<td>Asal Provinsi</td>
									<td>:</td>
									<td><?php 
									if($value->asal_provinsi == '0' || $value->asal_provinsi == null){
										echo "-";
									}

									foreach ($propinsi as $x_prov) {
										if($value->asal_provinsi == $x_prov->id_propinsi){
											echo $x_prov->nama_propinsi;
										}
									}
									?></td>
								</tr>

								<tr>
									<td>Asal Kab/Kota</td>
									<td>:</td>
									<td><?php 
									if($value->asal_kab_kota == '0' || $value->asal_kab_kota == null){
										echo "-";
									}

									foreach($data_kab_kota as $x_kab_kota){
										if($value->asal_kab_kota == $x_kab_kota->id_kota){
											echo $x_kab_kota->nama_kota;
										}
									}
									?></td>
								</tr>

								<tr>
									<td>No Telp</td>
									<td>:</td>
									<td><?php echo $value->no_telp; ?></td>
								</tr>

								<tr>
									<td>Email</td>
									<td>:</td>
									<td><?php echo $value->email; ?></td>
								</tr>

								<tr>
									<td>Alamat</td>
									<td>:</td>
									<td><?php echo $value->alamat; ?></td>
								</tr>
								
								<tr>
									<td>RT</td>
									<td>:</td>
									<td><?php echo $value->rt_2; ?></td>
									<td><b class="asterik">*</b></td>
								</tr>

								<tr>
									<td>RW</td>
									<td>:</td>
									<td><?php echo $value->rw_2; ?></td>
									<td><b class="asterik">*</b></td>
								</tr>

								<tr>
									<td>Kecamatan</td>
									<td>:</td>
									<td><?php echo $value->kecamatan_2; ?></td>
									<td><b class="asterik">*</b></td>
								</tr>

								<tr>
									<td>Kelurahan</td>
									<td>:</td>
									<td><?php echo $value->kelurahan_2; ?></td>
									<td><b class="asterik">*</b></td>
								</tr>

								<tr>
									<td>Kode Pos</td>
									<td>:</td>
									<td><?php echo $value->kode_pos; ?></td>
								</tr>
								<!--End Identitas Diri-->
							</table>
						</div>

						<!--Data Ortu-->
						<div id="data-ortu" class="col-md-12">
							<h2><b><u>Data Orang Tua</u></b></h2>
						</div>
						
						<div class="table-responsive col-md-offset-2 col-md-9 input">
							<table class="table">
								<tr>
									<td>Nama Ayah</td>
									<td>:</td>
									<td><?php echo $value->nama_ayah; ?> 
									<?php 
									if($value->almarhum == '40'){
										echo "(Almarhum)";
									}else if($value->almarhum == null || $value->almarhum == '0'){
										echo "";
									}
									?></td>
								</tr>

								<tr>
									<td>Nama Ibu</td>
									<td>:</td>
									<td><?php echo $value->nama_ibu; ?> 
									<?php 
									if($value->almarhumah == '20'){
										echo "(Almarhumah)";
									}else if($value->almarhumah == null || $value->almarhumah == '0'){
										echo "";
									}
									?></td>
								</tr>

								<tr>
									<td>Alamat Ortu</td>
									<td>:</td>
									<td><?php echo $value->alamat_ortu; ?></td>
								</tr>
								
								<tr>
    								<td>Kecamatan Ortu</td>
    								<td>:</td>
    								<td><?php echo $value->kecamatan_3; ?></td>
    								<td><b class="asterik">*</b></td>
    							</tr>
    							
    							<tr>
    								<td>Kelurahan Ortu</td>
    								<td>:</td>
    								<td><?php echo $value->kelurahan_3; ?></td>
    								<td><b class="asterik">*</b></td>
    							</tr>
								
								<tr>
    								<td>RT Ortu</td>
    								<td>:</td>
    								<td><?php echo $value->rt_3; ?></td>
    								<td><b class="asterik">*</b></td>
    							</tr>
    
    							<tr>
    								<td>RW Ortu</td>
    								<td>:</td>
    								<td><?php echo $value->rw_3; ?></td>
    								<td><b class="asterik">*</b></td>
    							</tr>


								<tr>
									<td>Provinsi Ortu</td>
									<td>:</td>
									<td><?php 
									foreach ($propinsi as $x_prov) {
										if($value->provinsi_ortu == $x_prov->id_propinsi){
											echo $x_prov->nama_propinsi;
										}
									}
									?></td>
								</tr>

								<tr>
									<td>Kab/Kota Ortu</td>
									<td>:</td>
									<td><?php 
									foreach($data_kab_kota as $x_kab_kota){
										if($value->kab_kota_ortu == $x_kab_kota->id_kota){
											echo $x_kab_kota->nama_kota;
										}
									}
									?></td>
								</tr>

								<tr>
									<td>No Telp/Hp Ortu</td>
									<td>:</td>
									<td><?php echo $value->no_telp_ortu; ?></td>
								</tr>

								<tr>
									<td>Kode Pos Ortu</td>
									<td>:</td>
									<td><?php echo $value->kode_pos_ortu; ?></td>
								</tr>

								<tr>
									<td>Pekerjaan Ayah</td>
									<td>:</td>
									<td><?php 
									if($value->pekerjaan_ayah == '1'){
										echo "PNS/TNI/POLRI";
										?>	
										<tr>
											<td>Keterangan PNS/TNI/POLRI</td>
											<td>:</td>
											<td><?php echo $value->ket_pns_tni_polri_ayah; ?></td>
										</tr>
										<?php		
									}else if($value->pekerjaan_ayah == '2'){
										echo "Wiraswasta";
										?>
										<tr>
											<td>Keterangan Wiraswasta</td>
											<td>:</td>
											<td><?php echo $value->ket_wiraswasta_ayah; ?></td>
										</tr>
										<?php
									}else if($value->pekerjaan_ayah == '3'){
										echo "Tukang";
										?>
										<tr>
											<td>Keterangan Tukang</td>
											<td>:</td>
											<td><?php echo $value->ket_tukang_ayah; ?></td>
										</tr>
										<?php
									}else if($value->pekerjaan_ayah == '4'){
										echo "Buruh Tani/Petani";
									}

									?></td>
								</tr>

								<tr>
									<td>Pekerjaan Ibu</td>
									<td>:</td>
									<td><?php 
									if($value->pekerjaan_ibu == 'PNS/TNI/POLRI'){
										echo "PNS/TNI/POLRI";
										?>	
										<tr>
											<td>Keterangan PNS/TNI/POLRI</td>
											<td>:</td>
											<td><?php echo $value->ket_pns_tni_polri_ibu; ?></td>
										</tr>
										<?php		
									}else if($value->pekerjaan_ibu == 'Wiraswasta'){
										echo "Wiraswasta";
										?>
										<tr>
											<td>Keterangan Wiraswasta</td>
											<td>:</td>
											<td><?php echo $value->ket_wiraswasta_ibu; ?></td>
										</tr>
										<?php
									}else if($value->pekerjaan_ibu == 'Ibu Rumah Tangga'){
										echo "Ibu Rumah Tangga";
									}else if($value->pekerjaan_ibu == 'Buruh Tani/Petani'){
										echo "Buruh Tani/Petani";
									}
									?></td>
								</tr>

								<tr>
									<td>Pendidikan Ayah</td>
									<td>:</td>
									<td><?php 
									if($value->pendidikan_ayah == '1'){
										echo "Lebih dari Sarjana";
									}else if($value->pendidikan_ayah == '2'){
										echo "SLTA/Sederajat";
									}else if($value->pendidikan_ayah == '3'){
										echo "SLTP/Sederajat";
									}else if($value->pendidikan_ayah == '4'){
										echo "SD/Tidak Tamat SD";
									}
									?></td>
								</tr>

								<tr>
									<td>Pendidikan Ibu</td>
									<td>:</td>
									<td><?php echo $value->pendidikan_ibu; ?></td>
								</tr>

								<tr>
									<td>Penghasilan Ayah</td>
									<td>:</td>
									<td><?php
									if($value->penghasilan_ayah == '1'){
										echo "Lebih dari 1.200.000";
									}else if($value->penghasilan_ayah == '2'){
										echo "1.000.001 - 1.200.000";
									}else if($value->penghasilan_ayah == '3'){
										echo "500.001 - 750.000";
									}else if($value->penghasilan_ayah == '4'){
										echo "Kurang dari 500.000";
									}else{
										echo "Data Tidak Ada";
									}
									?></td>
								</tr>

								<tr>
									<td>Nominal Penghasilan Ayah</td>
									<td>:</td>
									<td><?php echo 'Rp '.number_format($value->nominal_peng_ayah); ?></td>
								</tr>

								<tr>
									<td>Penghasilan Ibu</td>
									<td>:</td>
									<td><?php
									if($value->penghasilan_ibu == '1'){
										echo "Lebih dari 1.200.000";
									}else if($value->penghasilan_ibu == '2'){
										echo "1.000.001 - 1.200.000";
									}else if($value->penghasilan_ibu == '3'){
										echo "500.001 - 750.000";
									}else if($value->penghasilan_ibu == '4'){
										echo "Kurang dari 500.000";
									}else{
										echo "Data Tidak Ada";
									}
									?></td>
								</tr>

								<tr>
									<td>Nominal Penghasilan Ibu</td>
									<td>:</td>
									<td><?php echo 'Rp '.number_format($value->nominal_peng_ibu); ?></td>
								</tr>

								<tr>
									<td>Jumlah Tanggungan</td>
									<td>:</td>
									<td><?php 
									if($value->jumlah_saudara_kandung_tang_ortu == '1'){
										echo "Kurang dari 5 Orang";
									}else if($value->jumlah_saudara_kandung_tang_ortu == '2'){
										echo "5 - 6 Orang";
									}else if($value->jumlah_saudara_kandung_tang_ortu == '3'){
										echo "7 - 8 Orang";
									}else if($value->jumlah_saudara_kandung_tang_ortu == '4'){
										echo "Lebih dari 8 Orang";
									}else{
										echo "Data Tidak Ada";
									}
									?></td>
								</tr>
							</table>
						</div>
						<!--End Data Ortu-->

						<!--Data Rumah-->
						<div id="data-kondisi-rumah" class="col-md-12">
							<h2><b><u>Data Kondisi Rumah</u></b></h2>
						</div>

						<div class="table-responsive col-md-offset-2 col-md-9 input">
							<table class="table">
								<tr>
									<td>Luas Rumah</td>
									<td>:</td>
									<td><?php 
									if($value->luas_rumah == '1'){
										echo "Lebih dari 120 M Persegi";
									}else if($value->luas_rumah == '2'){
										echo "81 - 120 M Persegi";
									}else if($value->luas_rumah == '3'){
										echo "41 - 80 M Persegi";
									}else if($value->luas_rumah == '4'){
										echo "Kurang dari 40 M Persegi";
									}else{
										echo "Data Tidak Ada";
									}
									?></td>
								</tr>

								<tr>
									<td>Pajak Bumi Bangunan</td>
									<td>:</td>
									<td><?php
									if($value->pbb == '1'){
										echo "Lebih dari 100.000";
									}else if($value->pbb == '2'){
										echo "76.000 - 100.000";
									}else if($value->pbb == '3'){
										echo "26.000 - 75.000";
									}else if($value->pbb == '4'){
										echo "Kurang dari 25.000";
									}else{
										echo "Data tidak Ada";
									}
									?></td>
								</tr>

								<tr>
									<td>Rekening Listrik/Bulan</td>
									<td>:</td>
									<td><?php
									if($value->rek_listrik_per_bulan == '1'){
										echo "Lebih dari 100.000";
									}else if($value->rek_listrik_per_bulan == '2'){
										echo "76.000 - 100.000";
									}else if($value->rek_listrik_per_bulan == '3'){
										echo "26.000 - 75.000";
									}else if($value->rek_listrik_per_bulan == '4'){
										echo "Kurang dari 25.000";
									}else{
										echo "Data Tidak ada";
									}
									?></td>
								</tr>
							</table>
						</div>
						<!--End Data Rumah-->

						<!--Data Sekolah-->
						<div id="data-sekolah" class="col-md-12">
							<h2><b><u>Data Sekolah</u></b></h2>
						</div>

						<div class="table-responsive col-md-offset-2 col-md-9 input">
							<table class="table">
								<tr>
									<td>Alamat Sekolah</td>
									<td>:</td>
									<td><?php echo $value->alamat_sekolah; ?></td>
								</tr>
								
								<tr>
    								<td>Kecamatan Sekolah</td>
    								<td>:</td>
    								<td><?php echo $value->kecamatan_5; ?></td>
    								<td><i class="asterik">*</i></td>
    							</tr>
    							
    							<tr>
    								<td>Kelurahan Sekolah</td>
    								<td>:</td>
    								<td><?php echo $value->kelurahan_5; ?></td>
    								<td><i class="asterik">*</i></td>
    							</tr>
								
								<tr>
    								<td>RT Sekolah</td>
    								<td>:</td>
    								<td><?php echo $value->rt_5; ?></td>
    								<td><i class="asterik">*</i></td>
    							</tr>
    
    							<tr>
    								<td>RW Sekolah</td>
    								<td>:</td>
    								<td><?php echo $value->rw_5; ?></td>
    								<td><i class="asterik">*</i></td>
    							</tr>

								<tr>
									<td>Provinsi Sekolah</td>
									<td>:</td>
									<td><?php 
									if($value->prov_sekolah == '0' || $value->prov_sekolah == null){
										echo "-";
									}

									foreach ($propinsi as $x_prov) {
										if($value->prov_sekolah == $x_prov->id_propinsi){
											echo $x_prov->nama_propinsi;
										}
									}
									?></td>
								</tr>

								<tr>
									<td>Kab/Kota Sekolah</td>
									<td>:</td>
									<td><?php
									if($value->kab_kota_sekolah == '0' || $value->kab_kota_sekolah == null){
										echo "-";
									}

									foreach($data_kab_kota as $x_kab_kota){
										if($value->kab_kota_sekolah == $x_kab_kota->id_kota){
											echo $x_kab_kota->nama_kota;
										}
									}
									?></td>
								</tr>

								<tr>
									<td>Nama Sekolah</td>
									<td>:</td>
									<td><?php echo $value->nama_sekolah; ?></td>
								</tr>

								<tr>
									<td>Tahun Lulus</td>
									<td>:</td>
									<td><?php echo $value->tahun_lulus; ?></td>
								</tr>

								<tr>
									<td>Jurusan Sekolah</td>
									<td>:</td>
									<td><?php echo $value->jurusan_sekolah; ?></td>
								</tr>

								<tr>
									<td>Rerata Nilai UN</td>
									<td>:</td>
									<td><?php 
									if($value->rerata_nilai_un == '1'){
										echo "Kurang dari 7.00";
									}else if($value->rerata_nilai_un == '2'){
										echo "7.00 - 8.00";
									}else if($value->rerata_nilai_un == '3'){
										echo "8.10 - 9.00";
									}else if($value->rerata_nilai_un == '4'){
										echo "Lebih dari 9.00";
									}else{
										echo "Data Tidak Ada";
									}
									?></td>
								</tr>

								<tr>
									<td>Rerata Nilai Raport</td>
									<td>:</td>
									<td><?php 
									if($value->rerata_nilai_raport == '1'){
										echo "Kurang dari 7.00";
									}else if($value->rerata_nilai_raport == '2'){
										echo "7.00 - 8.00";
									}else if($value->rerata_nilai_raport == '3'){
										echo "8.10 - 9.00";
									}else if($value->rerata_nilai_raport == '4'){
										echo "Lebih dari 9.00";
									}else{
										echo "Data Tidak Ada";
									}
									?></td>
								</tr>

								<tr>
									<td>Prestasi Akademik</td>
									<td>:</td>
									<td><?php
									if($value->prestasi_akademik == '0'){
										echo "Tidak Ada";
									}else if($value->prestasi_akademik == '1'){
										echo "Tingkat Lokal";
									}else if($value->prestasi_akademik == '2'){
										echo "Tingkat Regional";
									}else if($value->prestasi_akademik == '3'){
										echo "Tingkat Nasional";
									}else if($value->prestasi_akademik == '4'){
										echo "Tingkat Internasional";
									}else{
										echo "Data Tidak Ada";
									}
									?></td>
								</tr>

								<tr>
									<td>Prestasi Non Akademik</td>
									<td>:</td>
									<td><?php
									if($value->prestasi_non_akademik == '0'){
										echo "Tidak Ada";
									}else if($value->prestasi_non_akademik == '1'){
										echo "Tingkat Lokal";
									}else if($value->prestasi_non_akademik == '2'){
										echo "Tingkat Regional";
									}else if($value->prestasi_non_akademik == '3'){
										echo "Tingkat Nasional";
									}else if($value->prestasi_non_akademik == '4'){
										echo "Tingkat Internasional";
									}else{
										echo "Data Tidak Ada";
									}
									?></td>
								</tr>
							</table>
						</div>
						<!--End Data Sekolah-->

						<!--Data Pesantren-->
						<div id="data-pesantren" class="col-md-12">
							<h2><b><u>Data Pesantren</u></b></h2>
						</div>

						<div class="table-responsive col-md-offset-2 col-md-9 input">
							<table class="table">
								<?php
								if($value->mondok == "Ya"){
									?>
									<tr>
										<td>Pernah Mondok</td>
										<td>:</td>
										<td><?php echo $value->mondok; ?></td>
									</tr>
									
									<tr>
										<td>Nama Ponpes</td>
										<td>:</td>
										<td><?php
										if($value->nama_ponpes == null){
											echo "-";
										}else if($value->nama_ponpes != null){
											echo $value->nama_ponpes;
										}else{
											echo "Data Tidak ada";
										}
										?></td>
									</tr>

									<tr>
										<td>Alamat Ponpes</td>
										<td>:</td>
										<td><?php
										if($value->alamat_ponpes == null){
											echo "-";
										}else if($value->alamat_ponpes != null){
											echo $value->alamat_ponpes;
										}else{
											echo "Data Tidak ada";
										}
										?></td>
									</tr>
									
									<tr>
    									<td>Kecamatan Ponpes</td>
    									<td>:</td>
    									<td><?php
    										if($value->kecamatan_6 == null){
    											echo "";
    										}else if($value->kecamatan_6 != null){
    											echo $value->kecamatan_6;
    										}
    									?></td>
    								</tr>
    							
    								<tr>
    									<td>Kelurahan Ponpes</td>
    									<td>:</td>
    									<td><?php
    										if($value->kelurahan_6 == null){
    											echo "";
    										}else if($value->kelurahan_6 != null){
    											echo $value->kelurahan_6;
    										}
    									?></td>
    								</tr>
									
									<tr>
    									<td>RT Ponpes</td>
    									<td>:</td>
    									<td><?php
    										if($value->rt_6 == null){
    											echo "";
    										}else if($value->rt_6 != null){
    											echo $value->rt_6;
    										}
    									?></td>
    								</tr>
    
    								<tr>
    									<td>RW Ponpes</td>
    									<td>:</td>
    									<td><?php
    										if($value->rw_6 == null){
    											echo "";
    										}else if($value->rw_6 != null){
    											echo $value->rw_6;
    										}
    									?></td>
    								</tr>

									<tr>
										<td>Provinsi Ponpes</td>
										<td>:</td>
										<td><?php 
										if($value->prov_ponpes == '0' || $value->prov_ponpes == null){
											echo "-";
										}

										foreach ($propinsi as $x_prov) {
											if($value->prov_ponpes == $x_prov->id_propinsi){
												echo $x_prov->nama_propinsi;
											}
										}
										?></td>
									</tr>

									<tr>
										<td>Kab/Kota Ponpes</td>
										<td>:</td>
										<td><?php 
										if($value->kab_kota_ponpes == '0' || $value->kab_kota_ponpes == null){
											echo "-";
										}

										foreach($data_kab_kota as $x_kab_kota){
											if($value->kab_kota_ponpes == $x_kab_kota->id_kota){
												echo $x_kab_kota->nama_kota;
											}
										}
										?></td>
									</tr>

									<tr>
										<td>Kode Pos Ponpes</td>
										<td>:</td>
										<td><?php echo $value->kode_pos_ponpes; ?></td>
									</tr>

									<tr>
										<td>Lama Belajar</td>
										<td>:</td>
										<td><?php echo $value->lama_belajar; ?> Tahun</td>	
									</tr>
								<?php }else if($value->mondok == "Tidak" || $value->mondok == null) { ?>
									<tr>
										<td>Pernah Mondok</td>
										<td>:</td>
										<td><?php echo $value->mondok; ?></td>
									</tr>

									<tr>
										<td>Nama Ponpes</td>
										<td>:</td>
										<td><?php
										if($value->nama_ponpes == null){
											echo "-";
										}else{
											echo "Data Tidak ada";
										}
										?></td>
									</tr>

									<tr>
										<td>Alamat Ponpes</td>
										<td>:</td>
										<td><?php
										if($value->alamat_ponpes == null){
											echo "-";
										}else{
											echo "Data Tidak ada";
										}
										?></td>
									</tr>
									
									<tr>
    									<td>RT Ponpes</td>
    									<td>:</td>
    									<td><?php
    										if($value->rt_6 == null){
    											echo "";
    										}
    									?></td>
    								</tr>
    
    								<tr>
    									<td>RW Ponpes</td>
    									<td>:</td>
    									<td><?php
    										if($value->rw_6 == null){
    											echo "";
    										}
    									?></td>
    								</tr>
    
    								<tr>
    									<td>Kelurahan Ponpes</td>
    									<td>:</td>
    									<td><?php
    										if($value->kelurahan_6 == null){
    											echo "";
    										}
    									?></td>
    								</tr>
    
    								<tr>
    									<td>Kecamatan Ponpes</td>
    									<td>:</td>
    									<td><?php
    										if($value->kecamatan_6 == null){
    											echo "";
    										}
    									?></td>
    								</tr>

									<tr>
										<td>Provinsi Ponpes</td>
										<td>:</td>
										<td><?php 
										if($value->prov_ponpes == '0' || $value->prov_ponpes == null){
											echo "-";
										}
										?></td>
									</tr>

									<tr>
										<td>Kab/Kota Ponpes</td>
										<td>:</td>
										<td><?php 
										if($value->kab_kota_ponpes == '0' || $value->kab_kota_ponpes == null){
											echo "-";
										}
										?></td>
									</tr>

									<tr>
										<td>Kode Pos Ponpes</td>
										<td>:</td>
										<td><?php
										if($value->kode_pos_ponpes == '0' || $value->kode_pos_ponpes == null){
											echo "-";
										}
										?></td>
									</tr>

									<tr>
										<td>Lama Belajar</td>
										<td>:</td>
										<td><?php 
										if($value->lama_belajar == '0' || $value->lama_belajar == null){
											echo "-";
										}
										?> &nbsp;&nbsp;Tahun</td>	
									</tr>
								<?php }?>
							</table>
						</div>					
						<!--End Data Pesantren-->

						<!--Keterampilan-->
						<div id="keterampilan" class="col-md-12">
							<h2><b><u>Keterampilan</u></b></h2>
						</div>

						<div class="table-responsive col-md-offset-2 col-md-9 input">
							<table class="table">
								<tr>
									<td>Kemampuan Bahasa Arab</td>
									<td>:</td>
									<td><?php echo $value->kem_bhs_arab; ?></td>
								</tr>

								<tr>
									<td>Kemampuan Bahasa Inggris</td>
									<td>:</td>
									<td><?php echo $value->kem_bhs_inggris; ?></td>
								</tr>

								<tr>
									<td>Kemampuan Komputer</td>
									<td>:</td>
									<td><?php echo $value->kem_komputer; ?></td>
								</tr>
							</table>
						</div>
						<!--End Keterampilan-->

						<!--Dokumen Pendukung-->
						<div id="upload-dokumen-pendukung" class="col-md-12">
							<h2><b><u>Dokumen Pendukung</u></b></h2>
						</div>

						<div class="table-responsive col-md-offset-2 col-md-9 input">
							<table class="table">
								<tr>
									<td>Foto Rumah Bagian Depan</td>
									<td>:</td>
									<td><button class="btn btn-primary" data-toggle="modal" data-target="#view-foto-rumah-bagian-depan" type="submit">Lihat</button></td>
								</tr>

								<tr>
									<td>Foto Rumah Bagian Kiri</td>
									<td>:</td>
									<td><button class="btn btn-primary" data-toggle="modal" data-target="#view-foto-rumah-bagian-kiri" type="submit">Lihat</button></td>
								</tr>

								<tr>
									<td>Foto Rumah Bagian Kanan</td>
									<td>:</td>
									<td><button class="btn btn-primary" data-toggle="modal" data-target="#view-foto-rumah-bagian-kanan" type="submit">Lihat</button></td>
								</tr>

								<tr>
									<td>Foto PBB</td>
									<td>:</td>
									<td><button class="btn btn-primary" data-toggle="modal" data-target="#view-foto-pbb" type="submit">Lihat</button></td>
								</tr>

								<tr>
									<td>Foto Rekening Listrik</td>
									<td>:</td>
									<td><button class="btn btn-primary" data-toggle="modal" data-target="#view-foto-rek-listrik" type="submit">Lihat</button></td>
								</tr>

								<tr>
									<td>Semua Foto Dokumen</td>
									<td>:</td>
									<td><button class="btn btn-primary" data-toggle="modal" data-target="#view-foto-semua" type="submit">Lihat</button></td>
								</tr>
							</table>
						</div>
						<!--End Dokumen Pendukung-->

						<!--Persyaratan Dokumen-->
						<div id="persyaratan-dokumen" class="col-md-12">
							<h2><b><u>Persyaratan Dokumen</u></b></h2>
						</div>

						<div class="table-responsive col-md-offset-2 col-md-9 input">
							<table class="table">
								<tr>
									<td>Kartu Peserta Jalur <?php echo $value->jalur_pendaftaran.' '.date('Y'); ?></td>
									<td>:</td>
									<td><?php echo $value->kartu_tes; ?></td>
								</tr>

								<tr>
									<td>Formulir Pedaftaran Bidik Misi yang telah diisi</td>
									<td>:</td>
									<td><?php echo $value->formulir_pendaftaran; ?></td>
								</tr>

								<tr>
									<td>Surat Keterangan Lulus dari Kepela Sekolah</td>
									<td>:</td>
									<td><?php echo $value->surat_ket_lulus; ?></td>
								</tr>

								<tr>
									<td>Fotocopy Raport Semester 1-6 yang dilegalisir Kepala Sekolah</td>
									<td>:</td>
									<td><?php echo $value->fotocopy_raport_semester; ?></td>
								</tr>

								<tr>
									<td>Fotocopy Ijazah yang dilegalisir Kepala Sekolah</td>
									<td>:</td>
									<td><?php echo $value->fotocopy_ijazah; ?></td>
								</tr>

								<tr>
									<td>Fotocopy Nilai Ujian Akhir Nasional yang dilegalisir Kepala Sekolah</td>
									<td>:</td>
									<td><?php echo $value->fotocopy_nilai_uan; ?></td>
								</tr>

								<tr>
									<td>Surat Keterangan Prestasi dan Bukti Pendukung Prestasi yang dilegalisir Kepala Sekolah</td>
									<td>:</td>
									<td><?php echo $value->surat_ket_prestasi; ?></td>
								</tr>

								<tr>
									<td>Surat Keterangan Penghasilan Ortu/Wali atau Surat Keterangan Tidak Mampu yang dikeluarkan Kepala Desa/Dusun/Instansi/Tokoh Masyarakat</td>
									<td>:</td>
									<td><?php echo $value->surat_ket_peng_ortu; ?></td>
								</tr>

								<tr>
									<td>Fotocopy Kartu Keluarga atau Surat Keterangan Susunan Keluarga</td>
									<td>:</td>
									<td><?php echo $value->fotocopy_kk; ?></td>
								</tr>

								<tr>
									<td>Fotocopy Rekening Listrik Bulan Terakhir (bila tersedia listrik)</td>
									<td>:</td>
									<td><?php echo $value->fotocopy_rek_listrik; ?></td>
								</tr>

								<tr>
									<td>Fotocopy Bukti Pembayaran PBB Tahun Terakhir</td>
									<td>:</td>
									<td><?php echo $value->fotocopy_pbb; ?></td>
								</tr>

								<tr>
									<td>Melengkapi data foto rumah dari 3(tiga) sudut</td>
									<td>:</td>
									<td><?php echo $value->foto_rumah_tiga_sudut; ?></td>
								</tr>
								<!--End Persyaratan Dokumen-->
							<?php } ?>

						</table>
					</div>

					<div class="button-all">
						<div class="col-md-12 col-md-offset-2">
							<a href="<?=base_url('C_mhs/step9'); ?>" class="btn btn-info">
								<i class="fa fa-check-circle-o"></i>
								&laquo; Kembali
							</a>
							
							<button class="btn btn-primary col-md-offset-4" data-toggle="modal" data-target="#confirm" type="submit" >
								<i class="glyphicon glyphicon-ok"></i>	
								Verifikasi
							</button>
						</div>
					</div>
				</div>
			</div>
		</div>

		<!--Modal Confirm Verifikasi-->
		<div class="modal fade" id="confirm" role="dialog">
			<div class="modal-dialog">
				<div class="modal-content">
					<div class="modal-header">
						<button type="button" class="close" data-dismiss="modal">&times;</button>
						<h4 class="modal-title">Anda yakin dengan Data anda ?</h4>
					</div>

					<form role="form" method="POST" action="<?=base_url('C_mhs/step11'); ?>">
						<div class="modal-footer">
							<button type="submit" class="btn btn-primary">Ya</button>
							<button type="button" class="btn btn-default" data-dismiss="modal">Tidak</button>
						</div>
					</form>
				</div>
			</div>
		</div>
		<!--End Modal Confirm Verifikasi-->

		<!--View Foto Rumah Depan-->
		<div id="view-foto-rumah-bagian-depan" class="modal fade" role="dialog">
			<div class="modal-dialog">
				<div class="modal-content">
					<div class="modal-header">
						<button type="button" class="close" data-dismiss="modal">&times;</button>
						<h4 class="modal-title">Foto Rumah Bagian Depan <?php echo $value->nama_mahasiswa; ?></h4>
					</div>

					<div class="modal-body">
						<div class="embed-responsive embed-responsive-4by3">
							<img class="embed-responsive-item" src="<?=base_url().'assets/foto_dokumen/'.$value->upload_foto_rumah_depan; ?>">
						</div>
					</div>

					<div class="modal-footer">
						<button type="button" class="btn btn-default" data-dismiss="modal">Tutup</button>
					</div>
				</div>
			</div>
		</div>
		<!--End View Foto Rumah Depan-->

		<!--View Foto Rumah Kiri-->
		<div id="view-foto-rumah-bagian-kiri" class="modal fade" role="dialog">
			<div class="modal-dialog">
				<div class="modal-content">
					<div class="modal-header">
						<button type="button" class="close" data-dismiss="modal">&times;</button>
						<h4 class="modal-title">Foto Rumah Bagian Kiri <?php echo $value->nama_mahasiswa; ?></h4>
					</div>

					<div class="modal-body">
						<div class="embed-responsive embed-responsive-4by3">
							<img class="embed-responsive-item" src="<?=base_url().'assets/foto_dokumen/'.$value->upload_foto_rumah_kiri; ?>">
						</div>
					</div>

					<div class="modal-footer">
						<button type="button" class="btn btn-default" data-dismiss="modal">Tutup</button>
					</div>
				</div>
			</div>
		</div>
		<!--End View Foto Rumah Kiri-->

		<!--View Foto Rumah Kanan-->
		<div id="view-foto-rumah-bagian-kanan" class="modal fade" role="dialog">
			<div class="modal-dialog">
				<div class="modal-content">
					<div class="modal-header">
						<button type="button" class="close" data-dismiss="modal">&times;</button>
						<h4 class="modal-title">Foto Rumah Bagian Kanan <?php echo $value->nama_mahasiswa; ?></h4>
					</div>

					<div class="modal-body">
						<div class="embed-responsive embed-responsive-4by3">
							<img class="embed-responsive-item" src="<?=base_url().'assets/foto_dokumen/'.$value->upload_foto_rumah_kanan; ?>">
						</div>
					</div>

					<div class="modal-footer">
						<button type="button" class="btn btn-default" data-dismiss="modal">Tutup</button>
					</div>
				</div>
			</div>
		</div>
		<!--End View Foto Rumah Kanan-->

		<!--View foto Pbb-->
		<div id="view-foto-pbb" class="modal fade" role="dialog">
			<div class="modal-dialog">
				<div class="modal-content">
					<div class="modal-header">
						<button type="button" class="close" data-dismiss="modal">&times;</button>
						<h4 class="modal-title">Foto PBB <?php echo $value->nama_mahasiswa; ?></h4>
					</div>

					<div class="modal-body">
						<div class="embed-responsive embed-responsive-4by3">
							<img class="embed-responsive-item" src="<?=base_url().'assets/foto_dokumen/'.$value->upload_foto_pbb; ?>">
						</div>
					</div>

					<div class="modal-footer">
						<button type="button" class="btn btn-default" data-dismiss="modal">Tutup</button>
					</div>
				</div>
			</div>
		</div>
		<!--End View foto Pbb-->

		<!--View Foto Rekening Listrik-->
		<div id="view-foto-rek-listrik" class="modal fade" role="dialog">
			<div class="modal-dialog">
				<div class="modal-content">
					<div class="modal-header">
						<button type="button" class="close" data-dismiss="modal">&times;</button>
						<h4 class="modal-title">Foto Rekening Listrik <?php echo $value->nama_mahasiswa; ?></h4>
					</div>

					<div class="modal-body">
						<div class="embed-responsive embed-responsive-4by3">
							<img class="embed-responsive-item" src="<?=base_url().'assets/foto_dokumen/'.$value->upload_foto_rek_listrik; ?>">
						</div>
					</div>

					<div class="modal-footer">
						<button type="button" class="btn btn-default" data-dismiss="modal">Tutup</button>
					</div>
				</div>
			</div>
		</div>
		<!--End View Foto Rekening Listrik-->

		<!--View All Foto-->
		<div id="view-foto-semua" class="modal fade" role="dialog">
			<div class="modal-dialog">
				<div class="modal-content">
					<div class="modal-header">
						<button type="button" class="close" data-dismiss="modal">&times;</button>
						<h4 class="modal-title">Foto Semua Dokumen <?php echo $value->nama_mahasiswa; ?></h4>
					</div>

					<div class="modal-body">
						<label>Foto Rumah Bagian Depan</label>
						<div class="embed-responsive embed-responsive-4by3">
							<img class="embed-responsive-item" src="<?=base_url().'assets/foto_dokumen/'.$value->upload_foto_rumah_depan; ?>">
						</div>

						<br/>

						<label>Foto Rumah Bagian Kiri</label>
						<div class="embed-responsive embed-responsive-4by3">
							<img class="embed-responsive-item" src="<?=base_url().'assets/foto_dokumen/'.$value->upload_foto_rumah_kiri; ?>">
						</div>

						<br/>

						<label>Foto Rumah Bagian Kanan</label>
						<div class="embed-responsive embed-responsive-4by3">
							<img class="embed-responsive-item" src="<?=base_url().'assets/foto_dokumen/'.$value->upload_foto_rumah_kanan; ?>">
						</div>

						<br/>

						<label>Foto PBB</label>
						<div class="embed-responsive embed-responsive-4by3">
							<img class="embed-responsive-item" src="<?=base_url().'assets/foto_dokumen/'.$value->upload_foto_pbb; ?>">
						</div>

						<br/>

						<label>Foto Rekening Listrik</label>
						<div class="embed-responsive embed-responsive-4by3">
							<img class="embed-responsive-item" src="<?=base_url().'assets/foto_dokumen/'.$value->upload_foto_rek_listrik; ?>">
						</div>
					</div>

					<div class="modal-footer">
						<button type="button" class="btn btn-default" data-dismiss="modal">Tutup</button>
					</div>
				</div>
			</div>
		</div>
		<!--End View All Foto-->

		<!--Modal Edit Identitas Diri-->
		<?php foreach ($data as $modal_value) { ?>
			<form action="<?=base_url('C_mhs/update_modal1'); ?>" method="POST" enctype="multipart/form-data">
				<div id="edit-identitas-diri" class="modal fade" role="dialog">
					<div class="modal-dialog">
						<div class="modal-content">
							<div class="modal-header">
								<button type="button" class="close" data-dismiss="modal">&times;</button>
								<h4 class="modal-title">Edit Identitas Diri</h4>
							</div>


							<div class="modal-body">
								<div class="form-group">
									<label>Nama Lengkap</label>
									<input class="form-control" type="text" name="nama_lengkap" placeholder="Nama Lengkap Anda" required="required" value="<?php echo $modal_value->nama_mahasiswa; ?>">
								</div>

								<div class="form-group">
									<img style="width: 130px; height: 130px;" src="<?php echo base_url(). 'assets/foto_mhs/'.$value->upload_foto; ?>">
									<input type="file" name="foto">
								</div>

								<div class="form-group">
									<label>Jenis Kelamin</label>
									<select name="jenis_kelamin" class="form-control" required="required">
										<option value="">-Pilih SalahSatu-</option>
										<option value="Laki - Laki">Laki - Laki</option>
										<option value="Perempuan">Perempuan</option>
									</select>
								</div>

								<div class="form-group">
									<label>Tempat Lahir</label>
									<input type="text" class="form-control" required="required" value="<?php echo $modal_value->tempat_lahir; ?>" name="tempat_lahir">
								</div>

								<div class="input-group date" data-provide="datepicker">
									<label>Tanggal Lahir</label>
									<input value="<?php echo $modal_value->tanggal_lahir; ?>" required="required" class="form-control" type="text" id="tanggal" name="tgl_lahir" placeholder="Tanggal Lahir Anda">
								</div>

								<br>

								<div class="form-group">
									<label>Jalur Pendaftaran</label>
									<select name="jalur_pendaftaran" class="form-control" required="required" value="">
										<option value="">-Pilih SalahSatu-</option>
										<option value="MANDIRI-TERTULIS">MANDIRI-TERTULIS</option>
										<option value="SNMPTN">SNMPTN</option>
										<option value="MANDIRI-PRESTASI">MANDIRI-PRESTASI</option>
										<option value="SPAN-PTKIN">SPAN-PTKIN</option>
										<option value="UM-PTKIN">UM-PTKIN</option>
										<option value="SBMPTN">SBMPTN</option>
									</select>
								</div>

								<div class="form-group">
									<label>Kategori UKT</label>
									<select name="kategori" class="form-control" required="required" value="">
										<option value="">-Pilih SalahSatu-</option>
										<option value="K1">K1</option>
										<option value="K2">K2</option>
										<option value="K3">K3</option>
										<option value="K4">K4</option>
										<option value="K5">K5</option>
										<option value="K6">K6</option>
										<option value="K7">K7</option>
									</select>
								</div>

								<div class="form-group">
									<label>Fakultas</label>
									<select class="form-control" required="required" name="fakultas" id="fakultas2">

										<option value="">-Pilih SalahSatu-</option>
										<?php
									//melakukan looping dari fungsi index di controller C_mhs
										foreach($fakultas as $data){
											echo "<option value='".$data->id_fakultas."'>".$data->nama_fakultas."</option>";
										}
										?>
									</select>
								</div>

								<div class="form-group">
									<label>Jurusan</label>
									<select class="form-control" required="required" name="jurusan" id="jurusan2">
										<option value="">-Pilih SalahSatu-</option>	
									</select>
									<div id="loading7">
										<img src="<?=base_url('assets/img/loading.gif'); ?>"><small>Loading..</small>
									</div>
								</div>

								<div class="form-group">
									<label>Status Pernikahan</label>
									<select name="status_pernikahan" class="form-control" required="required">
										<option value="">-Pilih SalahSatu-</option>
										<option value="Menikah">Menikah</option>
										<option value="Belum Menikah">Belum Menikah</option>
									</select>
								</div>

								<div class="form-group">
									<label>Asal Provinsi</label>
									<select class="form-control" name="asal_provinsi" id="provinsi6" required="required">
										<option value="">-Pilih SalahSatu</option>
										<?php
										foreach($propinsi as $data){
											echo "<option value='".$data->id_propinsi."'>".$data->nama_propinsi."</option>";
										}
										?>
									</select>
								</div>

								<div class="form-group">
									<label>Asal Kab/Kota</label>
									<select class="form-control" required="required" name="asal_kab_kota" id="kota6">
										<option value="">-Pilih SalahSatu-</option>
									</select>
									<div id="loading6">
										<img src="<?=base_url('assets/img/loading.gif'); ?>"><small>Loading..</small>
									</div>
								</div>

								<div class="form-group">
									<label>No Telp</label>
									<input class="form-control" type="text" name="no_telp" value="<?php echo $modal_value->no_telp; ?>" required="required" placeholder="contoh : 0881-0093-3388">
								</div>

								<div class="form-group">
									<label>Email</label>
									<input type="email" class="form-control" name="email" value="<?php echo $modal_value->email; ?>" required="required" placholder="Email Anda">
								</div>

								<div class="form-group">
									<label>Alamat</label>
									<textarea type="text" class="form-control" name="alamat" required="required" placeholder="Alamat Anda"><?php echo $modal_value->alamat; ?></textarea>
								</div>

								<div class="form-group">
									<label>Kode Pos</label>
									<input type="text" class="form-control" name="kode_pos" required="required" placeholder="Kode Pos Anda" value="<?php echo $modal_value->kode_pos; ?>">
								</div>
							</div>


							<div class="modal-footer">
								<button type="button" class="btn btn-default" data-dismiss="modal">Tutup</button>
								<button type="submit" class="btn btn-primary">Simpan</button>
							</div>
						</div>
					</div>
				</div>
			</form>
			<!--End Modal Edit Identitas Diri-->

			<!--Modal Edit Data Ortu-->
			<form action="<?=base_url('C_mhs/update_modal2'); ?>" method="POST" enctype="multipart/form-data">
				<div id="edit-data-ortu" class="modal fade" role="dialog">
					<div class="modal-dialog">
						<div class="modal-content">
							<div class="modal-header">
								<button type="button" class="close" data-dismiss="modal">&times;</button>
								<h4 class="modal-title">Edit Data Ortu</h4>
							</div>

							<div class="modal-body">
								<div class="form-group">
									<label>Nama Ayah</label>
									<table>
										<tr>
											<td><input class="form-control" type="text" name="nama_ayah" placeholder="Nama Ayah Anda" required="required" value="<?php echo $modal_value->nama_ayah; ?>"></td>
											<td>&nbsp;&nbsp;&nbsp;&nbsp;<input type="checkbox" value="40" name="almarhum">&nbsp;&nbsp;Almarhum</td>
										</tr>
									</table>
								</div>

								<div class="form-group">
									<label>Nama Ibu</label>
									<table>
										<tr>
											<td><input class="form-control" type="text" name="nama_ibu" placeholder="Nama Ibu Anda" required="required" value="<?php echo $modal_value->nama_ibu; ?>"></td>
											<td>&nbsp;&nbsp;&nbsp;&nbsp;<input type="checkbox" value="20" name="almarhumah">&nbsp;&nbsp;Almarhumah</td>
										</tr>
									</table>
								</div>

								<div class="form-group">
									<label>Alamat Ortu</label>
									<textarea class="form-control" type="text" name="alamat_ortu" placeholder="Alamat Ortu Anda" required="required"><?php echo $modal_value->alamat_ortu; ?></textarea>
								</div>

								<div class="form-group">
									<label>Provinsi Ortu</label>
									<select class="form-control" required="required" name="asal_provinsi_ortu" id="provinsi7">
										<option value="">-Pilih SalahSatu-</option>
										<?php
									//melakukan looping dari fungsi index di controller C_mhs
										foreach($propinsi as $data){
											echo "<option value='".$data->id_propinsi."'>".$data->nama_propinsi."</option>";
										}
										?>
									</select>
								</div>

								<div class="form-group">
									<label>Kab/Kota Ortu</label>
									<select class="form-control" required="required" name="kab_kota_ortu" id="kota7">
										<option value="">-Pilih SalahSatu-</option>
									</select>
									<div id="loading8">
										<img src="<?=base_url('assets/img/loading.gif'); ?>"><small>Loading..</small>
									</div>
								</div>

								<div class="form-group">
									<label>Kode Pos Ortu</label>
									<input class="form-control" value="<?php echo $modal_value->kode_pos_ortu; ?>" type="text" name="kode_pos_ortu" placeholder="Kode Pos Ortu Anda">
								</div>

								<div class="form-group">
									<label>No Telp/Hp Ortu</label>
									<input value="<?php echo $modal_value->no_telp_ortu; ?>" class="form-control" type="text" name="no_telp_ortu" required="required" placeholder="Contoh : 0883-2239-3343">
								</div>

								<div class="form-group">
									<label>Pekerjaan Ayah</label>
									<select class="form-control" id="pekerjaan_ayah" onchange="proses()" required="required" name="pekerjaan_ayah">
										<option value="">-Pilih SalahSatu-</option>
										<option value="1">PNS/TNI/POLRI</option>
										<option value="2">Wiraswasta</option>
										<option value="3">Tukang</option>
										<option value="4">Buruh Tani/Petani</option>
									</select>
								</div>

								<div class="form-group" id="keterangan_pns" style="display: none;">
									<label>Keterangan PNS/TNI/POLRI</label>
									<textarea class="form-control" type="text" name="pns_tni_polri_ayah" placeholder="Keterangan PNS/TNI/POLRI Ayah"><?php echo $modal_value->ket_pns_tni_polri_ayah; ?></textarea>
								</div>

								<div class="form-group" id="keterangan_wiraswasta" style="display: none;">
									<label>Keterangan Wiraswasta</label>
									<textarea class="form-control" type="text" name="wiraswasta_ayah" placeholder="Keterangan Wiraswasta Ayah"><?php echo $modal_value->ket_wiraswasta_ayah; ?></textarea>
								</div>

								<div class="form-group" id="keterangan_tukang" style="display: none;">
									<label>Keterangan Tukang</label>
									<textarea class="form-control" type="text" name="tukang_ayah" placeholder="Keterangan Tukang Ayah"><?php echo $modal_value->ket_tukang_ayah; ?></textarea>
								</div>

								<div class="form-group">
									<label>Pekerjaan Ibu</label>
									<select class="form-control" id="pekerjaan_ibu" onchange="proses2()" required="required" name="pekerjaan_ibu">
										<option value="">-Pilih SalahSatu-</option>
										<option value="PNS/TNI/POLRI">PNS/TNI/POLRI</option>
										<option value="Wiraswasta">Wiraswasta</option>
										<option value="Ibu Rumah Tangga">Ibu Rumah Tangga</option>
										<option value="Buruh Tani/Petani">Buruh Tani/Petani</option>
									</select>
								</div>

								<div class="form-group" id="keterangan_pns2" style="display: none;">
									<label>Keterangan PNS/TNI/POLRI</label>
									<textarea class="form-control" type="text" name="pns_tni_polri_ibu" placeholder="Keterangan PNS/TNI/POLRI Ibu"><?php echo $modal_value->ket_pns_tni_polri_ibu; ?></textarea>
								</div>

								<div class="form-group" id="keterangan_wiraswasta2" style="display: none;">
									<label>Keterangan Wiraswasta</label>
									<textarea class="form-control" type="text" name="wiraswasta_ibu" placeholder="Keterangan Wiraswasta Ibu"><?php echo $modal_value->ket_wiraswasta_ibu; ?></textarea>
								</div>

								<div class="form-group">
									<label>Pendidikan Ayah</label>
									<select class="form-control" required="required" name="pendidikan_ayah">
										<option value="">-Pilih SalahSatu-</option>
										<option value="1">>Sarjana</option>
										<option value="2">SLTA/Sederajat</option>
										<option value="3">SLTP/Sederajat</option>
										<option value="4">SD/Tidak Sekolah</option>
									</select>
								</div>

								<div class="form-group">
									<label>Pendidikan Ibu</label>
									<select required="required" name="pendidikan_ibu" class="form-control">
										<option value="">-Pilih SalahSatu-</option>
										<option value=">Sarjana">>Sarjana</option>
										<option value="SLTA/Sederajat">SLTA/Sederajat</option>
										<option value="SLTP/Sederajat">SLTP/Sederajat</option>
										<option value="SD/Tidak Sekolah">SD/Tidak Sekolah</option>
									</select>
								</div>

								<div class="form-group">
									<label>Penghasilan Ayah</label>
									<select class="form-control" required="required" name="penghasilan_ayah">
										<option value="">-Pilih SalahSatu-</option>
										<option value="1">1.001.000 s/d 1.200.000</option>
										<option value="2">751.000 s/d 1.000.000</option>
										<option value="3">501.000 s/d 750.000</option>
										<option value="4">< 500.000</option>
									</select>
								</div>

								<div class="form-group">
									<label>Nominal Penghasilan Ayah</label>
									<input class="form-control" value="<?php echo $modal_value->nominal_peng_ayah; ?>" type="number" min="0" name="nominal_penghasilan_ayah" placeholder="Contoh : 1000000">
								</div>

								<div class="form-group">
									<label>Penghasilan Ibu</label>
									<select class="form-control" required="required" name="penghasilan_ibu">
										<option value="">-Pilih SalahSatu-</option>
										<option value="1">1.001.000 s/d 1.200.000</option>
										<option value="2">751.000 s/d 1.000.000</option>
										<option value="3">501.000 s/d 750.000</option>
										<option value="4">< 500.000</option>
									</select>
								</div>

								<div class="form-group">
									<label>Nomminal Penghasilan Ibu</label>
									<input class="form-control" value="<?php echo $modal_value->nominal_peng_ibu; ?>" type="number" min="0" name="nominal_penghasilan_ibu" placeholder="Contoh : 1000000">
								</div>

								<div class="form-group">
									<label>Jumlah Tanggungan Ortu</label>
									<select class="form-control" required="required" name="saudara_kandung">
										<option value="">-Pilih SalahSatu-</option>
										<option value="1">< 3 Orang</option>
										<option value="2">4 - 6 Orang</option>
										<option value="3">7 - 8 Orang</option>
										<option value="4">> 8 Orang</option>
									</select>
								</div>
							</div>

							<div class="modal-footer">
								<button type="button" class="btn btn-default" data-dismiss="modal">Tutup</button>
								<button type="submit" class="btn btn-primary">Simpan</button>
							</div>
						</div>
					</div>
				</div>
			</form>
			<!--End Modal Edit Data Ortu-->

			<!--Modal Edit Data Rumah-->
			<form action="<?=base_url('C_mhs/update_modal3'); ?>" method="POST" enctype="multipart/form-data">
				<div id="edit-data-rumah" class="modal fade" role="dialog">
					<div class="modal-dialog">
						<div class="modal-content">
							<div class="modal-header">
								<button type="button" class="close" data-dismiss="modal">&times;</button>
								<h4 class="modal-title">Edit Data Kondisi Rumah</h4>
							</div>

							<div class="modal-body">
								<div class="form-group">
									<label>Luas Rumah</label>
									<select class="form-control" required="required" name="luas_rumah">
										<option value="">-Pilih SalahSatu-</option>
										<option value="1">> 120 Meter Persegi</option>
										<option value="2">81 - 120 Meter Persegi</option>
										<option value="3">41 - 80 Meter Persegi</option>
										<option value="4">< 40 Meter Persegi</option>
									</select>
								</div>

								<div class="form-group">
									<label>Pajak Bumi Bangunan (PBB)</label>
									<select class="form-control" required="required" name="pbb">
										<option value="">-Pilih SalahSatu-</option>
										<option value="1">> 100.000</option>
										<option value="2">76.000 - 100.000</option>
										<option value="3">26.000 - 75.000</option>
										<option value="4">< 25.000</option>
									</select>
								</div>

								<div class="form-group">
									<label>Rekening Listrik PerBulan</label>
									<select class="form-control" required="required" name="rek_listrik_per_bulan">
										<option value="">-Pilih SalahSatu-</option>
										<option value="1">> 100.000</option>
										<option value="2">76.000 - 100.000</option>
										<option value="3">26.000 - 75.000</option>
										<option value="4">< 25.000</option>
									</select>
								</div>
							</div>

							<div class="modal-footer">
								<button type="button" class="btn btn-default" data-dismiss="modal">Tutup</button>
								<button type="submit" class="btn btn-primary">Simpan</button>
							</div>
						</div>
					</div>
				</div>
			</form>
			<!--End Modal Edit Luas Rumah-->

			<!--Modal Edit Data Sekolah-->
			<form action="<?=base_url('C_mhs/update_modal4'); ?>" method="POST" enctype="multipart/form-data">
				<div id="edit-data-sekolah" class="modal fade" role="dialog">
					<div class="modal-dialog">
						<div class="modal-content">
							<div class="modal-header">
								<button type="button" class="close" data-dismiss="modal">&times;</button>
								<h4 class="modal-title">Edit Data Sekolah</h4>
							</div>

							<div class="modal-body">
								<div class="form-group">
									<label>Alamat Sekolah</label>
									<textarea class="form-control" type="text" name="alamat_sekolah" placeholder="Alamat Sekolah Anda" required="required"><?php echo $modal_value->alamat_sekolah; ?></textarea>
								</div>

								<div class="form-group">
									<label>Provinsi Sekolah</label>
									<select class="form-control" required="required" name="provinsi_sekolah" id="provinsi8">
										<option value="">-Pilih SalahSatu-</option>
										<?php
									//melakukan looping dari fungsi index di controller C_mhs
										foreach($propinsi as $data){
											echo "<option value='".$data->id_propinsi."'>".$data->nama_propinsi."</option>";
										}
										?>
									</select>
								</div>

								<div class="form-group">
									<label>Kab/Kota Sekolah</label>
									<select class="form-control" style="font-family: 'Arial'; font-size: 13px; " required="required" name="kab_kota_sekolah" id="kota8">
										<option value="">-Pilih SalahSatu-</option>
									</select>

									<div id="loading9">
										<img src="<?=base_url('assets/img/loading.gif'); ?>"><small>Loading..</small>
									</div>
								</div>

								<div class="form-group">
									<label>Nama Sekolah</label>
									<textarea class="form-control" type="text" name="nama_sekolah" placeholder="Nama Sekolah Anda" required="required"><?php echo $modal_value->nama_sekolah; ?></textarea>
								</div>

								<div class="form-group">
									<label>Tahun Lulus</label>
									<select class="form-control" required="required" name="tahun_lulus">
										<option value="">-Pilih SalahSatu-</option>
										<option value="2018">2018</option>
										<option value="2019">2019</option>
									</select>
								</div>

								<div class="form-group">
									<label>Jurusan Sekolah</label>
									<select class="form-control" required="required" name="jurusan_sekolah">
										<option value="">-Pilih SalahSatu-</option>
										<option value="IPA">IPA</option>
										<option value="IPS">IPS</option>
										<option value="Bahasa">Bahasa</option>
										<option value="Teknik">Teknik</option>
										<option value="Pertanian">Pertanian</option>
										<option value="Ekonomi">Ekonomi</option>
										<option value="Seni">Seni</option>
										<option value="Pariwisata">Pariwisata</option>
										<option value="Agama">Agama</option>
										<option value="Lain - Lain">Lain - Lain</option>
									</select>
								</div>

								<div class="form-group">
									<label>Rerata Nilai UN</label>
									<select class="form-control" required="required" name="rerata_nilai_un">
										<option value="">-Pilih SalahSatu-</option>
										<option value="1">< 7.00</option>
										<option value="2">7.00 - 8.00</option>
										<option value="3">8.10 - 9.00</option>
										<option value="4">> 9.00</option>
									</select>
								</div>

								<div class="form-group">
									<label>Rerata Nilai Raport</label>
									<select class="form-control" required="required" name="rerata_nilai_raport">
										<option value="">-Pilih SalahSatu-</option>
										<option value="1">< 7.00</option>
										<option value="2">7.00 - 8.00</option>
										<option value="3">8.10 - 9.00</option>
										<option value="4">> 9.00</option>
									</select>
								</div>

								<div class="form-group">
									<label>Prestasi Akademik</label>
									<select class="form-control" required="required" name="prestasi_akademik">
										<option value="">-Pilih SalahSatu-</option>
										<option value="0">Tidak Ada Prestasi</option>
										<option value="1">Tingkat Lokal</option>
										<option value="2">Tingkat Regional</option>
										<option value="3">Tingkat Nasional</option>
										<option value="4">Tingkat Internasional</option>
									</select>
								</div>

								<div class="form-group">
									<label>Prestasi Non Akademik</label>
									<select class="form-control" required="required" name="prestasi_non_akademik">
										<option value="">-Pilih SalahSatu-</option>
										<option value="0">Tidak Ada Prestasi</option>
										<option value="1">Tingkat Lokal</option>
										<option value="2">Tingkat Regional</option>
										<option value="3">Tingkat Nasional</option>
										<option value="4">Tingkat Internasional</option>
									</select>
								</div>
							</div>

							<div class="modal-footer">
								<button type="button" class="btn btn-default" data-dismiss="modal">Tutup</button>
								<button type="submit" class="btn btn-primary">Simpan</button>
							</div>
						</div>
					</div>
				</div>
			</form>
			<!--End Modal Edit Data Sekolah-->

			<!--Modal Edit Data Pesantren-->
			<form action="<?=base_url('C_mhs/update_modal5'); ?>" method="POST" enctype="multipart/form-data">
				<div id="edit-data-pesantren" class="modal fade" role="dialog">
					<div class="modal-dialog">
						<div class="modal-content">
							<div class="modal-header">
								<button type="button" class="close" data-dismiss="modal">&times;</button>
								<h4 class="modal-title">Edit Data Pesantren</h4>
							</div>

							<div class="modal-body">
								<div class="form-group">
									<label>Pernah Mondok ?</label>
									<input style=" cursor: pointer;" type="radio" value="Ya" name="mondok" id="mondok" onclick="cek_pondok()">Ya
									&nbsp;&nbsp;&nbsp;
									<input style=" cursor: pointer;" id="mondok" value="Tidak" onclick="cek_pondok()" type="radio" name="mondok">Tidak
								</div>

								<div class="form-group">
									<label class="list_pondok" style="display: none;">Nama Ponpes</label>
									<input class="form-control list_pondok" style="display: none;" value="<?php echo $modal_value->nama_ponpes; ?>" type="text" name="nama_ponpes" required="required" placeholder="Nama Ponpes Anda">
								</div>

								<div class="form-group">
									<label class="list_pondok" style="display: none;">Alamat Ponpes</label>
									<textarea class="form-control list_pondok" style="display: none;" type="text" name="alamat_ponpes" placeholder="Alamat Ponpes Anda" required="required"><?php echo $modal_value->alamat_ponpes; ?></textarea>
								</div>

								<div class="form-group">
									<label class="list_pondok" style="display: none;">Provinsi Ponpes</label>
									<select class="form-control list_pondok" style="display: none;" required="required" id="provinsi9" name="provinsi_ponpes">
										<option value="">-Pilih SalahSatu-</option>
										<?php
									//melakukan looping dari fungsi index di controller C_mhs
										foreach($propinsi as $data){
											echo "<option value='".$data->id_propinsi."'>".$data->nama_propinsi."</option>";
										}
										?>
									</select>
								</div>

								<div class="form-group">
									<label class="list_pondok" style="display: none;">Kab/Kota Ponpes</label>
									<select class="form-control list_pondok" style="display: none;" required="required" id="kota9" name="kab_kota_ponpes">
										<option value="">-Pilih SalahSatu-</option>
									</select>

									<div id="loading10">
										<img src="<?=base_url('assets/img/loading.gif'); ?>"><small>Loading..</small>
									</div>
								</div>

								<div class="form-group">
									<label class="list_pondok" style="display: none;">Kode Pos Ponpes</label>
									<input value="<?php echo $modal_value->kode_pos_ponpes; ?>" style="display: none;" class="form-control list_pondok" type="text" name="kode_pos_ponpes" placeholder="Kode Pos Ponpes Anda">
								</div>

								<div class="form-group">
									<label class="list_pondok" style="display: none;">Lama Belajar</label>
									<table>
										<tr>
											<td><input class="form-control list_pondok" style="display: none;" value="<?php echo $modal_value->lama_belajar; ?>" type="number" name="lama_belajar" placeholder="Lama Belajar" required="required"></td>
											<td class="list_pondok" style="display: none;">&nbsp;&nbsp;&nbsp;Tahun</td>
										</tr>
									</table>
								</div>
							</div>

							<div class="modal-footer">
								<button type="button" class="btn btn-default" data-dismiss="modal">Tutup</button>
								<button type="submit" class="btn btn-primary">Simpan</button>
							</div>
						</div>
					</div>
				</div>
			</form>
			<!--End Modal Edit Data Pesantren-->

			<!--Modal Edit Keterampilan-->
			<form action="<?=base_url('C_mhs/update_modal6'); ?>" method="POST" enctype="multipart/form-data">
				<div id="edit-data-keterampilan" class="modal fade" role="dialog">
					<div class="modal-dialog">
						<div class="modal-content">
							<div class="modal-header">
								<button type="button" class="close" data-dismiss="modal">&times;</button>
								<h4 class="modal-title">Edit Data Keterampilan</h4>
							</div>

							<div class="modal-body">
								<div class="form-group">
									<label>Kemampuan Bahasa Arab</label>
									<select class="form-control" required="required" name="kemampuan_bahasa_arab">
										<option value="">-Pilih SalahSatu-</option>
										<option value="Tidak Bisa">Tidak Bisa</option>
										<option value="Pasif">Pasif</option>
										<option value="Mahir">Mahir</option>
										<option value="Aktif">Aktif</option>
									</select>
								</div>

								<div class="form-group">
									<label>Kemampuan Bahasa Inggris</label>
									<select class="form-control" required="required" name="kemampuan_bahasa_inggris">
										<option value="">-Pilih SalahSatu-</option>
										<option value="Tidak Bisa">Tidak Bisa</option>
										<option value="Pasif">Pasif</option>
										<option value="Mahir">Mahir</option>
										<option value="Aktif">Aktif</option>
									</select>
								</div>

								<div class="form-group">
									<label>Kemampuan Komputer</label>
									<select class="form-control" required="required" name="kemampuan_komputer">
										<option value="">-Pilih SalahSatu-</option>
										<option value="Tidak Bisa">Tidak Bisa</option>
										<option value="Bisa">Bisa</option>
									</select>
								</div>
							</div>

							<div class="modal-footer">
								<button type="button" class="btn btn-default" data-dismiss="modal">Tutup</button>
								<button type="submit" class="btn btn-primary">Simpan</button>
							</div>
						</div>
					</div>
				</div>
			</form>
			<!--End Modal Edit Keterampilan-->

			<!--Modal Edit Dokumen Pendukung-->
			<form action="<?=base_url('C_mhs/update_modal7'); ?>" method="POST" enctype="multipart/form-data">
				<div id="edit-data-dokumen" class="modal fade" role="dialog">
					<div class="modal-dialog">
						<div class="modal-content">
							<div class="modal-header">
								<button type="button" class="close" data-dismiss="modal">&times;</button>
								<h4 class="modal-title">Edit Data Dokumen Pendukung</h4>
							</div>

							<div class="modal-body">
								<div class="form-group">
									<label>Foto Rumah Bagian Depan</label>
									<table>
										<tr>
											<td><embed style="height: 300px;" src="<?php echo base_url(). 'assets/foto_dokumen/'.$value->upload_foto_rumah_depan; ?>"></td>
											</tr>
										</table>
										<input type="checkbox" name="ubah_foto_rumah_depan" value="1">&nbsp;&nbsp;Ceklis, Jika Ingin mengubah Foto Rumah Bagian Depan
										<input type="file" name="foto_rumah_depan">
									</div>

									<div class="form-group">
										<label>Foto Rumah Bagian Kiri</label>
										<table>
											<tr>
												<td><embed style="height: 300px;" src="<?php echo base_url(). 'assets/foto_dokumen/'.$value->upload_foto_rumah_kiri; ?>"></td>
												</tr>
											</table>
											<input type="checkbox" name="ubah_foto_rumah_kiri" value="2">&nbsp;&nbsp;Ceklis, Jika Ingin mengubah Foto Rumah Bagian Kiri
											<input type="file" name="foto_rumah_kiri">
										</div>

										<div class="form-group">
											<label>Foto Rumah Bagian Kanan</label>
											<table>
												<tr>
													<td><embed style="height: 300px;" src="<?php echo base_url(). 'assets/foto_dokumen/'.$value->upload_foto_rumah_kanan; ?>"></td>
													</tr>
												</table>
												<input type="checkbox" name="ubah_foto_rumah_kanan" value="3">&nbsp;&nbsp;Ceklis, Jika Ingin mengubah Foto Rumah Bagian Kanan
												<input type="file" name="foto_rumah_kanan">
											</div>

											<div class="form-group">
												<label>Foto PBB</label>
												<table>
													<tr>
														<td><embed style="height: 300px;" src="<?php echo base_url(). 'assets/foto_dokumen/'.$value->upload_foto_pbb; ?>"></td>
														</tr>
													</table>
													<input type="checkbox" name="ubah_foto_pbb" value="4">&nbsp;&nbsp;Ceklis, Jika Ingin mengubah Foto PBB
													<input type="file" name="foto_pbb">
												</div>

												<div class="form-group">
													<label>Foto Rekening Listrik</label>
													<table>
														<tr>
															<td><embed style="height: 300px;" src="<?php echo base_url(). 'assets/foto_dokumen/'.$value->upload_foto_rek_listrik; ?>"></td>
															</tr>
														</table>
														<input type="checkbox" name="ubah_foto_rek" value="5">&nbsp;&nbsp;Ceklis, Jika Ingin mengubah Foto Rekening Listrik
														<input type="file" name="foto_rek_listrik">
													</div>
												</div>


												<div class="modal-footer">
													<button type="button" class="btn btn-default" data-dismiss="modal">Tutup</button>
													<button type="submit" class="btn btn-primary">Simpan</button>
												</div>
											</div>
										</div>
									</div>
								</form>
								<!--End Modal Edit Dokumen Pendukung-->

								<!--Modal Edit Persyaratan Dokumen-->
								<form action="<?=base_url('C_mhs/update_modal8'); ?>" method="POST" enctype="multipart/form-data">
									<div id="edit-data-persyaratan-dokumen" class="modal fade" role="dialog">
										<div class="modal-dialog">
											<div class="modal-content">
												<div class="modal-header">
													<button type="button" class="close" data-dismiss="modal">&times;</button>
													<h4 class="modal-title">Edit Data Dokumen Pendukung</h4>
												</div>

												<div class="modal-body">
													<div class="form-group">
														<label>Kartu Tes Jalur Pendaftaran Jalur <?php echo $modal_value->jalur_pendaftaran; ?></label>
														<select class="form-control" required="required" name="kartu_tes">
															<option value="">-Pilih SalahSatu-</option>
															<option value="ADA">ADA</option>
															<option value="TIDAK ADA">TIDAK ADA</option>
														</select>
													</div>

													<div class="form-group">
														<label>Formulir Pendaftaran Bidik Misi yang telah diisi</label>
														<select class="form-control" required="required" name="formulir_pendaftaran">
															<option value="">-Pilih SalahSatu-</option>
															<option value="ADA">ADA</option>
															<option value="TIDAK ADA">TIDAK ADA</option>
														</select>
													</div>

													<div class="form-group">
														<label>Surat Keterangan Lulus dari Kepala Sekolah</label>
														<select class="form-control" required="required" name="skl_dari_kepsek">
															<option value="">-Pilih SalahSatu-</option>
															<option value="ADA">ADA</option>
															<option value="TIDAK ADA">TIDAK ADA</option>
														</select>
													</div>

													<div class="form-group">
														<label>Fotocopy Raport Semester 1-6 yang dilegalisir Kepala Sekolah</label>
														<select class="form-control" required="required" name="raport_semester">
															<option value="">-Pilih SalahSatu-</option>
															<option value="ADA">ADA</option>
															<option value="TIDAK ADA">TIDAK ADA</option>
														</select>
													</div>

													<div class="form-group">
														<label>Fotocopy Ijazah yang diligalisir Kepala Sekolah</label>
														<select class="form-control" required="required" name="ijazah_legalisir">
															<option value="">-Pilih SalahSatu-</option>
															<option value="ADA">ADA</option>
															<option value="TIDAK ADA">TIDAK ADA</option>
														</select>
													</div>

													<div class="form-group">
														<label>Fotocopy Nilai Ujian Akhir Nasional yang dilegalisir Kepala Sekolah</label>
														<select class="form-control" required="required" name="fotocopy_nilai_ujian_un">
															<option value="">-Pilih SalahSatu-</option>
															<option value="ADA">ADA</option>
															<option value="TIDAK ADA">TIDAK ADA</option>
														</select>
													</div>

													<div class="form-group">
														<label>Surat Keterangan Prestasi dan Bukti Pendukung Prestasi yang dilegalisir Kepala Sekolah</label>
														<select class="form-control" required="required" name="keterangan_prestasi">
															<option value="">-Pilih SalahSatu-</option>
															<option value="ADA">ADA</option>
															<option value="TIDAK ADA">TIDAK ADA</option>
														</select>
													</div>

													<div class="form-group">
														<label>Surat Keterangan Penghasilan Ortu/Wali atau Surat Keterangan Tidak Mampu yang dikeluarkan Kepala Desa/Dusun/Instansi/Tokoh Masyarakat</label>
														<select class="form-control" required="required" name="keterangan_penghasilan_ortu_wali">
															<option value="">-Pilih SalahSatu-</option>
															<option value="ADA">ADA</option>
															<option value="TIDAK ADA">TIDAK ADA</option>
														</select>
													</div>

													<div class="form-group">
														<label>Fotocopy Kartu Keluarga atau Surat Keterangan Susunan Keluarga</label>
														<select class="form-control" required="required" name="fotocopy_kk">
															<option value="">-Pilih SalahSatu-</option>
															<option value="ADA">ADA</option>
															<option value="TIDAK ADA">TIDAK ADA</option>
														</select>
													</div>

													<div class="form-group">
														<label>Fotocopy Rekening Listrik Bulan Terakhir (bila tersedia listrik)</label>
														<select class="form-control" required="required" name="fotocopy_rek">
															<option value="">-Pilih SalahSatu-</option>
															<option value="ADA">ADA</option>
															<option value="TIDAK ADA">TIDAK ADA</option>
														</select>
													</div>

													<div class="form-group">
														<label>Fotocopy Bukti Pembayaran PBB Tahun Terakhir</label>
														<select class="form-control" required="required" name="fotocopy_bukti_pembayaran_pbb">
															<option value="">-Pilih SalahSatu-</option>
															<option value="ADA">ADA</option>
															<option value="TIDAK ADA">TIDAK ADA</option>
														</select>
													</div>

													<div class="form-group">
														<label>Melengkapi data foto rumah dari 3(tiga) sudut</label>
														<select class="form-control" required="required" name="data_foto_rumah">
															<option value="">-Pilih SalahSatu-</option>
															<option value="ADA">ADA</option>
															<option value="TIDAK ADA">TIDAK ADA</option>
														</select>
													</div>
												</div>

												<div class="modal-footer">
													<button type="button" class="btn btn-default" data-dismiss="modal">Tutup</button>
													<button type="submit" class="btn btn-primary">Simpan</button>
												</div>
											</div>
										</div>
									</div>
								</form>
								<!--End Modal Edit Persyaratan Dokumen-->
							<?php } ?>
						</body>

						<div style="text-align: center;">	
							<?php
							$this->load->view('project_bidikmisi/footer/footer');
							?>
						</div>
						</html>
