<!DOCTYPE html>
<html>
	<body>
		<div class="container-fluid">
			<div class="row">
				<div class="col-md-12" style="text-align: center; background-color: #ffe599;">
					<div class="tahap">
						<h3>Tahap 10</h3>
					</div>
					
					<div id="verifikasi">
						<h2><b><u>Verifikasi Data Bidikmisi</u></b></h2>
					</div>
					
					<div class="penting">
						<p>Silahkan Cek Kembali data yang telah anda masukan.</p>
						<!--p>PERHATIAN !! Jangan membayar daftar ulang dahulu sebelum keluar pengumuman lulus/tidak lulus BidikMisi Anda !!</p-->
					</div>
					<p>Jika anda sudah yakin dengan data yang telah dimasukan, silahkan klik tombol VERIFIKASI di bagian paling bawah Website</p>
				</div>		
			</div>
		</div>
	</body>
</html>