<?php
	$this->load->view('project_bidikmisi/header/mahasiswa/header3_mhs');
	$this->load->view('project_bidikmisi/mahasiswa/navbar_mhs');
?>
<!DOCTYPE html>
<html>
	<body>
		<div class="container-fluid">
			<div class="">
				<div class="row">
					<div class="notif notifikasi col-md-offset-8">
						<?php echo $this->session->flashdata('direct2_success'); ?>
					</div>

					<!--Sidebar-->
					<div class="col-md-3" style="padding-bottom: 40px;">
						<div class="sidebar-buat col-md-12 col-md-offset-1">
							<h3>Tahapan Bidikmisi</h3>
						</div>

						<div class="list-group col-md-12 col-md-offset-1">
							<a href="<?=base_url('C_mhs'); ?>" class="list-group-item input">Tahap 1 Upload Foto</a>
							<a href="<?=base_url('C_mhs/step2'); ?>" class="list-group-item input active">Tahap 2 Identitas Diri</a>
							<a href="<?=base_url('C_mhs/step3'); ?>" class="list-group-item input">Tahap 3 Data Ortu</a>
							<a href="<?=base_url('C_mhs/step4'); ?>" class="list-group-item input">Tahap 4 Data Kondisi Rumah</a>
							<a href="<?=base_url('C_mhs/step5'); ?>" class="list-group-item input">Tahap 5 Data Sekolah</a>
							<a href="<?=base_url('C_mhs/step6'); ?>" class="list-group-item input">Tahap 6 Data Pesantren</a>
							<a href="<?=base_url('C_mhs/step7'); ?>" class="list-group-item input">Tahap 7 Keterampilan</a>
							<a href="<?=base_url('C_mhs/step8'); ?>" class="list-group-item input">Tahap 8 Upload Dokumen Pendukung</a>
							<a href="<?=base_url('C_mhs/step9'); ?>" class="list-group-item input">Tahap 9 Persyaratan Dokumen</a>
							<a href="<?=base_url('C_mhs/step10'); ?>" class="list-group-item input">Tahap 10 Verifikasi Data</a>    
						</div>
					</div>
					<!--End Sidebar-->


					<div class="col-md-4" style="text-align: center;">
    					<div class="col-md-offset-2">	
    						<h3>RULE Tahap 2 (Identitas Diri)</h3>
    						<div class="penting">
    							<p>Tanda Asterik (*) Wajib diisi</p>
    						</div>
    						
    						<p>Silahkan isi data identitas diri anda, jika ada kesalahan/belum terisi silahkan klik tombol EDIT dibawah.</p>
    						<p>Jika sudah diisi Silahkan klik Tombol Lanjut</p>
    					</div>
					</div>

					<div class="col-md-4">
						<div class="tahap">
							<h3>Tahap 2</h3>
						</div>

						<!--Identitas Diri-->
						<?php foreach ($data_diri as $value) { ?>
						<form action="<?=base_url('C_mhs/direct2'); ?>" method="POST">
							<div id="identitas-diri">
								<h2><b><u>Identitas Diri</u></b></h2>
							</div>

							<div class="col-md-offset-1 col-md-12">
								<table class="table">
									<tr>
										<td>Tempat Lahir</td>
										<td>:</td>
										<td><?php echo $value->tempat_lahir; ?></td>
										<td><b class="asterik">*</b></td>
									</tr>

									<tr>
										<td>Status Pernikahan</td>
										<td>:</td>
										<td><?php echo $value->status_pernikahan; ?></td>
										<td><b class="asterik">*</b></td>
									</tr>

									<tr>
										<td>Asal Provinsi</td>
										<td>:</td>
										<td><?php
												foreach ($propinsi as $x_prov) {
													if($value->asal_provinsi == $x_prov->id_propinsi){
														echo $x_prov->nama_propinsi;
													}
												}
										?></td>
										<td><b class="asterik">*</b></td>
									</tr>

									<tr>
										<td>Asal Kab/Kota</td>
										<td>:</td>
										<td><?php
												foreach ($kota as $x_kota) {
													if($value->asal_kab_kota == $x_kota->id_kota){
														echo $x_kota->nama_kota;
													}
												}
										?></td>
										<td><b class="asterik">*</b></td>
									</tr>

									<tr>
										<td>No Telp/Hp</td>
										<td>:</td>
										<td><?php echo $value->no_telp; ?></td>
										<td><b class="asterik">*</b></td>
									</tr>

									<tr>
										<td>E-mail</td>
										<td>:</td>
										<td><?php echo $value->email; ?></td>
										<td><b class="asterik">*</b></td>
									</tr>

									<tr>
										<td>Alamat</td>
										<td>:</td>
										<td><?php echo $value->alamat; ?></td>
										<td><b class="asterik">*</b></td>
									</tr>

									<tr>
										<td>RT</td>
										<td>:</td>
										<td><?php echo $value->rt_2; ?></td>
										<td><b class="asterik">*</b></td>
									</tr>

									<tr>
										<td>RW</td>
										<td>:</td>
										<td><?php echo $value->rw_2; ?></td>
										<td><b class="asterik">*</b></td>
									</tr>

									<tr>
										<td>Kecamatan</td>
										<td>:</td>
										<td><?php echo $value->kecamatan_2; ?></td>
										<td><b class="asterik">*</b></td>
									</tr>

									<tr>
										<td>Kelurahan</td>
										<td>:</td>
										<td><?php echo $value->kelurahan_2; ?></td>
										<td><b class="asterik">*</b></td>
									</tr>

									<tr>
										<td>Kode Pos Alamat Anda</td>
										<td>:</td>
										<td><?php echo $value->kode_pos; ?></td>
										<td><b class="asterik">*</b></td>
									</tr>
								</table>
							</div>
							<div class="clear"></div>
							<!--End Identitas Diri-->
						</form>
					
						<!--button-->
						<div class="button-all">
							<div class="col-md-12 col-md-offset-3">
								<a href="<?=base_url('C_mhs'); ?>" class="btn btn-info">
									<i class="fa fa-check-circle-o"></i>
									&laquo; Kembali
								</a>

								<button data-target="#edit-identitas-diri" data-toggle="modal" class="btn btn-primary" value="Edit" type="submit">
									<i class="glyphicon glyphicon-edit"></i>
									Edit
								</button>

								<a href="<?=base_url('C_mhs/step3'); ?>" class="btn btn-info">
									<i class="fa fa-check-circle-o"></i>
									Lanjut &raquo;
								</a>
							</div>
						</div>
						<!--End button-->
					</div>

					<form action="<?=base_url('C_mhs/direct2'); ?>" method="POST">
						<div id="edit-identitas-diri" class="modal fade">
							<div class="modal-dialog">
								<div class="modal-content">
									<div class="modal-header">
										<button type="button" class="close" data-dismiss="modal">&times;</button>
										<h4 class="modal-title">Edit Identitas Diri</h4>
									</div>

									<div class="modal-body">
										<div class="form-group">
											<label>Tempat Lahir <b class="asterik">*</b></label>
											<input class="form-control input" type="text" placeholder="Tempat Lahir Anda" name="tempat_lahir" required="required" value="<?php echo $value->tempat_lahir; ?>">
										</div>

										<div class="form-group">
											<label>Status Pernikahan <b class="asterik">*</b></label>
											<select class="form-control input" required="required" name="status_pernikahan">
												<?php if($value->status_pernikahan == null) { ?>
													<option value="">-Pilih SalahSatu-</option>
													<option value="Menikah">Menikah</option>
													<option value="Belum Menikah">Belum Menikah</option>
												<?php }else{ ?>
													<option value="<?php echo $value->status_pernikahan; ?>"><?php echo $value->status_pernikahan; ?></option>	
													<option value="">--</option>
													<option value="Menikah">Menikah</option>
													<option value="Belum Menikah">Belum Menikah</option>
												<?php } ?>
											</select>
										</div>

										<div class="form-group">
											<label>Asal Provinsi <b class="asterik">*</b></label>
											<select class="form-control input" required="required" name="asal_provinsi" id="provinsi">
												<?php if($value->asal_provinsi == null || $value->asal_provinsi == '0') { ?>
												<option value="">-Pilih SalahSatu-</option>
												<?php
													//melakukan looping dari fungsi index di controller C_mhs
													foreach($propinsi as $data){
														echo "<option value='".$data->id_propinsi."'>".$data->nama_propinsi."</option>";
													}
												}else{	
												?>
												<?php foreach ($propinsi as $x_prov) {
													if($value->asal_provinsi == $x_prov->id_propinsi){
												?>
													<option value="<?php echo $x_prov->id_propinsi; ?>">
														<?php		
																echo $x_prov->nama_propinsi;
																}
															} 
														?>
													</option>	
													<option value="">--</option>
												<?php
													//melakukan looping dari fungsi index di controller C_mhs
													foreach($propinsi as $data){
														echo "<option value='".$data->id_propinsi."'>".$data->nama_propinsi."</option>";
													}
												} 
												?>
											</select>
										</div>

										<div class="form-group">
											<label>Asal Kab/Kota <b class="asterik">*</b></label>
											<?php if($value->asal_kab_kota == null || $value->asal_kab_kota == '0') { ?>
												<select required="required" class="form-control input" name="asal_kab_kota" id="kota">
													<option value="">-Pilih SalahSatu-</option>
												</select>
												<div id="loading">
													<img src="<?=base_url('assets/img/loading.gif'); ?>"><small>Loading..</small>
												</div>
											<?php }else{ ?>
												<select required="required" class="form-control input" name="asal_kab_kota" id="kota">
											<?php
												foreach ($kota as $x_kota) {
													if($value->asal_kab_kota == $x_kota->id_kota) {
											?>
													<option value="<?php echo $x_kota->id_kota; ?>">
													<?php		
																echo $x_kota->nama_kota;
															}
														}
													?>
													</option>
													<option>--</option>
												</select>
												<div id="loading">
													<img src="<?=base_url('assets/img/loading.gif'); ?>"><small>Loading..</small>
												</div>
											<?php } ?>
										</div>

										<div class="form-group">
											<label>No Telp/Hp <b class="asterik">*</b></label>
											<input class="form-control input" type="text" placeholder="Contoh : 0882-2233-8832" name="no_telp" required="required" value="<?php echo $value->no_telp; ?>">
										</div>

										<div class="form-group">
											<label>E-Mail <b class="asterik">*</b></label>
											<input class="form-control input" type="email" placeholder="Email Anda" name="email" required="required" value="<?php echo $value->email; ?>">
										</div>

										<div class="form-group">
											<label>Alamat <b class="asterik">*</b></label>
											<textarea class="form-control input" type="text" name="alamat" placeholder="Alamat Anda" required="required"><?php echo $value->alamat; ?></textarea>
										</div>

										<div class="form-group">
											<label>RT <b class="asterik">*</b></label>
											<input class="form-control input" type="number" placeholder="Rukun Tetangga" name="rt_2" required="required" value="<?php echo $value->rt_2; ?>">
										</div>

										<div class="form-group">
											<label>RW <b class="asterik">*</b></label>
											<input class="form-control input" type="number" placeholder="Rukun Warga" name="rw_2" required="required" value="<?php echo $value->rw_2; ?>">
										</div>

										<div class="form-group">
											<label>Kecamatan <b class="asterik">*</b></label>
											<input class="form-control input" type="text" placeholder="Kecamatan Alamat Anda" name="kecamatan_2" required="required" value="<?php echo $value->kecamatan_2; ?>">
										</div>

										<div class="form-group">
											<label>Kelurahan <b class="asterik">*</b></label>
											<input class="form-control input" type="text" placeholder="Kelurahan Anda" name="kelurahan_2" required="required" value="<?php echo $value->kelurahan_2; ?>">
										</div>

										<div class="form-group">
											<label>Kode Pos Alamat Anda <b class="asterik">*</b></label>
											<input class="form-control input" type="text" placeholder="Kode Pos Alamat Anda" name="kode_pos" required="required" value="<?php echo $value->kode_pos; ?>">
										</div>
										<!--div class="table-responsive">
											<table class="table">
												<tr class="form-group">
													<td class="input">Tempat Lahir</td>	
													<td>:</td>					
													<td><input class="form-control input" type="text" placeholder="Tempat Lahir Anda" name="tempat_lahir" required="required" value="<?php echo $value->tempat_lahir; ?>"></td>
													<td><b class="asterik">*</b></td>
												</tr>

												<tr class="form-group">
													<td class="input">Status Pernikahan</td>
													<td>:</td>
													<td>
													<select class="form-control input" required="required" name="status_pernikahan">
														<?php if($value->status_pernikahan == null) { ?>
															<option value="">-Pilih SalahSatu-</option>
															<option value="Menikah">Menikah</option>
															<option value="Belum Menikah">Belum Menikah</option>
														<?php }else{ ?>
															<option value="<?php echo $value->status_pernikahan; ?>"><?php echo $value->status_pernikahan; ?></option>	
															<option value="">--</option>
															<option value="Menikah">Menikah</option>
															<option value="Belum Menikah">Belum Menikah</option>
														<?php } ?>
													</select></td>
													<td><b class="asterik">*</b></td>
												</tr>

												<tr class="form-group">
													<td class="input">Asal Provinsi</td>
													<td>:</td>
													<td>
														<select class="form-control input" required="required" name="asal_provinsi" id="provinsi">
															<?php if($value->asal_provinsi == null || $value->asal_provinsi == '0') { ?>
															<option value="">-Pilih SalahSatu-</option>
															<?php
																//melakukan looping dari fungsi index di controller C_mhs
																foreach($propinsi as $data){
																	echo "<option value='".$data->id_propinsi."'>".$data->nama_propinsi."</option>";
																}
															}else{	
															?>
															<?php foreach ($propinsi as $x_prov) {
																if($value->asal_provinsi == $x_prov->id_propinsi){
															?>
																<option value="<?php echo $x_prov->id_propinsi; ?>">
																	<?php		
																			echo $x_prov->nama_propinsi;
																			}
																		} 
																	?>
																</option>	
																<option value="">--</option>
															<?php
																//melakukan looping dari fungsi index di controller C_mhs
																foreach($propinsi as $data){
																	echo "<option value='".$data->id_propinsi."'>".$data->nama_propinsi."</option>";
																}
															} 
															?>
														</select>
													</td>
													<td><b class="asterik">*</b></td>
												</tr>

												<tr class="form-group">
													<td class="input">Asal Kab/Kota</td>
													<td>:</td>
													<td>
														<?php if($value->asal_kab_kota == null || $value->asal_kab_kota == '0') { ?>
															<select required="required" class="form-control input" name="asal_kab_kota" id="kota">
																<option value="">-Pilih SalahSatu-</option>
															</select>
															<div id="loading">
																<img src="<?=base_url('assets/img/loading.gif'); ?>"><small>Loading..</small>
															</div>
														<?php }else{ ?>
															<select required="required" class="form-control input" name="asal_kab_kota" id="kota">
														<?php
															foreach ($kota as $x_kota) {
																if($value->asal_kab_kota == $x_kota->id_kota) {
														?>
																<option value="<?php echo $x_kota->id_kota; ?>">
																<?php		
																			echo $x_kota->nama_kota;
																		}
																	}
																?>
																</option>
																<option>--</option>
															</select>
															<div id="loading">
																<img src="<?=base_url('assets/img/loading.gif'); ?>"><small>Loading..</small>
															</div>
														<?php } ?>
													</td>
													<td><b class="asterik">*</b></td>
												</tr>

												<tr class="form-group">
													<td class="input">No Telp/Hp</td>
													<td>:</td>
													<td><input class="form-control input" type="text" placeholder="Contoh : 0882-2233-8832" name="no_telp" required="required" value="<?php echo $value->no_telp; ?>"></td>
													<td><b class="asterik">*</b></td>
												</tr>

												<tr class="form-group">
													<td class="input">E-mail</td>
													<td>:</td>
													<td><input class="form-control input" type="email" placeholder="Email Anda" name="email" required="required" value="<?php echo $value->email; ?>"></td>
													<td><b class="asterik">*</b></td>
												</tr>

												<tr class="form-group">
													<td class="input">Alamat</td>
													<td>:</td>
													<td><textarea class="form-control input" type="text" name="alamat" placeholder="Alamat Anda" required="required"><?php echo $value->alamat; ?></textarea></td>
													<td><b class="asterik">*</b></td>
												</tr>

												<tr class="form-group">
													<td class="input">RT</td>
													<td>:</td>
													<td><input class="form-control input" type="number" placeholder="Rukun Tetangga" name="rt_2" required="required" value="<?php echo $value->rt_2; ?>"></td>
													<td><b class="asterik">*</b></td>
												</tr>

												<tr class="form-group">
													<td class="input">RW</td>
													<td>:</td>
													<td><input class="form-control input" type="number" placeholder="Rukun Warga" name="rw_2" required="required" value="<?php echo $value->rw_2; ?>"></td>
													<td><b class="asterik">*</b></td>
												</tr>

												<tr class="form-group">
													<td class="input">Kelurahan/Desa</td>
													<td>:</td>
													<td><input class="form-control input" type="text" placeholder="Kelurahan Anda" name="kelurahan_2" required="required" value="<?php echo $value->kelurahan_2; ?>"></td>
													<td><b class="asterik">*</b></td>
												</tr>

												<tr class="form-group">
													<td class="input">Kecamatan</td>
													<td>:</td>
													<td><input class="form-control input" type="text" placeholder="Kecamatan Alamat Anda" name="kecamatan_2" required="required" value="<?php echo $value->kecamatan_2; ?>"></td>
													<td><b class="asterik">*</b></td>
												</tr>

												<tr class="form-group">
													<td class="input">Kode Pos Alamat Anda</td>
													<td>:</td>
													<td><input class="form-control input" type="text" placeholder="Kode Pos Alamat Anda" name="kode_pos" required="required" value="<?php echo $value->kode_pos; ?>"></td>
													<td><b class="asterik">*</b></td>
												</tr>
											</table>
										</div-->
									</div>

									<div class="modal-footer">
										<button type="button" class="btn btn-default" data-dismiss="modal">Tutup</button>
										<button type="submit" class="btn btn-primary">Simpan</button>
									</div>
								</div>
							</div>
						</div>
					</form>
					
					<?php } ?>

					<div class="clear"></div>
				</div>
			</div>
		</div>	
	</body>
	<div style="text-align: center;">
		<?php
			$this->load->view('project_bidikmisi/footer/footer');
		?>
	</div>
</html>