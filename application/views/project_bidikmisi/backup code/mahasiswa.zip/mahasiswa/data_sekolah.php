<?php
	$this->load->view('project_bidikmisi/header/mahasiswa/header3_mhs');
	$this->load->view('project_bidikmisi/mahasiswa/navbar_mhs');
?>

<!DOCTYPE html>
<html>
	<body>
		<div class="container-fluid">
			<div class="">
				<div class="row">
					<div class="notif notifikasi col-md-offset-8">
						<?php echo $this->session->flashdata('direct5_success'); ?>
					</div>
					
					<!--Sidebar-->
					<div class="col-md-3" style="padding-bottom: 40px;">
						<div class="sidebar-buat col-md-12 col-md-offset-1">
							<h3>Tahapan Bidikmisi</h3>
						</div>

						<div class="list-group col-md-12 col-md-offset-1">
							<a href="<?=base_url('C_mhs'); ?>" class="list-group-item input">Tahap 1 Upload Foto</a>
							<a href="<?=base_url('C_mhs/step2'); ?>" class="list-group-item input">Tahap 2 Identitas Diri</a>
							<a href="<?=base_url('C_mhs/step3'); ?>" class="list-group-item input">Tahap 3 Data Ortu</a>
							<a href="<?=base_url('C_mhs/step4'); ?>" class="list-group-item input">Tahap 4 Data Kondisi Rumah</a>
							<a href="<?=base_url('C_mhs/step5'); ?>" class="list-group-item input active">Tahap 5 Data Sekolah</a>
							<a href="<?=base_url('C_mhs/step6'); ?>" class="list-group-item input">Tahap 6 Data Pesantren</a>
							<a href="<?=base_url('C_mhs/step7'); ?>" class="list-group-item input">Tahap 7 Keterampilan</a>
							<a href="<?=base_url('C_mhs/step8'); ?>" class="list-group-item input">Tahap 8 Upload Dokumen Pendukung</a>
							<a href="<?=base_url('C_mhs/step9'); ?>" class="list-group-item input">Tahap 9 Persyaratan Dokumen</a>
							<a href="<?=base_url('C_mhs/step10'); ?>" class="list-group-item input">Tahap 10 Verifikasi Data</a>	    
						</div>
					</div>
					<!--End Sidebar-->

					<div class="col-md-4" style="text-align: center;">
    					<div class="col-md-offset-2">
    						<h3>RULE Tahap 5 (Data Sekolah)</h3>
    						<div class="penting">
    							<p>Tanda Asterik (*) Wajib diisi</p>
    						</div>
    						
    						<p>Silahkan klik Tombol EDIT dibawah, jika ada kesalahan/data anda belum diisi</p>
    						<p>Jika sudah diisi Silahkan klik Tombol Lanjut</p>
    					</div>
					</div>

					<?php foreach ($data_diri as $value) { ?>
					<div class="col-md-4">
						<div class="tahap">
							<h3>Tahap 5</h3>
						</div>
						<!--Data Sekolah-->
						<div id="data-sekolah">
							<h2><b><u>Data Sekolah</u></b></h2>
						</div>

						<table class="table">
							<tr>
								<td>Alamat Sekolah</td>
								<td>:</td>
								<td><?php echo $value->alamat_sekolah; ?></td>
								<td><i class="asterik">*</i></td>
							</tr>

							<tr>
								<td>RT Sekolah</td>
								<td>:</td>
								<td><?php echo $value->rt_5; ?></td>
								<td><i class="asterik">*</i></td>
							</tr>

							<tr>
								<td>RW Sekolah</td>
								<td>:</td>
								<td><?php echo $value->rw_5; ?></td>
								<td><i class="asterik">*</i></td>
							</tr>

							<tr>
								<td>Provinsi Sekolah</td>
								<td>:</td>
								<td><?php 
										if($value->prov_sekolah == '0' || $value->prov_sekolah == null){
											echo "";
										}

										foreach ($propinsi as $x_prov) {
											if($value->prov_sekolah == $x_prov->id_propinsi){
												echo $x_prov->nama_propinsi;
											}
										}
									?></td>
									<td><i class="asterik">*</i></td>
							</tr>

							<tr>
								<td>Kab/Kota Sekolah</td>
								<td>:</td>
								<td><?php
										if($value->kab_kota_sekolah == '0' || $value->kab_kota_sekolah == null){
											echo "";
										}

										foreach($kota as $x_kab_kota){
										if($value->kab_kota_sekolah == $x_kab_kota->id_kota){
											echo $x_kab_kota->nama_kota;
										}
									}
									?></td>
									<td><i class="asterik">*</i></td>
							</tr>

							<tr>
								<td>Kecamatan Sekolah</td>
								<td>:</td>
								<td><?php echo $value->kecamatan_5; ?></td>
								<td><i class="asterik">*</i></td>
							</tr>
							
							<tr>
								<td>Kelurahan Sekolah</td>
								<td>:</td>
								<td><?php echo $value->kelurahan_5; ?></td>
								<td><i class="asterik">*</i></td>
							</tr>

							<tr>
								<td>Nama Sekolah</td>
								<td>:</td>
								<td><?php echo $value->nama_sekolah; ?></td>
								<td><i class="asterik">*</i></td>
							</tr>

							<tr>
								<td>Tahun Lulus</td>
								<td>:</td>
								<td><?php 
										if($value->tahun_lulus == null || $value->tahun_lulus == '0') { 
											echo "";
										}else{
											echo $value->tahun_lulus;
										}
									?>
								</td>
								<td><i class="asterik">*</i></td>
							</tr>

							<tr>
								<td>Jurusan Sekolah</td>
								<td>:</td>
								<td><?php echo $value->jurusan_sekolah; ?></td>
								<td><i class="asterik">*</i></td>
							</tr>

							<tr>
								<td>Rerata Nilai UN</td>
								<td>:</td>
								<td><?php 
									if($value->rerata_nilai_un == '1'){
										echo "< 7.00";
									}else if($value->rerata_nilai_un == '2'){
										echo "7.00 - 8.00";
									}else if($value->rerata_nilai_un == '3'){
										echo "8.10 - 9.00";
									}else if($value->rerata_nilai_un == '4'){
										echo "> 9.00";
									}
								?></td>
								<td><i class="asterik">*</i></td>
							</tr>

							<tr>
								<td>Rerata Nilai Raport</td>
								<td>:</td>
								<td><?php 
									if($value->rerata_nilai_raport == '1'){
										echo "< 7.00";
									}else if($value->rerata_nilai_raport == '2'){
										echo "7.00 - 8.00";
									}else if($value->rerata_nilai_raport == '3'){
										echo "8.10 - 9.00";
									}else if($value->rerata_nilai_raport == '4'){
										echo "> 9.00";
									}
								?></td>
								<td><i class="asterik">*</i></td>
							</tr>

							<tr>
								<td>Prestasi Akademik</td>
								<td>:</td>
								<td><?php
									if($value->prestasi_akademik == '0'){
										echo "Tidak Ada Prestasi";
									}else if($value->prestasi_akademik == '1'){
										echo "Tingkat Lokal";
									}else if($value->prestasi_akademik == '2'){
										echo "Tingkat Regional";
									}else if($value->prestasi_akademik == '3'){
										echo "Tingkat Nasional";
									}else if($value->prestasi_akademik == '4'){
										echo "Tingkat Internasional";
									}
								?></td>
								<td><i class="asterik">*</i></td>
							</tr>

							<tr>
								<td>Prestasi Non Akademik</td>
								<td>:</td>
								<td><?php
									if($value->prestasi_non_akademik == '0'){
										echo "Tidak Ada Prestasi";
									}else if($value->prestasi_non_akademik == '1'){
										echo "Tingkat Lokal";
									}else if($value->prestasi_non_akademik == '2'){
										echo "Tingkat Regional";
									}else if($value->prestasi_non_akademik == '3'){
										echo "Tingkat Nasional";
									}else if($value->prestasi_non_akademik == '4'){
										echo "Tingkat Internasional";
									}
								?></td>
								<td><i class="asterik">*</i></td>
							</tr>
						</table>
						<!--End Data Sekolah-->
						
						<!--button-->
						<div class="button-all">
							<div class="col-md-12 col-md-offset-2">	
								<a href="<?=base_url('C_mhs/step4'); ?>" class="btn btn-info">
									<i class="fa fa-check-circle-o"></i>
									&laquo; Kembali
								</a>

								<button data-target="#edit-data-sekolah" data-toggle="modal" class="btn btn-primary" value="Edit" type="submit">
									<i class="glyphicon glyphicon-edit"></i>
									Edit
								</button>

								<a href="<?=base_url('C_mhs/step6'); ?>" class="btn btn-info">
									<i class="fa fa-check-circle-o"></i>
									Lanjut &raquo;
								</a>
							</div>
						</div>
						<!--End button-->
					</div>

					<!--Modal Data Sekolah -->
					<form action="<?=base_url('C_mhs/direct5'); ?>" method="POST">
						<div id="edit-data-sekolah" class="modal fade">
							<div class="modal-dialog">
								<div class="modal-content">
									<div class="modal-header">
										<button type="button" class="close" data-dismiss="modal">&times;</button>
										<h4 class="modal-title">Edit Data Sekolah</h4>
									</div>

									<div class="modal-body">
										<div class="form-group">
											<label>Alamat Sekolah <i class="asterik">*</i></label>
											<textarea class="form-control input" type="text" name="alamat_sekolah" placeholder="Alamat Sekolah Anda" required="required"><?php echo $value->alamat_sekolah; ?></textarea>
										</div>

										<div class="form-group">
											<label>RT Sekolah <i class="asterik">*</i></label>
											<input class="form-control input" type="number" name="rt_5" placeholder="Rukun Tetangga" required="required" value="<?php echo $value->rt_5; ?>">
										</div>

										<div class="form-group">
											<label>RW Sekolah <i class="asterik">*</i></label>
											<input class="form-control input" type="number" name="rw_5" placeholder="Rukun Warga" required="required" value="<?php echo $value->rw_5; ?>">
										</div>

										<div class="form-group">
											<label>Provinsi Sekolah <i class="asterik">*</i></label>
											<select class="form-control input" required="required" name="provinsi_sekolah" id="provinsi3">
												<?php 
												if($value->prov_sekolah == null || $value->prov_sekolah == '0') { ?>
													<option value="">-Pilih SalahSatu-</option>
													<?php
														//melakukan looping dari fungsi index di controller C_mhs
														foreach($propinsi as $data){
															echo "<option value='".$data->id_propinsi."'>".$data->nama_propinsi."</option>";
														}
													}else{	
													?>
													<?php foreach ($propinsi as $x_prov) {
														if($value->prov_sekolah == $x_prov->id_propinsi){
													?>
														<option value="<?php echo $x_prov->id_propinsi; ?>">
															<?php		
																	echo $x_prov->nama_propinsi;
																	}
																} 
															?>
														</option>	
														<option value="">--</option>
													<?php
														//melakukan looping dari fungsi index di controller C_mhs
														foreach($propinsi as $data){
															echo "<option value='".$data->id_propinsi."'>".$data->nama_propinsi."</option>";
														}
													} 
												?>
											</select>
										</div>

										<div class="form-group">
											<label>Kab/Kota Sekolah <i class="asterik">*</i></label>
											<?php if($value->kab_kota_sekolah == null || $value->kab_kota_sekolah == '0') { ?>
												<select class="form-control input" required="required" name="kab_kota_sekolah" id="kota3">
													<option value="">-Pilih SalahSatu-</option>
												</select>
												<div id="loading3">
													<img src="<?=base_url('assets/img/loading.gif'); ?>"><small>Loading..</small>
												</div>
											<?php }else{ ?>
												<select class="form-control input" required="required" name="kab_kota_sekolah" id="kota3">
											<?php
												foreach ($kota as $x_kota) {
													if($value->kab_kota_sekolah == $x_kota->id_kota) {
											?>
													<option value="<?php echo $x_kota->id_kota; ?>">
													<?php		
																echo $x_kota->nama_kota;
															}
														}
													?>
													</option>
													<option value="">--</option>
												</select>
												<div id="loading3">
													<img src="<?=base_url('assets/img/loading.gif'); ?>"><small>Loading..</small>
												</div>
											<?php } ?>
										</div>

										<div class="form-group">
											<label>Kecamatan Sekolah <i class="asterik">*</i></label>
											<input class="form-control input" type="text" name="kecamatan_5" placeholder="Kecamatan Sekolah Anda" required="required" value="<?php echo $value->kecamatan_5; ?>">
										</div>

										<div class="form-group">
											<label>Kelurahan Sekolah <i class="asterik">*</i></label>
											<input class="form-control input" type="text" name="kelurahan_5" placeholder="Kelurahan Sekolah Anda" required="required" value="<?php echo $value->kelurahan_5; ?>">
										</div>

										<div class="form-group">
											<label>Nama Sekolah <i class="asterik">*</i></label>
											<textarea class="form-control input" type="text" name="nama_sekolah" placeholder="Nama Sekolah Anda" required="required"><?php echo $value->nama_sekolah; ?></textarea>
										</div>

										<div class="form-group">
											<label>Tahun Lulus <i class="asterik">*</i></label>
											<select class="form-control input" required="required" name="tahun_lulus">
												<?php if($value->tahun_lulus == null || $value->tahun_lulus == '0') { ?>	
													<option value="">-Pilih SalahSatu-</option>
													<?php foreach($tahun_lulus as $x_tahun) { ?>
													<option value="<?php echo $x_tahun->tahun_lulus; ?>"><?php echo $x_tahun->tahun_lulus; ?></option>
													<?php } ?>
												<?php }else { ?>
													<option value="<?php echo $value->tahun_lulus; ?>"><?php echo $value->tahun_lulus; ?></option>
													<option value="">--</option>
													<?php foreach($tahun_lulus as $x_tahun) { ?>
													<option value="<?php echo $x_tahun->tahun_lulus; ?>"><?php echo $x_tahun->tahun_lulus; ?></option>
													<?php } ?>
												<?php } ?>
											</select>
										</div>

										<div class="form-group">
											<label>Jurusan Sekolah <i class="asterik">*</i></label>
											<select class="form-control input" required="required" name="jurusan_sekolah">
												<?php if($value->jurusan_sekolah == null) { ?>	
													<option value="">-Pilih SalahSatu-</option>
													<option value="IPA">IPA</option>
													<option value="IPS">IPS</option>
													<option value="Bahasa">Bahasa</option>
													<option value="Teknik">Teknik</option>
													<option value="Pertanian">Pertanian</option>
													<option value="Ekonomi">Ekonomi</option>
													<option value="Seni">Seni</option>
													<option value="Pariwisata">Pariwisata</option>
													<option value="Agama">Agama</option>
													<option value="Lain - Lain">Lain - Lain</option>
												<?php }else{ ?>
													<option value="<?php echo $value->jurusan_sekolah; ?>"><?php echo $value->jurusan_sekolah; ?></option>
													<option value="">--</option>
													<option value="IPA">IPA</option>
													<option value="IPS">IPS</option>
													<option value="Bahasa">Bahasa</option>
													<option value="Teknik">Teknik</option>
													<option value="Pertanian">Pertanian</option>
													<option value="Ekonomi">Ekonomi</option>
													<option value="Seni">Seni</option>
													<option value="Pariwisata">Pariwisata</option>
													<option value="Agama">Agama</option>
													<option value="Lain - Lain">Lain - Lain</option>
												<?php } ?>
											</select>
										</div>

										<div class="form-group">
											<label>Rerata Nilai UN <i class="asterik">*</i></label>
											<select class="form-control input" required="required" name="rerata_nilai_un">
												<?php if($value->rerata_nilai_un == null || $value->rerata_nilai_un == '0') { ?>	
													<option value="">-Pilih SalahSatu-</option>
													<option value="1">< 7.00</option>
													<option value="2">7.00 - 8.00</option>
													<option value="3">8.10 - 9.00</option>
													<option value="4">> 9.00</option>
												<?php }else{ ?>
													<option value="<?php echo $value->rerata_nilai_un; ?>"><?php 
														if($value->rerata_nilai_un == '1'){
															echo "< 7.00";
														}else if($value->rerata_nilai_un == '2'){
															echo "7.00 - 8.00";
														}else if($value->rerata_nilai_un == '3'){
															echo "8.10 - 9.00";
														}else if($value->rerata_nilai_un == '4'){
															echo "> 9.00";
														}
													?></option>
													<option value="">--</option>
													<option value="1">< 7.00</option>
													<option value="2">7.00 - 8.00</option>
													<option value="3">8.10 - 9.00</option>
													<option value="4">> 9.00</option>
												<?php } ?>
											</select>
										</div>

										<div class="form-group">
											<label>Rerata Nilai Raport <i class="asterik">*</i></label>
											<select class="form-control input" required="required" name="rerata_nilai_raport">
												<?php if($value->rerata_nilai_raport == null || $value->rerata_nilai_raport == '0') { ?>	
													<option value="">-Pilih SalahSatu-</option>
													<option value="1">< 7.00</option>
													<option value="2">7.00 - 8.00</option>
													<option value="3">8.10 - 9.00</option>
													<option value="4">> 9.00</option>
												<?php }else{ ?>
													<option value="<?php echo $value->rerata_nilai_raport; ?>"><?php 
														if($value->rerata_nilai_un == '1'){
															echo "< 7.00";
														}else if($value->rerata_nilai_un == '2'){
															echo "7.00 - 8.00";
														}else if($value->rerata_nilai_un == '3'){
															echo "8.10 - 9.00";
														}else if($value->rerata_nilai_un == '4'){
															echo "> 9.00";
														}
													?></option>
													<option value="">--</option>
													<option value="1">< 7.00</option>
													<option value="2">7.00 - 8.00</option>
													<option value="3">8.10 - 9.00</option>
													<option value="4">> 9.00</option>
												<?php } ?>
											</select>
										</div>

										<div class="form-group">
											<label>Prestasi Akademik <i class="asterik">*</i></label>
											<select class="form-control input" required="required" name="prestasi_akademik">
												<?php if($value->prestasi_akademik == null) { ?>
														<option value="">-Pilih SalahSatu-</option>
														<option value="0">Tidak Ada Prestasi</option>
														<option value="1">Tingkat Lokal</option>
														<option value="2">Tingkat Regional</option>
														<option value="3">Tingkat Nasional</option>
														<option value="4">Tingkat Internasional</option>
													<?php }else{ ?>
														<option value="<?php echo $value->prestasi_akademik; ?>">
															<?php
																if($value->prestasi_akademik == '0'){
																	echo "Tidak Ada Prestasi";
																}else if($value->prestasi_akademik == '1'){
																	echo "Tingkat Lokal";
																}else if($value->prestasi_akademik == '2'){
																	echo "Tingkat Regional";
																}else if($value->prestasi_akademik == '3'){
																	echo "Tingkat Nasional";
																}else if($value->prestasi_akademik == '4'){
																	echo "Tingkat Internasional";
																}
															?>
													</option>
													<option value="">--</option>
													<option value="0">Tidak Ada Prestasi</option>
													<option value="1">Tingkat Lokal</option>
													<option value="2">Tingkat Regional</option>
													<option value="3">Tingkat Nasional</option>
													<option value="4">Tingkat Internasional</option>
												<?php } ?>
											</select>
										</div>

										<div class="form-group">
											<label>Prestasi Non Akademik <i class="asterik">*</i></label>
											<select class="form-control input" required="required" name="prestasi_non_akademik">
												<?php if($value->prestasi_non_akademik == null) { ?>
													<option value="">-Pilih SalahSatu-</option>
													<option value="0">Tidak Ada Prestasi</option>
													<option value="1">Tingkat Lokal</option>
													<option value="2">Tingkat Regional</option>
													<option value="3">Tingkat Nasional</option>
													<option value="4">Tingkat Internasional</option>
												<?php }else{ ?>
													<option value="<?php echo $value->prestasi_non_akademik; ?>">
														<?php
															if($value->prestasi_akademik == '0'){
																echo "Tidak Ada Prestasi";
															}else if($value->prestasi_akademik == '1'){
																echo "Tingkat Lokal";
															}else if($value->prestasi_akademik == '2'){
																echo "Tingkat Regional";
															}else if($value->prestasi_akademik == '3'){
																echo "Tingkat Nasional";
															}else if($value->prestasi_akademik == '4'){
																echo "Tingkat Internasional";
															}
														?>
													</option>
													<option value="">--</option>
													<option value="0">Tidak Ada Prestasi</option>
													<option value="1">Tingkat Lokal</option>
													<option value="2">Tingkat Regional</option>
													<option value="3">Tingkat Nasional</option>
													<option value="4">Tingkat Internasional</option>
												<?php } ?>
											</select>
										</div>
										<!--div class="table-responsive">
											<table class="table">					
												<tr class="form-group">
													<td class="input">Alamat Sekolah</td>
													<td>:</td>
													<td>
														<textarea class="form-control input" type="text" name="alamat_sekolah" placeholder="Alamat Sekolah Anda" required="required"><?php echo $value->alamat_sekolah; ?></textarea>
													</td>
													<td><i class="asterik">*</i></td>
												</tr>

												<tr class="form-group">
													<td class="input">RT Sekolah</td>
													<td>:</td>
													<td>
														<input class="form-control input" type="number" name="rt_5" placeholder="Rukun Tetangga" required="required" value="<?php echo $value->rt_5; ?>">
													</td>
													<td><i class="asterik">*</i></td>
												</tr>

												<tr class="form-group">
													<td class="input">RW Sekolah</td>
													<td>:</td>
													<td>
														<input class="form-control input" type="number" name="rw_5" placeholder="Rukun Warga" required="required" value="<?php echo $value->rw_5; ?>">
													</td>
													<td><i class="asterik">*</i></td>
												</tr>

												<tr class="form-group">
													<td class="input">Kelurahan Sekolah</td>
													<td>:</td>
													<td>
														<input class="form-control input" type="text" name="kelurahan_5" placeholder="Kelurahan Sekolah Anda" required="required" value="<?php echo $value->kelurahan_5; ?>">
													</td>
													<td><i class="asterik">*</i></td>
												</tr>

												<tr class="form-group">
													<td class="input">Kecamatan Sekolah</td>
													<td>:</td>
													<td>
														<input class="form-control input" type="text" name="kecamatan_5" placeholder="Kecamatan Sekolah Anda" required="required" value="<?php echo $value->kecamatan_5; ?>">
													</td>
													<td><i class="asterik">*</i></td>
												</tr>

												<tr class="form-group">
													<td class="input">Provinsi Sekolah</td>
													<td>:</td>
													<td>
														<select class="form-control input" required="required" name="provinsi_sekolah" id="provinsi3">
															<?php 
															if($value->prov_sekolah == null || $value->prov_sekolah == '0') { ?>
																<option value="">-Pilih SalahSatu-</option>
																<?php
																	//melakukan looping dari fungsi index di controller C_mhs
																	foreach($propinsi as $data){
																		echo "<option value='".$data->id_propinsi."'>".$data->nama_propinsi."</option>";
																	}
																}else{	
																?>
																<?php foreach ($propinsi as $x_prov) {
																	if($value->prov_sekolah == $x_prov->id_propinsi){
																?>
																	<option value="<?php echo $x_prov->id_propinsi; ?>">
																		<?php		
																				echo $x_prov->nama_propinsi;
																				}
																			} 
																		?>
																	</option>	
																	<option value="">--</option>
																<?php
																	//melakukan looping dari fungsi index di controller C_mhs
																	foreach($propinsi as $data){
																		echo "<option value='".$data->id_propinsi."'>".$data->nama_propinsi."</option>";
																	}
																} 
															?>
														</select>
													</td>
													<td><i class="asterik">*</i></td>
												</tr>

												<tr class="form-group">
													<td class="input">Kab/Kota Sekolah</td>
													<td>:</td>
													<td>
														<?php if($value->kab_kota_sekolah == null || $value->kab_kota_sekolah == '0') { ?>
															<select class="form-control input" required="required" name="kab_kota_sekolah" id="kota3">
																<option value="">-Pilih SalahSatu-</option>
															</select>
															<div id="loading3">
																<img src="<?=base_url('assets/img/loading.gif'); ?>"><small>Loading..</small>
															</div>
														<?php }else{ ?>
															<select class="form-control input" required="required" name="kab_kota_sekolah" id="kota3">
														<?php
															foreach ($kota as $x_kota) {
																if($value->kab_kota_sekolah == $x_kota->id_kota) {
														?>
																<option value="<?php echo $x_kota->id_kota; ?>">
																<?php		
																			echo $x_kota->nama_kota;
																		}
																	}
																?>
																</option>
																<option value="">--</option>
															</select>
															<div id="loading3">
																<img src="<?=base_url('assets/img/loading.gif'); ?>"><small>Loading..</small>
															</div>
														<?php } ?>
													</td>
													<td><i class="asterik">*</i></td>
												</tr>

												<tr class="form-group">
													<td class="input">Nama Sekolah</td>
													<td>:</td>
													<td>
														<textarea class="form-control input" type="text" name="nama_sekolah" placeholder="Nama Sekolah Anda" required="required"><?php echo $value->nama_sekolah; ?></textarea>
														<td><i class="asterik">*</i></td>
													</td>
												</tr>

												<tr class="form-group">
													<td class="input">Tahun Lulus</td>
													<td>:</td>
													<td>
														<select class="form-control input" required="required" name="tahun_lulus">
															<?php if($value->tahun_lulus == null || $value->tahun_lulus == '0') { ?>	
																<option value="">-Pilih SalahSatu-</option>
																<?php foreach($tahun_lulus as $x_tahun) { ?>
																<option value="<?php echo $x_tahun->tahun_lulus; ?>"><?php echo $x_tahun->tahun_lulus; ?></option>
																<?php } ?>
															<?php }else { ?>
																<option value="<?php echo $value->tahun_lulus; ?>"><?php echo $value->tahun_lulus; ?></option>
																<option value="">--</option>
																<?php foreach($tahun_lulus as $x_tahun) { ?>
																<option value="<?php echo $x_tahun->tahun_lulus; ?>"><?php echo $x_tahun->tahun_lulus; ?></option>
																<?php } ?>
															<?php } ?>
														</select>
													</td>
													<td><i class="asterik">*</i></td>
												</tr>

												<tr class="form-group">
													<td class="input">Jurusan di Sekolah</td>
													<td>:</td>
													<td>
														<select class="form-control input" required="required" name="jurusan_sekolah">
															<?php if($value->jurusan_sekolah == null) { ?>	
																<option value="">-Pilih SalahSatu-</option>
																<option value="IPA">IPA</option>
																<option value="IPS">IPS</option>
																<option value="Bahasa">Bahasa</option>
																<option value="Teknik">Teknik</option>
																<option value="Pertanian">Pertanian</option>
																<option value="Ekonomi">Ekonomi</option>
																<option value="Seni">Seni</option>
																<option value="Pariwisata">Pariwisata</option>
																<option value="Agama">Agama</option>
																<option value="Lain - Lain">Lain - Lain</option>
															<?php }else{ ?>
																<option value="<?php echo $value->jurusan_sekolah; ?>"><?php echo $value->jurusan_sekolah; ?></option>
																<option value="">--</option>
																<option value="IPA">IPA</option>
																<option value="IPS">IPS</option>
																<option value="Bahasa">Bahasa</option>
																<option value="Teknik">Teknik</option>
																<option value="Pertanian">Pertanian</option>
																<option value="Ekonomi">Ekonomi</option>
																<option value="Seni">Seni</option>
																<option value="Pariwisata">Pariwisata</option>
																<option value="Agama">Agama</option>
																<option value="Lain - Lain">Lain - Lain</option>
															<?php } ?>
														</select>
													</td>
													<td><i class="asterik">*</i></td>
												</tr>

												<tr class="form-group">
													<td class="input">Rerata Nilai UN</td>
													<td>:</td>
													<td>
														<select class="form-control input" required="required" name="rerata_nilai_un">
															<?php if($value->rerata_nilai_un == null || $value->rerata_nilai_un == '0') { ?>	
																<option value="">-Pilih SalahSatu-</option>
																<option value="1">< 7.00</option>
																<option value="2">7.00 - 8.00</option>
																<option value="3">8.10 - 9.00</option>
																<option value="4">> 9.00</option>
															<?php }else{ ?>
																<option value="<?php echo $value->rerata_nilai_un; ?>"><?php 
																	if($value->rerata_nilai_un == '1'){
																		echo "< 7.00";
																	}else if($value->rerata_nilai_un == '2'){
																		echo "7.00 - 8.00";
																	}else if($value->rerata_nilai_un == '3'){
																		echo "8.10 - 9.00";
																	}else if($value->rerata_nilai_un == '4'){
																		echo "> 9.00";
																	}
																?></option>
																<option value="">--</option>
																<option value="1">< 7.00</option>
																<option value="2">7.00 - 8.00</option>
																<option value="3">8.10 - 9.00</option>
																<option value="4">> 9.00</option>
															<?php } ?>
														</select>
													</td>
													<td><i class="asterik">*</i></td>
												</tr>

												<tr class="form-group">
													<td class="input">Rerata Nilai Raport Sekolah</td>
													<td>:</td>
													<td>
														<select class="form-control input" required="required" name="rerata_nilai_raport">
															<?php if($value->rerata_nilai_raport == null || $value->rerata_nilai_raport == '0') { ?>	
																<option value="">-Pilih SalahSatu-</option>
																<option value="1">< 7.00</option>
																<option value="2">7.00 - 8.00</option>
																<option value="3">8.10 - 9.00</option>
																<option value="4">> 9.00</option>
															<?php }else{ ?>
																<option value="<?php echo $value->rerata_nilai_raport; ?>"><?php 
																	if($value->rerata_nilai_un == '1'){
																		echo "< 7.00";
																	}else if($value->rerata_nilai_un == '2'){
																		echo "7.00 - 8.00";
																	}else if($value->rerata_nilai_un == '3'){
																		echo "8.10 - 9.00";
																	}else if($value->rerata_nilai_un == '4'){
																		echo "> 9.00";
																	}
																?></option>
																<option value="">--</option>
																<option value="1">< 7.00</option>
																<option value="2">7.00 - 8.00</option>
																<option value="3">8.10 - 9.00</option>
																<option value="4">> 9.00</option>
															<?php } ?>
														</select>
													</td>
													<td><i class="asterik">*</i></td>
												</tr>	

												<tr class="form-group">
													<td class="input">Prestasi Akademik Terbaik</td>
													<td>:</td>
													<td>
														<select class="form-control input" required="required" name="prestasi_akademik">
															<?php if($value->prestasi_akademik == null) { ?>
																	<option value="">-Pilih SalahSatu-</option>
																	<option value="0">Tidak Ada Prestasi</option>
																	<option value="1">Tingkat Lokal</option>
																	<option value="2">Tingkat Regional</option>
																	<option value="3">Tingkat Nasional</option>
																	<option value="4">Tingkat Internasional</option>
																<?php }else{ ?>
																	<option value="<?php echo $value->prestasi_akademik; ?>">
																		<?php
																			if($value->prestasi_akademik == '0'){
																				echo "Tidak Ada Prestasi";
																			}else if($value->prestasi_akademik == '1'){
																				echo "Tingkat Lokal";
																			}else if($value->prestasi_akademik == '2'){
																				echo "Tingkat Regional";
																			}else if($value->prestasi_akademik == '3'){
																				echo "Tingkat Nasional";
																			}else if($value->prestasi_akademik == '4'){
																				echo "Tingkat Internasional";
																			}
																		?>
																</option>
																<option value="">--</option>
																<option value="0">Tidak Ada Prestasi</option>
																<option value="1">Tingkat Lokal</option>
																<option value="2">Tingkat Regional</option>
																<option value="3">Tingkat Nasional</option>
																<option value="4">Tingkat Internasional</option>
															<?php } ?>
														</select>
													</td>
													<td><i class="asterik">*</i></td>
												</tr>

												<tr class="form-group">
													<td class="input">Prestasi Non Akademik Terbaik</td>
													<td>:</td>
													<td>
														<select class="form-control input" required="required" name="prestasi_non_akademik">
															<?php if($value->prestasi_non_akademik == null) { ?>
																<option value="">-Pilih SalahSatu-</option>
																<option value="0">Tidak Ada Prestasi</option>
																<option value="1">Tingkat Lokal</option>
																<option value="2">Tingkat Regional</option>
																<option value="3">Tingkat Nasional</option>
																<option value="4">Tingkat Internasional</option>
															<?php }else{ ?>
																<option value="<?php echo $value->prestasi_non_akademik; ?>">
																	<?php
																		if($value->prestasi_akademik == '0'){
																			echo "Tidak Ada Prestasi";
																		}else if($value->prestasi_akademik == '1'){
																			echo "Tingkat Lokal";
																		}else if($value->prestasi_akademik == '2'){
																			echo "Tingkat Regional";
																		}else if($value->prestasi_akademik == '3'){
																			echo "Tingkat Nasional";
																		}else if($value->prestasi_akademik == '4'){
																			echo "Tingkat Internasional";
																		}
																	?>
																</option>
																<option value="">--</option>
																<option value="0">Tidak Ada Prestasi</option>
																<option value="1">Tingkat Lokal</option>
																<option value="2">Tingkat Regional</option>
																<option value="3">Tingkat Nasional</option>
																<option value="4">Tingkat Internasional</option>
															<?php } ?>
														</select>
													</td>
													<td><i class="asterik">*</i></td>
												</tr>								
											</table>
										</div-->
									</div>

									<div class="modal-footer">
										<button type="button" class="btn btn-default" data-dismiss="modal">Tutup</button>
										<button type="submit" class="btn btn-primary">Simpan</button>
									</div>

								</div>
							</div>
						</div>
					</form>
					<!--End Modal Data Sekolah -->
					<?php } ?>
				</div>
			</div>
		</div>
	</body>

	<div style="text-align: center;">
		<?php
			$this->load->view('project_bidikmisi/footer/footer');
		?>
	</div>
</html>
