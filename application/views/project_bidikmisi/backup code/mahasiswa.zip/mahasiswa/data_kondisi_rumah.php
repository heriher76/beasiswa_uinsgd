<?php
	$this->load->view('project_bidikmisi/header/mahasiswa/header3_mhs');
	$this->load->view('project_bidikmisi/mahasiswa/navbar_mhs');
?>
<!DOCTYPE html>
<html>
	<body>
		<div class="container-fluid">
			<div class="">
				<div class="row">
					<div class="notif notifikasi col-md-offset-8">
						<?php echo $this->session->flashdata('direct4_success'); ?>
					</div>

					<!--Sidebar-->
					<div class="col-md-3" style="padding-bottom: 40px;">
						<div class="sidebar-buat col-md-12 col-md-offset-1">
							<h3>Tahapan Bidikmisi</h3>
						</div>

						<div class="list-group col-md-12 col-md-offset-1">
							<a href="<?=base_url('C_mhs'); ?>" class="list-group-item input">Tahap 1 Upload Foto</a>
							<a href="<?=base_url('C_mhs/step2'); ?>" class="list-group-item input">Tahap 2 Identitas Diri</a>
							<a href="<?=base_url('C_mhs/step3'); ?>" class="list-group-item input">Tahap 3 Data Ortu</a>
							<a href="<?=base_url('C_mhs/step4'); ?>" class="list-group-item input active">Tahap 4 Data Kondisi Rumah</a>
							<a href="<?=base_url('C_mhs/step5'); ?>" class="list-group-item input">Tahap 5 Data Sekolah</a>
							<a href="<?=base_url('C_mhs/step6'); ?>" class="list-group-item input">Tahap 6 Data Pesantren</a>
							<a href="<?=base_url('C_mhs/step7'); ?>" class="list-group-item input">Tahap 7 Keterampilan</a>
							<a href="<?=base_url('C_mhs/step8'); ?>" class="list-group-item input">Tahap 8 Upload Dokumen Pendukung</a>
							<a href="<?=base_url('C_mhs/step9'); ?>" class="list-group-item input">Tahap 9 Persyaratan Dokumen</a>
							<a href="<?=base_url('C_mhs/step10'); ?>" class="list-group-item input">Tahap 10 Verifikasi Data</a> 
						</div>
					</div>
					<!--End Sidebar-->

					<div class="col-md-4" style="text-align: center;">
					    <div class="col-md-offset-2">
    						<h3>RULE Tahap 4 (Data Kondisi Rumah)</h3>
    						<div class="penting">
    							<p>Tanda Asterik (*) Wajib diisi</p>
    						</div>
    						
    						<p>Silahkan klik Tombol EDIT dibawah, jika ada kesalahan/data anda belum diisi</p>
    						<p>Jika sudah diisi Silahkan klik Tombol Lanjut</p>
    					</div>	
					</div>


				<?php foreach ($data_diri as $value) { ?>
					<div class="col-md-4">
						<div class="tahap">
							<h3>Tahap 4</h3>
						</div>
						<!--Data Kondisi Rumah-->
						<div id="data-kondisi-rumah">
							<h2><b><u>Data Kondisi Rumah</u></b></h2>
						</div>

						<table class="table">
							<tr>
								<td>Luas Rumah</td>
								<td>:</td>
								<td><?php 
									if($value->luas_rumah == '1'){
										echo "> 120 Meter Persegi";
									}else if($value->luas_rumah == '2'){
										echo "81 - 120 Meter Persegi";
									}else if($value->luas_rumah == '3'){
										echo "41 - 80 Meter Persegi";
									}else if($value->luas_rumah == '4'){
										echo "< 40 Meter Persegi";
									}
								?></td>
								<td><b class="asterik">*</b></td>
							</tr>

							<tr>
								<td>Pajak Bumi Bangunan</td>
								<td>:</td>
								<td><?php
									if($value->pbb == '1'){
										echo "> 100.000";
									}else if($value->pbb == '2'){
										echo "76.000 - 100.000";
									}else if($value->pbb == '3'){
										echo "26.000 - 75.000";
									}else if($value->pbb == '4'){
										echo "< 25.000";
									}
								?></td>
								<td><b class="asterik">*</b></td>
							</tr>

							<tr>
								<td>Rekening Listrik/Bulan</td>
								<td>:</td>
								<td><?php
									if($value->rek_listrik_per_bulan == '1'){
										echo "> 100.000";
									}else if($value->rek_listrik_per_bulan == '2'){
										echo "76.000 - 100.000";
									}else if($value->rek_listrik_per_bulan == '3'){
										echo "26.000 - 75.000";
									}else if($value->rek_listrik_per_bulan == '4'){
										echo "< 25.000";
									}
								?></td>
								<td><b class="asterik">*</b></td>
							</tr>
						</table>
						<!--End Data Kondisi Rumah-->	

						<!--button-->
						<div class="button-all">
							<div class="col-md-12 col-md-offset-2">	
								<a href="<?=base_url('C_mhs/step3'); ?>" class="btn btn-info">
									<i class="fa fa-check-circle-o"></i>
									&laquo; Kembali
								</a>

								<button data-target="#edit-data-kondisi-rumah" data-toggle="modal" class="btn btn-primary" value="Edit" type="submit">
									<i class="glyphicon glyphicon-edit"></i>
									Edit
								</button>

								<a href="<?=base_url('C_mhs/step5'); ?>" class="btn btn-info">
									<i class="fa fa-check-circle-o"></i>
									Lanjut &raquo;
								</a>
							</div>
						</div>
						<!--End button-->
					</div>
					<div class="clear"></div>

					<!--Moda Data Kondisi Rumah-->
					<form action="<?=base_url('C_mhs/direct4'); ?>" method="POST">
						<div id="edit-data-kondisi-rumah" class="modal fade">
							<div class="modal-dialog">
								<div class="modal-content">
									<div class="modal-header">
										<button type="button" class="close" data-dismiss="modal">&times;</button>
										<h4 class="modal-title">Edit Data Kondisi Rumah</h4>
									</div>

									<div class="modal-body">
										<div class="form-group">
											<label>Luas Rumah <i class="asterik">*</i></label>
											<select class="form-control input" required="required" name="luas_rumah">
												<?php if($value->luas_rumah == null || $value->luas_rumah == '0') { ?>
													<option value="">-Pilih SalahSatu-</option>
													<option value="1">> 120 Meter Persegi</option>
													<option value="2">81 - 120 Meter Persegi</option>
													<option value="3">41 - 80 Meter Persegi</option>
													<option value="4">< 40 Meter Persegi</option>
												<?php }else{ ?>
													<option value="<?php echo $value->luas_rumah; ?>"><?php 
														if($value->luas_rumah == '1'){
															echo "> 120 Meter Persegi";
														}else if($value->luas_rumah == '2'){
															echo "81 - 120 Meter Persegi";
														}else if($value->luas_rumah == '3'){
															echo "41 - 80 Meter Persegi";
														}else if($value->luas_rumah == '4'){
															echo "< 40 Meter Persegi";
														}
													?></option>
													<option value="">--</option>
													<option value="1">> 120 Meter Persegi</option>
													<option value="2">81 - 120 Meter Persegi</option>
													<option value="3">41 - 80 Meter Persegi</option>
													<option value="4">< 40 Meter Persegi</option>
												<?php } ?>
											</select>
										</div>

										<div class="form-group">
											<label>Pajak Bumi Bangunan (PBB) <i class="asterik">*</i></label>
											<select class="form-control input" required="required" name="pbb">
												<?php if($value->pbb == null || $value->pbb == '0') { ?>	
													<option value="">-Pilih SalahSatu-</option>
													<option value="1">> 100.000</option>
													<option value="2">76.000 - 100.000</option>
													<option value="3">26.000 - 75.000</option>
													<option value="4">< 25.000</option>
												<?php }else{ ?>
													<option value="<?php echo $value->pbb; ?>"><?php
														if($value->pbb == '1'){
															echo "> 100.000";
														}else if($value->pbb == '2'){
															echo "76.000 - 100.000";
														}else if($value->pbb == '3'){
															echo "26.000 - 75.000";
														}else if($value->pbb == '4'){
															echo "< 25.000";
														}
													?></option>
													<option value="">--</option>
													<option value="1">> 100.000</option>
													<option value="2">76.000 - 100.000</option>
													<option value="3">26.000 - 75.000</option>
													<option value="4">< 25.000</option>
												<?php } ?>
											</select>
										</div>

										<div class="form-group">
											<label>Rekening Listrik Per Bulan <i class="asterik">*</i></label>
											<select class="form-control input" required="required" name="rek_listrik_per_bulan">
												<?php if($value->rek_listrik_per_bulan == null || $value->rek_listrik_per_bulan == '0') { ?>	
													<option value="">-Pilih SalahSatu-</option>
													<option value="1">> 100.000</option>
													<option value="2">76.000 - 100.000</option>
													<option value="3">26.000 - 75.000</option>
													<option value="4">< 25.000</option>
												<?php }else{ ?>
													<option value="<?php echo $value->rek_listrik_per_bulan; ?>"><?php
														if($value->rek_listrik_per_bulan == '1'){
															echo "> 100.000";
														}else if($value->rek_listrik_per_bulan == '2'){
															echo "76.000 - 100.000";
														}else if($value->rek_listrik_per_bulan == '3'){
															echo "26.000 - 75.000";
														}else if($value->rek_listrik_per_bulan == '4'){
															echo "< 25.000";
														}
													?></option>
													<option value="">--</option>
													<option value="1">> 100.000</option>
													<option value="2">76.000 - 100.000</option>
													<option value="3">26.000 - 75.000</option>
													<option value="4">< 25.000</option>
												<?php } ?>
											</select>
										</div>
										<!--div class="table-responsive">
											<table class="table">
												<tr class="form-group">
													<td class="input">Luas Rumah</td>
													<td>:</td>
													<td>
														<select class="form-control input" required="required" name="luas_rumah">
															<?php if($value->luas_rumah == null || $value->luas_rumah == '0') { ?>
																<option value="">-Pilih SalahSatu-</option>
																<option value="1">> 120 Meter Persegi</option>
																<option value="2">81 - 120 Meter Persegi</option>
																<option value="3">41 - 80 Meter Persegi</option>
																<option value="4">< 40 Meter Persegi</option>
															<?php }else{ ?>
																<option value="<?php echo $value->luas_rumah; ?>"><?php 
																	if($value->luas_rumah == '1'){
																		echo "> 120 Meter Persegi";
																	}else if($value->luas_rumah == '2'){
																		echo "81 - 120 Meter Persegi";
																	}else if($value->luas_rumah == '3'){
																		echo "41 - 80 Meter Persegi";
																	}else if($value->luas_rumah == '4'){
																		echo "< 40 Meter Persegi";
																	}
																?></option>
																<option value="">--</option>
																<option value="1">> 120 Meter Persegi</option>
																<option value="2">81 - 120 Meter Persegi</option>
																<option value="3">41 - 80 Meter Persegi</option>
																<option value="4">< 40 Meter Persegi</option>
															<?php } ?>
														</select>
													</td>
													<td><i class="asterik">*</i></td>
												</tr>

												<tr class="form-group">
													<td class="input">Pajak Bumi Bangunan (PBB) Pertahun</td>
													<td>:</td>
													<td>
														<select class="form-control input" required="required" name="pbb">
															<?php if($value->pbb == null || $value->pbb == '0') { ?>	
																<option value="">-Pilih SalahSatu-</option>
																<option value="1">> 100.000</option>
																<option value="2">76.000 - 100.000</option>
																<option value="3">26.000 - 75.000</option>
																<option value="4">< 25.000</option>
															<?php }else{ ?>
																<option value="<?php echo $value->pbb; ?>"><?php
																	if($value->pbb == '1'){
																		echo "> 100.000";
																	}else if($value->pbb == '2'){
																		echo "76.000 - 100.000";
																	}else if($value->pbb == '3'){
																		echo "26.000 - 75.000";
																	}else if($value->pbb == '4'){
																		echo "< 25.000";
																	}
																?></option>
																<option value="">--</option>
																<option value="1">> 100.000</option>
																<option value="2">76.000 - 100.000</option>
																<option value="3">26.000 - 75.000</option>
																<option value="4">< 25.000</option>
															<?php } ?>
														</select>
													</td>
													<td><i class="asterik">*</i></td>
												</tr>

												<tr class="form-group">
													<td class="input">Rekening Listrik Perbulan</td>
													<td>:</td>
													<td>
														<select class="form-control input" required="required" name="rek_listrik_per_bulan">
															<?php if($value->rek_listrik_per_bulan == null || $value->rek_listrik_per_bulan == '0') { ?>	
																<option value="">-Pilih SalahSatu-</option>
																<option value="1">> 100.000</option>
																<option value="2">76.000 - 100.000</option>
																<option value="3">26.000 - 75.000</option>
																<option value="4">< 25.000</option>
															<?php }else{ ?>
																<option value="<?php echo $value->rek_listrik_per_bulan; ?>"><?php
																	if($value->rek_listrik_per_bulan == '1'){
																		echo "> 100.000";
																	}else if($value->rek_listrik_per_bulan == '2'){
																		echo "76.000 - 100.000";
																	}else if($value->rek_listrik_per_bulan == '3'){
																		echo "26.000 - 75.000";
																	}else if($value->rek_listrik_per_bulan == '4'){
																		echo "< 25.000";
																	}
																?></option>
																<option value="">--</option>
																<option value="1">> 100.000</option>
																<option value="2">76.000 - 100.000</option>
																<option value="3">26.000 - 75.000</option>
																<option value="4">< 25.000</option>
															<?php } ?>
														</select>
													</td>
													<td><i class="asterik">*</i></td>
												</tr>
											</table>
										</div-->
									</div>

									<div class="modal-footer">
										<button type="button" class="btn btn-default" data-dismiss="modal">Tutup</button>
										<button type="submit" class="btn btn-primary">Simpan</button>
									</div>

									</div>
								</div>
							</div>
						</form>
						<!--Moda Data Kondisi Rumah-->
					<?php } ?>
				</div>
			</div>
		</div>
	</body>
	<div style="text-align: center;">	
		<?php
			$this->load->view('project_bidikmisi/footer/footer');
		?>
	</div>
</html>
