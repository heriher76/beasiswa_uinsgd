<?php
	$this->load->view('project_bidikmisi/header/mahasiswa/header3_mhs');
	$this->load->view('project_bidikmisi/mahasiswa/navbar_mhs');
?>

<!DOCTYPE html>
<html>
	<body>
		<div class="container-fluid">
			<div class="">
				<div class="row">
					<div class="notif notifikasi col-md-offset-8">
						<?php echo $this->session->flashdata('direct7_success'); ?>
					</div>

					<!--Sidebar-->
					<div class="col-md-3" style="padding-bottom: 40px;">
						<div class="sidebar-buat col-md-12 col-md-offset-1">
							<h3>Tahapan Bidikmisi</h3>
						</div>

						<div class="list-group col-md-12 col-md-offset-1">
							<a href="<?=base_url('C_mhs'); ?>" class="list-group-item input">Tahap 1 Upload Foto</a>
							<a href="<?=base_url('C_mhs/step2'); ?>" class="list-group-item input">Tahap 2 Identitas Diri</a>
							<a href="<?=base_url('C_mhs/step3'); ?>" class="list-group-item input">Tahap 3 Data Ortu</a>
							<a href="<?=base_url('C_mhs/step4'); ?>" class="list-group-item input">Tahap 4 Data Kondisi Rumah</a>
							<a href="<?=base_url('C_mhs/step5'); ?>" class="list-group-item input">Tahap 5 Data Sekolah</a>
							<a href="<?=base_url('C_mhs/step6'); ?>" class="list-group-item input">Tahap 6 Data Pesantren</a>
							<a href="<?=base_url('C_mhs/step7'); ?>" class="list-group-item input active">Tahap 7 Keterampilan</a>
							<a href="<?=base_url('C_mhs/step8'); ?>" class="list-group-item input">Tahap 8 Upload Dokumen Pendukung</a>
							<a href="<?=base_url('C_mhs/step9'); ?>" class="list-group-item input">Tahap 9 Persyaratan Dokumen</a>
							<a href="<?=base_url('C_mhs/step10'); ?>" class="list-group-item input">Tahap 10 Verifikasi Data</a> 
						</div>
					</div>
					<!--End Sidebar-->

					<div class="col-md-4" style="text-align: center;">
    					<div class="col-md-offset-2">
    						<h3>RULE Tahap 7 (Data Keterampilan)</h3>
    						<div class="penting">
    							<p>Tanda Asterik (*) Wajib diisi</p>
    						</div>
    						
    						<p>Silahkan klik Tombol EDIT dibawah, jika ada kesalahan/data anda belum diisi</p>
    						<p>Jika sudah diisi Silahkan klik Tombol Lanjut</p>
    					</div>
					</div>

					<?php foreach($data_diri as $value) { ?>
					<div class="col-md-4">
						<div class="tahap">	
							<h3>Tahap 7</h3>
						</div>
						<!--Keterampilan-->
						<div id="keterampilan">
							<h2><b><u>Keterampilan</u></b></h2>
						</div>

						<table class="table">
							<tr>
								<td>Kemampuan Bahasa Arab</td>
								<td>:</td>
								<td><?php echo $value->kem_bhs_arab; ?></td>
								<td><i class="asterik">*</i></td>
							</tr>

							<tr>
								<td>Kemampuan Bahasa Inggris</td>
								<td>:</td>
								<td><?php echo $value->kem_bhs_inggris; ?></td>
								<td><i class="asterik">*</i></td>
							</tr>

							<tr>
								<td>Kemampuan Komputer</td>
								<td>:</td>
								<td><?php echo $value->kem_komputer; ?></td>
								<td><i class="asterik">*</i></td>
							</tr>
						</table>
						<!--End Keterampilan-->

						<!--button-->
						<div id="button-all">
							<div class="col-md-12 col-md-offset-2">
								<a href="<?=base_url('C_mhs/step6'); ?>" class="btn btn-info">
									<i class="fa fa-check-circle-o"></i>
									&laquo; Kembali
								</a>

								<button data-target="#edit-data-keterampilan" data-toggle="modal" class="btn btn-primary" value="Edit" type="submit">
									<i class="glyphicon glyphicon-edit"></i>
									Edit
								</button>

								<a href="<?=base_url('C_mhs/step8'); ?>" class="btn btn-info">
									<i class="fa fa-check-circle-o"></i>
									Lanjut &raquo;
								</a>
							</div>
						</div>
						<!--End button-->
					</div>

					<!--Modal Update Keterampilan-->
					<form action="<?=base_url('C_mhs/direct7'); ?>" method="POST">
						<div id="edit-data-keterampilan" class="modal fade">
							<div class="modal-dialog">
								<div class="modal-content">
									<div class="modal-header">
										<button type="button" class="close" data-dismiss="modal">&times;</button>
										<h4 class="modal-title">Edit Data Keterampilan</h4>
									</div>

									<div class="modal-body">
										<div class="form-group">
											<label>Kemampuan Bahasa Arab <i class="asterik">*</i></label>
											<select class="form-control input" required="required" name="kemampuan_bahasa_arab">
												<?php if($value->kem_bhs_arab == null || $value->kem_bhs_arab == '0') { ?>	
													<option value="">-Pilih SalahSatu-</option>
													<option value="Tidak Bisa">Tidak Bisa</option>
													<option value="Pasif">Pasif</option>
													<option value="Mahir">Mahir</option>
													<option value="Aktif">Aktif</option>
												<?php }else{ ?>
													<option value="<?php echo $value->kem_bhs_arab; ?>"><?php echo $value->kem_bhs_arab; ?></option>
													<option value="">--</option>
													<option value="Tidak Bisa">Tidak Bisa</option>
													<option value="Pasif">Pasif</option>
													<option value="Mahir">Mahir</option>
													<option value="Aktif">Aktif</option>
												<?php } ?>
											</select>
										</div>

										<div class="form-group">
											<label>Kemampuan Bahasa Inggris <i class="asterik">*</i></label>
											<select class="form-control input" required="required" name="kemampuan_bahasa_inggris">
												<?php if($value->kem_bhs_inggris == null || $value->kem_bhs_inggris == '0') { ?>
													<option value="">-Pilih SalahSatu-</option>
													<option value="Tidak Bisa">Tidak Bisa</option>
													<option value="Pasif">Pasif</option>
													<option value="Mahir">Mahir</option>
													<option value="Aktif">Aktif</option>
												<?php }else{ ?>
													<option value="<?php echo $value->kem_bhs_inggris?>"><?php echo $value->kem_bhs_inggris; ?></option>
													<option value="">--</option>
													<option value="Tidak Bisa">Tidak Bisa</option>
													<option value="Pasif">Pasif</option>
													<option value="Mahir">Mahir</option>
													<option value="Aktif">Aktif</option>
												<?php } ?>
											</select>
										</div>

										<div class="form-group">
											<label>Kemampuan Komputer <i class="asterik">*</i></label>
											<select class="form-control input" required="required" name="kemampuan_komputer">
												<?php if($value->kem_komputer == null || $value->kem_komputer == '0') { ?>	
													<option value="">-Pilih SalahSatu-</option>
													<option value="Tidak Bisa">Tidak Bisa</option>
													<option value="Bisa">Bisa</option>
												<?php }else{ ?>
													<option value="<?php echo $value->kem_komputer; ?>"><?php echo $value->kem_komputer; ?></option>
													<option value="">--</option>
													<option value="Tidak Bisa">Tidak Bisa</option>
													<option value="Bisa">Bisa</option>
												<?php } ?>
											</select>
										</div>
										<!--div class="table-responsive">
											<table class="table">
												<tr class="form-group">
													<td class="input">Kemampuan Bahasa Arab</td>
													<td>:</td>
													<td>
														<select class="form-control input" required="required" name="kemampuan_bahasa_arab">
															<?php if($value->kem_bhs_arab == null || $value->kem_bhs_arab == '0') { ?>	
																<option value="">-Pilih SalahSatu-</option>
																<option value="Tidak Bisa">Tidak Bisa</option>
																<option value="Pasif">Pasif</option>
																<option value="Mahir">Mahir</option>
																<option value="Aktif">Aktif</option>
															<?php }else{ ?>
																<option value="<?php echo $value->kem_bhs_arab; ?>"><?php echo $value->kem_bhs_arab; ?></option>
																<option value="">--</option>
																<option value="Tidak Bisa">Tidak Bisa</option>
																<option value="Pasif">Pasif</option>
																<option value="Mahir">Mahir</option>
																<option value="Aktif">Aktif</option>
															<?php } ?>
														</select>
													</td>
													<td><i class="asterik">*</i></td>
												</tr>	

												<tr class="form-group">
													<td class="input">Kemampuan Bahasa Inggris</td>
													<td>:</td>
													<td>
														<select class="form-control input" required="required" name="kemampuan_bahasa_inggris">
															<?php if($value->kem_bhs_inggris == null || $value->kem_bhs_inggris == '0') { ?>
																<option value="">-Pilih SalahSatu-</option>
																<option value="Tidak Bisa">Tidak Bisa</option>
																<option value="Pasif">Pasif</option>
																<option value="Mahir">Mahir</option>
																<option value="Aktif">Aktif</option>
															<?php }else{ ?>
																<option value="<?php echo $value->kem_bhs_inggris?>"><?php echo $value->kem_bhs_inggris; ?></option>
																<option value="">--</option>
																<option value="Tidak Bisa">Tidak Bisa</option>
																<option value="Pasif">Pasif</option>
																<option value="Mahir">Mahir</option>
																<option value="Aktif">Aktif</option>
															<?php } ?>
														</select>
													</td>
													<td><i class="asterik">*</i></td>
												</tr>

												<tr class="form-group">
													<td class="input">Kemampuan Komputer</td>
													<td>:</td>
													<td>
														<select class="form-control input" required="required" name="kemampuan_komputer">
															<?php if($value->kem_komputer == null || $value->kem_komputer == '0') { ?>	
																<option value="">-Pilih SalahSatu-</option>
																<option value="Tidak Bisa">Tidak Bisa</option>
																<option value="Bisa">Bisa</option>
															<?php }else{ ?>
																<option value="<?php echo $value->kem_komputer; ?>"><?php echo $value->kem_komputer; ?></option>
																<option value="">--</option>
																<option value="Tidak Bisa">Tidak Bisa</option>
																<option value="Bisa">Bisa</option>
															<?php } ?>
														</select>
													</td>
													<td><i class="asterik">*</i></td>
												</tr>					
											</table>
										</div-->
									</div>
									<div class="modal-footer">
										<button type="button" class="btn btn-default" data-dismiss="modal">Tutup</button>
										<button type="submit" class="btn btn-primary">Simpan</button>
									</div>
								</div>
							</div>
						</div>
					</form>
					<?php } ?>
					<!--end Modal Update Keterampilan-->
				</div>
			</div>
		</div>
	</body>
	
	<div style="text-align: center;">	
		<?php
			$this->load->view('project_bidikmisi/footer/footer');
		?>
	</div>
</html>
