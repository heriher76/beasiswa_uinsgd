<?php
	$this->load->view('project_bidikmisi/header/mahasiswa/header3_mhs');
	$this->load->view('project_bidikmisi/mahasiswa/navbar_mhs');
?>
<!DOCTYPE html>
<html>
	<body>
		<div class="container">
			<div class="row">
				<div class="col-md-offset-3 col-md-6">
					<h3><u>Ganti Password</u></h3>
					<form action="<?=base_url('C_mhs/change_password'); ?>" method="POST">
						<table class="table" style="margin-top: 40px;">
							<tr class="form-group">
								<td class="input">Password Baru</td>
								<td>:</td>
								<td><input type="password" class="form-control input" placeholder="Password Baru Anda" name="password_baru" required="required"></td>
							</tr>

							<tr class="form-group">
								<td class="input">Konfirmasi Password Baru</td>
								<td>:</td>
								<td><input type="password" class="form-control input" placeholder="Konfirmasi Password Baru Anda" name="konfirmasi_password_baru" required="required"></td>
							</tr>
						</table>
						<button type="submit" class="btn btn-primary" style="float: right;">Simpan</button>
					</form>
				</div>
			</div>
		</div>
	</body>
</html>
<div style="text-align: center;">
	<?php
		//load footer
		$this->load->view('project_bidikmisi/footer/footer');
	?>
</div>