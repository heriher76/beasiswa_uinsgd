<?php
	$this->load->view('project_bidikmisi/header/mahasiswa/header3_mhs');
    $this->load->view('project_bidikmisi/mahasiswa/navbar_mhs');
?>
<!DOCTYPE html>
<html>
	<body>
		<div class="container">
			<div class="row">
			    <div class="notifikasi notif col-md-offset-9">
					<?php echo $this->session->flashdata('msg_berhasil'); ?>
                </div>
                
				<div class="col-md-offset-3 col-md-6">
					<center>
					<h3>Pengumuman Kelulusan Bidikmisi Tahun <?php echo date('Y'); ?></h3>
					<?php
						date_default_timezone_set('Asia/Jakarta');
   						$tgl_sekarang = date('Y-m-d H:i:s'); 
   						//$tgl_sekarang = date('2018-07-16 13:36:00');
   						$tgl_pengumuman = $this->session->userdata('pengumuman');
   						$tgl_tutup_pengumuman = $this->session->userdata('tutup_pengumuman');
						if($tgl_tutup_pengumuman >= $tgl_sekarang && $tgl_pengumuman <= $tgl_sekarang){
					?>
					</center>
						<div style="background-color:#4682B4; padding:10px; color:white;">
							<h4>Data Mahasiswa Pendaftar</h4>
						</div>
					<center>	
						<?php foreach($data as $value) { ?>
							<?php if($value->getLulus == 'TIDAK LULUS' && $value->reg == 2) { ?>
								<table class="table">
									<tr>
										<td>No Pendaftaran</td>
										<td>:</td>
										<td><?php echo $value->no_pendaftaran; ?></td>
									</tr>

									<tr>
										<td>Nama Mahasiswa</td>
										<td>:</td>
										<td><?php echo $value->nama_mahasiswa; ?></td>
									</tr>

									<tr>
										<td>Fakultas</td>
										<td>:</td>
										<td><?php
											foreach($fakultas as $x_fak){
													if($value->fakultas == $x_fak->id_fakultas){
														echo $x_fak->nama_fakultas;
													}
												} 
										?></td>
									</tr>

									<tr>
										<td>Jurusan</td>
										<td>:</td>
										<td><?php 
										foreach($jurusan as $x_jur){
												if($value->jurusan == $x_jur->id_jurusan){
													echo $x_jur->nama_jurusan;
												}
											} 
										?></td>
									</tr>
								</table>
							<div style="background-color: red; padding:10px; color:white;">
								<p>Anda dinyatakan <u><b><?php echo $value->getLulus; ?></b></u> dalam program Bidikmisi Universitas Islam Negeri Sunan Gunung Djati Bandung Tahun <?php echo date('Y'); ?></p>
							</div>
							<?php }else if($value->getLulus == 'LULUS' && $value->reg == 2) { ?>
								<table class="table">
									<tr>
										<td>No Pendaftaran</td>
										<td>:</td>
										<td><?php echo $value->no_pendaftaran; ?></td>
									</tr>

									<tr>
										<td>Nama Mahasiswa</td>
										<td>:</td>
										<td><?php echo $value->nama_mahasiswa; ?></td>
									</tr>

									<tr>
										<td>Fakultas</td>
										<td>:</td>
										<td><?php
											foreach($fakultas as $x_fak){
													if($value->fakultas == $x_fak->id_fakultas){
														echo $x_fak->nama_fakultas;
													}
												} 
										?></td>
									</tr>

									<tr>
										<td>Jurusan</td>
										<td>:</td>
										<td><?php 
										foreach($jurusan as $x_jur){
												if($value->jurusan == $x_jur->id_jurusan){
													echo $x_jur->nama_jurusan;
												}
											} 
										?></td>
									</tr>
								</table>
							<div style="background-color: green; padding:10px; color:white;">
								<p>Selamat, Anda dinyatakan <u><b><?php echo $value->getLulus; ?></b></u> dalam Tahap 1 program Bidikmisi Universitas Islam Negeri Sunan Gunung Djati Bandung Tahun <?php echo date('Y'); ?>,
								Tahap Selanjutnya Adalah Tahap 2 yaitu Visitasi atau Survey ke Rumah Alamat Calon Penerima Beasiswa Bidikmisi.
								Pengumuman Bidikmisi Akan Ditutup Pada Hari/Tanggal <b><u><?php echo tgl_indonesia($tgl_tutup_pengumuman); ?></u></b>
								</p>
							</div>

							<!--div style="margin-top: 10px;">
								<p>Silahkan Masukan nomor rekening</p>
							</div>

							<?php if($value->rekening_mhs == null || $value->rekening_mhs == 0) { ?>
							<?php }else{ ?>
							    <table class="table">
    							    <tr>
    							        <td>Nama Rekening (Atas Nama)</td>
    							        <td>:</td>
    							        <td><?php echo $value->nama_rekening; ?></td>
    							    </tr>
    							    
    								<tr>
    									<td>Rekening Anda</td>
    									<td>:</td>
    									<td><?php echo $value->rekening_mhs; ?></td>
    								</tr>
								</table>
							<?php } ?>
						</center>

							<button data-target="#masukan-rekening" style="float:right;" data-toggle="modal" class="btn btn-primary" value="Edit" type="submit">
								<span class="glyphicon glyphicon-ok-circle"></span>
								Masukan Rekening
							</button>

							<form action="<?=base_url('C_mhs/insert_rek'); ?>" method="POST">
								<div id="masukan-rekening" class="modal fade">
									<div class="modal-dialog">
										<div class="modal-content">
											<div class="modal-header">
												<button type="button" class="close" data-dismiss="modal">&times;</button>
												<h4 class="modal-title">Rekening Mahasiswa</h4>
											</div>

											<div class="modal-body">
											    <div class="form-group">
											        <p style="color:red;">Rekening yang dimasukkan diharapkan adalah rekening BSM (Bank Syariah Mandiri)</p>
											    </div>
											    
											    <div class="form-group">
											        <label>Nama Rekening (Atas Nama)</label>
											        <input type="text" required="required" name="nama_rekening" class="form-control" value="<?php echo $value->nama_rekening?>">
											    </div>
											    
											    <div class="form-group">
											        <label>Nomor Rekening Anda</label>
											        <input type="number" class="form-control input" name="rekening_mhs" value="<?php echo $value->rekening_mhs; ?>" required="required">
											    </div>
											    
												<!--table class="table">
													<tr>
														<td>Nomor Rekening Anda</td>
														<td>:</td>
														<td><input type="number" class="form-control input" name="rekening_mhs" value="<?php echo $value->rekening_mhs; ?>" required="required"></td>
													</tr>
												</table>
											</div>

											<div class="modal-footer">
												<button type="button" class="btn btn-default" data-dismiss="modal">Tutup</button>
												<button type="submit" class="btn btn-primary">Simpan</button>
											</div-->

										</div>
									</div>
								</div>
							</form>
							<?php }else if($value->getLulus == 'PENDING' && $value->reg == 2) { ?>
								<table class="table">
									<tr>
										<td>No Pendaftaran</td>
										<td>:</td>
										<td><?php echo $value->no_pendaftaran; ?></td>
									</tr>

									<tr>
										<td>Nama Mahasiswa</td>
										<td>:</td>
										<td><?php echo $value->nama_mahasiswa; ?></td>
									</tr>

									<tr>
										<td>Fakultas</td>
										<td>:</td>
										<td><?php
											foreach($fakultas as $x_fak){
													if($value->fakultas == $x_fak->id_fakultas){
														echo $x_fak->nama_fakultas;
													}
												} 
										?></td>
									</tr>

									<tr>
										<td>Jurusan</td>
										<td>:</td>
										<td><?php 
										foreach($jurusan as $x_jur){
												if($value->jurusan == $x_jur->id_jurusan){
													echo $x_jur->nama_jurusan;
												}
											} 
										?></td>
									</tr>
								</table>
							<div style="background-color: #BF9000; padding:10px; color:white;">
								<p>Status Bidikmisi anda masih dinyatakan <u><b><?php echo $value->getLulus; ?></b></u> Silahkan hubungi bagian kemahasiswaan Universitas Islam Negeri Sunan Gunung Djati Bandung.</p>
							</div>
							<?php }else if($value->getLulus == 'LULUS' && $value->reg == 3) { ?>
							    <table class="table">
									<tr>
										<td>No Pendaftaran</td>
										<td>:</td>
										<td><?php echo $value->no_pendaftaran; ?></td>
									</tr>

									<tr>
										<td>Nama Mahasiswa</td>
										<td>:</td>
										<td><?php echo $value->nama_mahasiswa; ?></td>
									</tr>

									<tr>
										<td>Fakultas</td>
										<td>:</td>
										<td><?php
											foreach($fakultas as $x_fak){
													if($value->fakultas == $x_fak->id_fakultas){
														echo $x_fak->nama_fakultas;
													}
												} 
										?></td>
									</tr>

									<tr>
										<td>Jurusan</td>
										<td>:</td>
										<td><?php 
										foreach($jurusan as $x_jur){
												if($value->jurusan == $x_jur->id_jurusan){
													echo $x_jur->nama_jurusan;
												}
											} 
										?></td>
									</tr>
								</table>
							    
							    <div style="background-color: green; padding:10px; color:white;">
								    <p>Selamat, Anda dinyatakan <u><b><?php echo $value->getLulus; ?></b></u> dalam Tahap 2 program Bidikmisi Universitas Islam Negeri Sunan Gunung Djati Bandung Tahun <?php echo date('Y'); ?>,
								    Pengumuman Bidikmisi Akan Ditutup Pada Hari/Tanggal <b><u><?php echo tgl_indonesia($tgl_tutup_pengumuman); ?></u></b>
								    </p>
							    </div>
							<?php } ?>
						<?php } ?>
					<center>
					<?php } else if($tgl_sekarang < $tgl_pengumuman){ ?>
							<div class="alert alert-info">
								<p>Hasil Kelulusan Bidikmisi Anda Belum Keluar, Akan Keluar pada Hari/Tanggal <br/><b><?php echo tgl_indonesia($tgl_pengumuman); ?></b></p>
							</div>
					<?php }else if($tgl_sekarang > $tgl_tutup_pengumuman){ ?>
					        <div class="alert alert-info">
					            <p>Pengumuman Bidikmisi Universitas Islam Negeri Sunan Gunung Djati Bandung Telah di <b><u>TUTUP</u></b>, Silahkan Hubungi Kemahasiswaan Universitas Islam Negeri Sunan Gunung Djati Bandung jika anda belum memasukkan <b><u>Nomor Rekening</u></b> Atau <b><u>Belum Cetak Formulir</u></b></p>
					        </div>
					<?php } ?>
					</center>
				</div>
			</div>
		</div>
	</body>
</html>
<div style="text-align: center;">
	<?php
		//load footer
		$this->load->view('project_bidikmisi/footer/footer');
	?>
</div>