<!DOCTYPE html>
<html>
	<body>
		<!--SideBar-->
		<div class="sidebar-buat col-md-9 col-md-offset-2">
			<h3><u>Side Bar</u></h3>
		</div>

		<div class="list-group col-md-9 col-md-offset-1">
			<a href="<?=base_url('C_mhs'); ?>" class="list-group-item input">Tahap 1 Upload Foto</a>
			<a href="<?=base_url('C_mhs/step2'); ?>" class="list-group-item input">Tahap 2 Identitas Diri</a>
			<a href="<?=base_url('C_mhs/step3'); ?>" class="list-group-item input">Tahap 3 Data Ortu</a>
			<a href="<?=base_url('C_mhs/step4'); ?>" class="list-group-item input">Tahap 4 Data Kondisi Rumah</a>
			<a href="<?=base_url('C_mhs/step5'); ?>" class="list-group-item input">Tahap 5 Data Sekolah</a>
			<a href="<?=base_url('C_mhs/step6'); ?>" class="list-group-item input">Tahap 6 Data Pesantren</a>
			<a href="<?=base_url('C_mhs/step7'); ?>" class="list-group-item input">Tahap 7 Keterampilan</a>
			<a href="<?=base_url('C_mhs/step8'); ?>" class="list-group-item input">Tahap 8 Persyaratan Dokumen</a>	    
		</div>
		<!--End SideBar-->
	</body>
</html>