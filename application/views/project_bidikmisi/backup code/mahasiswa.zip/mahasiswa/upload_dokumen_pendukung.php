<?php
$this->load->view('project_bidikmisi/header/mahasiswa/header3_mhs');
$this->load->view('project_bidikmisi/mahasiswa/navbar_mhs');
?>

<!DOCTYPE html>
<html>
	<body>
		<div class="container-fluid">
			<div class="">
				<div class="row">
					<div class="notif notifikasi col-md-offset-8">
						<?php echo $this->session->flashdata('update8_foto_rumah_depan_error'); ?>
						<?php echo $this->session->flashdata('update8_foto_rumah_depan_success'); ?>
						<?php echo $this->session->flashdata('update8_foto_rumah_kiri_error'); ?>
						<?php echo $this->session->flashdata('update8_foto_rumah_kiri_success'); ?>
						<?php echo $this->session->flashdata('update8_foto_rumah_kanan_error'); ?>
						<?php echo $this->session->flashdata('update8_foto_rumah_kanan_success'); ?>
						<?php echo $this->session->flashdata('update8_foto_pbb_error'); ?>
						<?php echo $this->session->flashdata('update8_foto_pbb_success'); ?>
						<?php echo $this->session->flashdata('update8_foto_rek_listrik_error'); ?>
						<?php echo $this->session->flashdata('update8_foto_rek_listrik_success'); ?>
					</div>

					<!--Sidebar-->
					<div class="col-md-3" style="padding-bottom: 40px;">
						<div class="sidebar-buat col-md-12 col-md-offset-1">
							<h3>Tahapan Bidikmisi</h3>
						</div>

						<div class="list-group col-md-12 col-md-offset-1">
							<a href="<?=base_url('C_mhs'); ?>" class="list-group-item input">Tahap 1 Upload Foto</a>
							<a href="<?=base_url('C_mhs/step2'); ?>" class="list-group-item input">Tahap 2 Identitas Diri</a>
							<a href="<?=base_url('C_mhs/step3'); ?>" class="list-group-item input">Tahap 3 Data Ortu</a>
							<a href="<?=base_url('C_mhs/step4'); ?>" class="list-group-item input">Tahap 4 Data Kondisi Rumah</a>
							<a href="<?=base_url('C_mhs/step5'); ?>" class="list-group-item input">Tahap 5 Data Sekolah</a>
							<a href="<?=base_url('C_mhs/step6'); ?>" class="list-group-item input">Tahap 6 Data Pesantren</a>
							<a href="<?=base_url('C_mhs/step7'); ?>" class="list-group-item input">Tahap 7 Keterampilan</a>
							<a href="<?=base_url('C_mhs/step8'); ?>" class="list-group-item input active">Tahap 8 Upload Dokumen Pendukung</a>
							<a href="<?=base_url('C_mhs/step9'); ?>" class="list-group-item input">Tahap 9 Persyaratan Dokumen</a>	 
							<a href="<?=base_url('C_mhs/step10'); ?>" class="list-group-item input">Tahap 10 Verifikasi Data</a>   
						</div>
					</div>
					<!--End Sidebar-->

					<div class="col-md-4" style="text-align: center;">
    					<div class="col-md-offset-2">	
    						<h3>RULE Tahap 8 (Upload Dokumen Pendukung)</h3>
    						<div class="penting">
    							<p>Maksimal Foto 1 MB</p>
    							<p>Format Foto : JPG, JPEG, dan PNG</p>
    						</div>
    
    						<p>Jika ingin ganti fotonya, silahkan klik tombol EDIT dan ceklis terlebih dahulu foto yang ingin diganti, kemudian masukan fotonya</p>
    						<p>Jika sudah Upload Silahkan klik Tombol Lanjut</p>
    					</div>
					</div>	

					<div class="col-md-4">
						<div class="tahap">
							<h3>Tahap 8</h3>
						</div>
						
					<!--Upload Dokumen Pendukung-->
					<div id="upload-dokumen-pendukung">
						<h2><b><u>Upload Dokumen Pendukung</u></b></h2>
					</div>

					<?php 
						$sess_foto_rumah_depan 	= $this->session->userdata('foto_rumah_depan');
						$sess_foto_rumah_kiri 	= $this->session->userdata('foto_rumah_kiri');
						$sess_foto_rumah_kanan 	= $this->session->userdata('foto_rumah_kanan');
						$sess_foto_pbb 			= $this->session->userdata('foto_pbb');
						$sess_foto_rek_listrik 	= $this->session->userdata('foto_rek_listrik');

						foreach($data_diri as $value) { 
					?>
					<table class="table">
						<!--Rumah depan-->
						<?php if($sess_foto_rumah_depan == null) { ?>
						<tr>
							<td>Foto Rumah Bagian Depan</td>
							<td>:</td>
							<td></td>
							<td><i class="asterik">*</i></td>
						</tr>
						<?php } ?>

						<?php if($sess_foto_rumah_depan != null) { ?>
						<tr>
							<td>Foto Rumah Bagian Depan</td>
							<td>:</td>
							<td><img style="height: 150px;" src="<?php echo base_url(). 'assets/foto_dokumen/'.$value->upload_foto_rumah_depan; ?>"></td>
								<td><i class="asterik">*</i></td>
						</tr>
						<?php } ?>
						<!--end Rumah depan-->

						<!--Rumah kiri-->
						<?php if($sess_foto_rumah_kiri == null) { ?>
						<tr>
							<td>Foto Rumah Bagian Kiri</td>
							<td>:</td>
							<td></td>
							<td><i class="asterik">*</i></td>
						</tr>
						<?php } ?>

						<?php if($sess_foto_rumah_kiri != null) { ?>
						<tr>
							<td>Foto Rumah Bagian Kiri</td>
							<td>:</td>
							<td><img style="height: 150px;" src="<?php echo base_url(). 'assets/foto_dokumen/'.$value->upload_foto_rumah_kiri; ?>"></td>
								<td><i class="asterik">*</i></td>
						</tr>
						<?php } ?>
						<!--end Rumah kiri-->

						<!--Rumah Kanan-->
						<?php if($sess_foto_rumah_kanan == null) { ?>
						<tr>
							<td>Foto Rumah Bagian Kanan</td>
							<td>:</td>
							<td></td>
							<td><i class="asterik">*</i></td>
						</tr>
						<?php } ?>

						<?php if($sess_foto_rumah_kanan != null) { ?>
						<tr>
							<td>Foto Rumah Bagian Kanan</td>
							<td>:</td>
							<td><img style="height: 150px;" src="<?php echo base_url(). 'assets/foto_dokumen/'.$value->upload_foto_rumah_kanan; ?>"></td>
								<td><i class="asterik">*</i></td>
						</tr>
						<?php } ?>
						<!--end Rumah Kanan-->

						<!--foto pbb-->
						<?php if($sess_foto_pbb == null) { ?>
						<tr>
							<td>Foto PBB</td>
							<td>:</td>
							<td></td>
							<td><i class="asterik">*</i></td>
						</tr>
						<?php } ?>

						<?php if($sess_foto_pbb != null) { ?>
						<tr>
							<td>Foto PBB</td>
							<td>:</td>
							<td><img style="height: 150px;" src="<?php echo base_url(). 'assets/foto_dokumen/'.$value->upload_foto_pbb; ?>"></td>
							<td><i class="asterik">*</i></td>
						</tr>
						<?php } ?>
						<!--end foto pbb-->

						<!--Foto rekening listrik-->
						<?php if($sess_foto_rek_listrik == null) { ?>
						<tr>
							<td>Foto Rekening Listrik</td>
							<td>:</td>
							<td></td>
							<td><i class="asterik">*</i></td>
						</tr>
						<?php } ?>
						
						<?php if($sess_foto_rek_listrik != null) { ?>
						<tr>
							<td>Foto Rekening Listrik</td>
							<td>:</td>
							<td><img style="height: 150px;" src="<?php echo base_url(). 'assets/foto_dokumen/'.$value->upload_foto_rek_listrik; ?>"></td>
								<td><i class="asterik">*</i></td>
						</tr>
						<?php } ?>
						<!--end Foto rekening listrik-->
					</table>
					<!--End Upload Dokumen Pendukung-->

					<!--button-->
					<div id="button-all">
						<div class="col-md-12 col-md-offset-2">
							<a href="<?=base_url('C_mhs/step7'); ?>" class="btn btn-info">
								<i class="fa fa-check-circle-o"></i>
								&laquo; Kembali
							</a>

							<button data-target="#edit-data-dokumen" data-toggle="modal" class="btn btn-primary" value="Edit" type="submit">
								<i class="glyphicon glyphicon-edit"></i>
								Edit
							</button>

							<a href="<?=base_url('C_mhs/step9'); ?>" class="btn btn-info">
								<i class="fa fa-check-circle-o"></i>
								Lanjut &raquo;
							</a>
						</div>
					</div>
					<!--End button-->
				</div>

				<!--Modal Update Dokumen Pendukung-->
				<form action="<?=base_url('C_mhs/direct8'); ?>" method="POST" enctype="multipart/form-data">
					<div id="edit-data-dokumen" class="modal fade" role="dialog">
						<div class="modal-dialog">
							<div class="modal-content">
								<div class="modal-header">
									<button type="button" class="close" data-dismiss="modal">&times;</button>
									<h4 class="modal-title">Edit Data Dokumen Pendukung</h4>
								</div>

								<div class="modal-body">
									<?php if($sess_foto_rumah_depan == null || $sess_foto_rumah_kiri == null || $sess_foto_rumah_kanan == null || $sess_foto_pbb == null || $sess_foto_rek_listrik == null) { ?>
									<div class="form-group">
										<label>Foto Rumah Bagian Depan</label>
										<br/>
										<input type="checkbox" name="ubah_foto_rumah_depan" value="1">&nbsp;&nbsp;Ceklis, Jika Ingin mengubah Foto Rumah Bagian Depan
										<input type="file" name="foto_rumah_depan">
									</div>

									<div class="form-group">
										<label>Foto Rumah Bagian Kiri</label>
										<br/>
										<input type="checkbox" name="ubah_foto_rumah_kiri" value="2">&nbsp;&nbsp;Ceklis, Jika Ingin mengubah Foto Rumah Bagian Kiri
										<input type="file" name="foto_rumah_kiri">
									</div>

									<div class="form-group">
										<label>Foto Rumah Bagian Kanan</label>
										<br/>
										<input type="checkbox" name="ubah_foto_rumah_kanan" value="3">&nbsp;&nbsp;Ceklis, Jika Ingin mengubah Foto Rumah Bagian Kanan
										<input type="file" name="foto_rumah_kanan">
									</div>

									<div class="form-group">
										<label>Foto PBB</label>
										<br/>
										<input type="checkbox" name="ubah_foto_pbb" value="4">&nbsp;&nbsp;Ceklis, Jika Ingin mengubah Foto PBB
										<input type="file" name="foto_pbb">
									</div>

									<div class="form-group">
										<label>Foto Rekening Listrik</label>
										<br/>
										<input type="checkbox" name="ubah_foto_rek" value="5">&nbsp;&nbsp;Ceklis, Jika Ingin mengubah Foto Rekening Listrik
										<input type="file" name="foto_rek_listrik">
									</div>
									<?php }else if($sess_foto_rumah_depan != null || $sess_foto_rumah_kiri != null || $sess_foto_rumah_kanan != null || $sess_foto_pbb != null || $sess_foto_rek_listrik != null) { ?>
									<div class="form-group">
											<label>Foto Rumah Bagian Depan</label>
										<table>
										<tr>
											<td><img style="height: 210px;" src="<?php echo base_url(). 'assets/foto_dokumen/'.$value->upload_foto_rumah_depan; ?>"></td>
											</tr>
										</table>
										<input type="checkbox" name="ubah_foto_rumah_depan" value="1">&nbsp;&nbsp;Ceklis, Jika Ingin mengubah Foto Rumah Bagian Depan
										<input type="file" name="foto_rumah_depan">
									</div>

									<div class="form-group">
										<label>Foto Rumah Bagian Kiri</label>
										<table>
										<tr>
											<td><img style="height: 210px;" src="<?php echo base_url(). 'assets/foto_dokumen/'.$value->upload_foto_rumah_kiri; ?>"></td>
											</tr>
										</table>
										<input type="checkbox" name="ubah_foto_rumah_kiri" value="2">&nbsp;&nbsp;Ceklis, Jika Ingin mengubah Foto Rumah Bagian Kiri
										<input type="file" name="foto_rumah_kiri">
									</div>

									<div class="form-group">
										<label>Foto Rumah Bagian Kanan</label>
										<table>
										<tr>
											<td><img style="height: 210px;" src="<?php echo base_url(). 'assets/foto_dokumen/'.$value->upload_foto_rumah_kanan; ?>"></td>
											</tr>
										</table>
										<input type="checkbox" name="ubah_foto_rumah_kanan" value="3">&nbsp;&nbsp;Ceklis, Jika Ingin mengubah Foto Rumah Bagian Kanan
										<input type="file" name="foto_rumah_kanan">
									</div>

									<div class="form-group">
										<label>Foto PBB</label>
										<table>
											<tr>
												<td><img style="height: 210px;" src="<?php echo base_url(). 'assets/foto_dokumen/'.$value->upload_foto_pbb; ?>"></td>
											</tr>
										</table>
										<input type="checkbox" name="ubah_foto_pbb" value="4">&nbsp;&nbsp;Ceklis, Jika Ingin mengubah Foto PBB
										<input type="file" name="foto_pbb">
									</div>

									<div class="form-group">
										<label>Foto Rekening Listrik</label>
										<table>
											<tr>
												<td><img style="height: 210px;" src="<?php echo base_url(). 'assets/foto_dokumen/'.$value->upload_foto_rek_listrik; ?>"></td>
											</tr>
										</table>
										<input type="checkbox" name="ubah_foto_rek" value="5">&nbsp;&nbsp;Ceklis, Jika Ingin mengubah Foto Rekening Listrik
										<input type="file" name="foto_rek_listrik">
									</div>
								<?php } ?>
								</div>
							<?php } ?>


								<div class="modal-footer">
									<button type="button" class="btn btn-default" data-dismiss="modal">Tutup</button>
									<button type="submit" class="btn btn-primary">Simpan</button>
								</div>
								</div>
							</div>
						</div>
					</form>
					<!--end Modal Update Dokumen Pendukung-->
				</div>
			</div>
		</div>
	</body>

	<div style="text-align: center;">	
		<?php
		$this->load->view('project_bidikmisi/footer/footer');
		?>
	</div>
</html>

<!--kodingan ga di pake-->
<!--form action="<?//=base_url('C_mhs/direct8'); ?>" method="POST" enctype="multipart/form-data">
<div class="table-responsive">
	<table class="table">
		<tr class="form-group">
			<td class="input">Foto Rumah Bagian Depan</td>
			<td>:</td>
			<td><input type="file" class="input" name="foto_rumah_depan" required="required"></td>
			<td><i class="asterik">*</i></td>
		</tr>

		<tr class="form-group">
			<td class="input">Foto Rumah Bagian Samping Kiri</td>
			<td>:</td>
			<td><input type="file" class="input" name="foto_rumah_kiri" required="required"></td>
			<td><i class="asterik">*</i></td>
		</tr>

		<tr class="form-group">
			<td class="input">Foto Rumah Bagian Samping Kanan</td>
			<td>:</td>
			<td><input type="file" class="input" name="foto_rumah_kanan" required="required"></td>
			<td><i class="asterik">*</i></td>
		</tr>

		<tr class="form-group">
			<td class="input">Foto PBB Tahun Terakhir</td>
			<td>:</td>
			<td><input type="file" class="input" name="foto_pbb"required="required"></td>
			<td><i class="asterik">*</i></td>
		</tr>

		<tr class="form-group">
			<td class="input">Foto Rekening Listrik</td>
			<td>:</td>
			<td><input type="file" class="input" name="foto_rek_listrik" required="required"></td>
			<td><i class="asterik">*</i></td>
		</tr>
	</table>
</div>
</form-->
<!--end kodingan ga di pake-->