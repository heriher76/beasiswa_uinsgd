<!DOCTYPE html>
<html>
	<body>
	<!--Header-->
		<header>	
			<div class="container">
				<div class="row">
					<div class="col-md-7 col-md-offset-5" style="text-align: center; padding-left: 50px;">
						<img src="<?=base_url('assets/img/logo-uin-bandung.png')?>">
					</div>

					<div class="col-md-12" style="text-align: center;">
						<h1>Penerimaan Beasiswa BidikMisi Universitas Islam Negeri Sunan Gunung Djati Bandung</h1>
					</div>

					<div style="margin-top: 30px;">
						<div class="col-md-offset-0 col-md-1" style="padding-right: 10px;">
							<a class="btn btn-info" href="<?=base_url('C_mhs/biodata'); ?>">
							<span class="glyphicon glyphicon-user"></span>	
								Lihat Biodata
							</a>
						</div>

						<div class="col-md-offset-1 col-md-1">
							<a class="btn btn-info" href="<?=base_url('C_mhs/pengumuman'); ?>">
							<span class="glyphicon glyphicon-bullhorn"></span>	
								Lihat Pengumuman
							</a>
						</div>

						<div class="col-md-offset-1 col-md-1">
							<a class="btn btn-info" href="<?=base_url('C_mhs/change'); ?>">
							<span class="glyphicon glyphicon-lock"></span>	
								Ganti Password
							</a>
						</div>

						<!--div class="col-md-offset-1 col-md-1">
							<a target="_blank" class="btn btn-info" href="<?//=base_url('C_mhs/cetak'); ?>">
							<span class="glyphicon glyphicon-print"></span>	
								Cetak Formulir
							</a>
						</div-->

						<div class="col-md-offset-1 col-md-1">
							<a class="btn btn-danger" href="<?=base_url('C_login/logout'); ?>">
							<span class="glyphicon glyphicon-log-out"></span>
								Logout
							</a>
						</div>
					</div>
				</div>
			</div>
		</header>
		<!--End Header-->
	</body>
</html>